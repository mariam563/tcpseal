/*
 * tcp_transfer.c - echo-based TCP transfer used to test the PC1 <-> PC2 path.
 *
 *   tcp_transfer server [--bind 0.0.0.0] [--port 5001]
 *   tcp_transfer client --host 10.0.2.2 [--port 5001] [--size 200000] [--timeout 10]
 *
 * The client sends --size bytes, the server echoes every byte, and the client
 * compares SHA-256 of sent and received data. Both directions are exercised.
 * Every 1024-byte block starts with an ASCII marker so that a capture on the
 * inter-device link can prove the data was encrypted.
 */
#include <openssl/evp.h>
#include <openssl/rand.h>

#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>

static const char MARKER[] = "TCPSEAL-PLAINTEXT-MARKER";

static void *echo(void *arg)
{
    int fd = (int)(intptr_t)arg;
    char buf[65536];
    ssize_t n;
    while ((n = recv(fd, buf, sizeof(buf), 0)) > 0) {
        ssize_t off = 0;
        while (off < n) {
            ssize_t w = send(fd, buf + off, (size_t)(n - off), MSG_NOSIGNAL);
            if (w <= 0) {
                goto done;
            }
            off += w;
        }
    }
done:
    (void)close(fd);
    return NULL;
}

static int serve(const char *bind_addr, int port)
{
    struct sockaddr_in addr = {.sin_family = AF_INET, .sin_port = htons((uint16_t)port)};
    int one = 1;
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0 || inet_pton(AF_INET, bind_addr, &addr.sin_addr) != 1 ||
        setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one)) != 0 ||
        bind(fd, (struct sockaddr *)&addr, sizeof(addr)) != 0 || listen(fd, 16) != 0) {
        (void)fprintf(stderr, "transfer failed: %s\n", strerror(errno));
        return 1;
    }
    (void)printf("echo server listening on %s:%d\n", bind_addr, port);
    (void)fflush(stdout);
    for (;;) {
        int conn = accept(fd, NULL, NULL);
        if (conn < 0) {
            continue;
        }
        pthread_t thread;
        if (pthread_create(&thread, NULL, echo, (void *)(intptr_t)conn) == 0) {
            (void)pthread_detach(thread);
        } else {
            (void)close(conn);
        }
    }
}

typedef struct {
    int fd;
    const unsigned char *data;
    size_t size;
    int ok;
} sender_args;

static void *sender(void *arg)
{
    sender_args *a = arg;
    size_t off = 0;
    while (off < a->size) {
        ssize_t w = send(a->fd, a->data + off, a->size - off, MSG_NOSIGNAL);
        if (w <= 0) {
            return NULL;
        }
        off += (size_t)w;
    }
    (void)shutdown(a->fd, SHUT_WR);
    a->ok = 1;
    return NULL;
}

static void sha256(const unsigned char *data, size_t len, unsigned char out[32])
{
    unsigned int out_len = 32;
    (void)EVP_Digest(data, len, out, &out_len, EVP_sha256(), NULL);
}

static int client(const char *host, int port, size_t size, double timeout)
{
    unsigned char *data = malloc(size + 1);
    unsigned char *received = malloc(size + 1);
    if (data == NULL || received == NULL || RAND_bytes(data, (int)size) != 1) {
        (void)fprintf(stderr, "transfer failed: out of memory\n");
        free(data);
        free(received);
        return 1;
    }
    for (size_t off = 0; off + sizeof(MARKER) - 1 <= size; off += 1024 + sizeof(MARKER) - 1) {
        memcpy(data + off, MARKER, sizeof(MARKER) - 1);
    }
    struct sockaddr_in addr = {.sin_family = AF_INET, .sin_port = htons((uint16_t)port)};
    struct timeval tv = {(time_t)timeout, (suseconds_t)((timeout - (double)(time_t)timeout) * 1e6)};
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    (void)inet_pton(AF_INET, host, &addr.sin_addr);
    (void)setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    (void)setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
    if (fd < 0 || connect(fd, (struct sockaddr *)&addr, sizeof(addr)) != 0) {
        (void)fprintf(stderr, "transfer failed: %s\n", errno == EINPROGRESS ? "timed out" : strerror(errno));
        free(data);
        free(received);
        return 1;
    }
    sender_args args = {fd, data, size, 0};
    pthread_t thread;
    (void)pthread_create(&thread, NULL, sender, &args);
    size_t got = 0;
    for (;;) {
        ssize_t n = recv(fd, received + got, size + 1 - got, 0);
        if (n <= 0) {
            if (n < 0) {
                (void)fprintf(stderr, "transfer failed: %s\n",
                              errno == EAGAIN ? "timed out" : strerror(errno));
                (void)shutdown(fd, SHUT_RDWR);
                (void)pthread_join(thread, NULL);
                (void)close(fd);
                free(data);
                free(received);
                return 1;
            }
            break;
        }
        got += (size_t)n;
        if (got > size) {
            break;
        }
    }
    (void)pthread_join(thread, NULL);
    (void)close(fd);
    unsigned char h1[32], h2[32];
    sha256(data, size, h1);
    sha256(received, got, h2);
    int ok = got == size && memcmp(h1, h2, 32) == 0;
    (void)printf("sent=%zu received=%zu sha256_match=%s\n", size, got, ok ? "True" : "False");
    free(data);
    free(received);
    return ok ? 0 : 1;
}

int main(int argc, char **argv)
{
    const char *bind_addr = "0.0.0.0", *host = NULL;
    int port = 5001;
    size_t size = 200000;
    double timeout = 10.0;
    if (argc < 2) {
        (void)fprintf(stderr, "usage: tcp_transfer server|client [options]\n");
        return 2;
    }
    for (int i = 2; i + 1 < argc; i += 2) {
        if (strcmp(argv[i], "--bind") == 0) {
            bind_addr = argv[i + 1];
        } else if (strcmp(argv[i], "--host") == 0) {
            host = argv[i + 1];
        } else if (strcmp(argv[i], "--port") == 0) {
            port = atoi(argv[i + 1]);
        } else if (strcmp(argv[i], "--size") == 0) {
            size = (size_t)strtoull(argv[i + 1], NULL, 10);
        } else if (strcmp(argv[i], "--timeout") == 0) {
            timeout = strtod(argv[i + 1], NULL);
        } else {
            (void)fprintf(stderr, "unknown option %s\n", argv[i]);
            return 2;
        }
    }
    if (strcmp(argv[1], "server") == 0) {
        return serve(bind_addr, port);
    }
    if (strcmp(argv[1], "client") == 0 && host != NULL && size > 0) {
        return client(host, port, size, timeout);
    }
    (void)fprintf(stderr, "usage: tcp_transfer server|client [options]\n");
    return 2;
}
