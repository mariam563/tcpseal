/*
 * link_sniffer.c - tiny AF_PACKET capture used by the demo as evidence.
 *
 *   link_sniffer --interface ts-d2p --port 5001 --marker TEXT --out summary.json
 *
 * Runs until SIGTERM/SIGINT, then writes a JSON summary: TCP packets for
 * --port, how many had payload, how many contained the plaintext marker, and
 * a few payload sizes. It never stores captured packet contents.
 * Creates "<out>.ready" once the socket is listening.
 */
#include <arpa/inet.h>
#include <errno.h>
#include <linux/if_ether.h>
#include <linux/if_packet.h>
#include <net/if.h>
#include <poll.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

static volatile sig_atomic_t g_running = 1;
static void on_signal(int signum)
{
    (void)signum;
    g_running = 0;
}

int main(int argc, char **argv)
{
    const char *iface = NULL, *marker = NULL, *out = NULL;
    int port = -1;
    for (int i = 1; i + 1 < argc; i += 2) {
        if (strcmp(argv[i], "--interface") == 0) {
            iface = argv[i + 1];
        } else if (strcmp(argv[i], "--port") == 0) {
            port = atoi(argv[i + 1]);
        } else if (strcmp(argv[i], "--marker") == 0) {
            marker = argv[i + 1];
        } else if (strcmp(argv[i], "--out") == 0) {
            out = argv[i + 1];
        }
    }
    if (iface == NULL || marker == NULL || out == NULL || port < 0) {
        (void)fprintf(stderr, "usage: link_sniffer --interface IF --port N --marker TEXT --out FILE\n");
        return 2;
    }
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = on_signal;
    (void)sigaction(SIGTERM, &sa, NULL);
    (void)sigaction(SIGINT, &sa, NULL);

    int fd = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
    struct sockaddr_ll sll = {
        .sll_family = AF_PACKET, .sll_protocol = htons(ETH_P_ALL), .sll_ifindex = (int)if_nametoindex(iface)};
    if (fd < 0 || sll.sll_ifindex == 0 || bind(fd, (struct sockaddr *)&sll, sizeof(sll)) != 0) {
        (void)fprintf(stderr, "link_sniffer: cannot capture on %s: %s\n", iface, strerror(errno));
        return 1;
    }
    char ready[4096];
    (void)snprintf(ready, sizeof(ready), "%s.ready", out);
    FILE *r = fopen(ready, "w");
    if (r != NULL) {
        (void)fclose(r);
    }

    unsigned long tcp_packets = 0, with_payload = 0, marker_hits = 0;
    size_t sizes[10];
    int nsizes = 0;
    size_t marker_len = strlen(marker);
    static unsigned char frame[70000];
    while (g_running) {
        struct pollfd pfd = {.fd = fd, .events = POLLIN};
        if (poll(&pfd, 1, 200) <= 0) {
            continue;
        }
        ssize_t n = recv(fd, frame, sizeof(frame), 0);
        if (n < 0) {
            if (errno == EINTR) {
                continue;
            }
            break; /* interface went away */
        }
        if (n < 34 || frame[12] != 0x08 || frame[13] != 0x00) {
            continue;
        }
        const unsigned char *ip = frame + 14;
        size_t ip_avail = (size_t)n - 14;
        size_t ihl = (size_t)(ip[0] & 0x0F) * 4;
        if (ip[9] != 6 || ip_avail < ihl + 20) {
            continue;
        }
        int sport = (ip[ihl] << 8) | ip[ihl + 1];
        int dport = (ip[ihl + 2] << 8) | ip[ihl + 3];
        if (sport != port && dport != port) {
            continue;
        }
        size_t total = (size_t)((ip[2] << 8) | ip[3]);
        size_t start = ihl + (size_t)(ip[ihl + 12] >> 4) * 4;
        if (total > ip_avail) {
            total = ip_avail;
        }
        size_t payload = total > start ? total - start : 0;
        tcp_packets++;
        if (payload > 0) {
            with_payload++;
            if (nsizes < 10) {
                sizes[nsizes++] = payload;
            }
            if (marker_len > 0 && memmem(ip + start, payload, marker, marker_len) != NULL) {
                marker_hits++;
            }
        }
    }
    FILE *f = fopen(out, "w");
    if (f == NULL) {
        return 1;
    }
    (void)fprintf(f,
                  "{\n  \"interface\": \"%s\",\n  \"tcp_packets\": %lu,\n  \"with_payload\": %lu,\n"
                  "  \"marker_hits\": %lu,\n  \"payload_sizes_sample\": [",
                  iface, tcp_packets, with_payload, marker_hits);
    for (int i = 0; i < nsizes; ++i) {
        (void)fprintf(f, "%s%zu", i ? ", " : "", sizes[i]);
    }
    (void)fprintf(f, "]\n}\n");
    (void)fclose(f);
    (void)close(fd);
    return 0;
}
