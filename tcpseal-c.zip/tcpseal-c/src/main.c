/*
 * main.c - command line interface.
 *
 *   tcpseal keygen --name device1 [--dir local/keys] [--force]
 *   tcpseal check-config local/device1.ini
 *   tcpseal run local/device1.ini
 *
 * Exit codes: 0 ok, 1 runtime error, 2 configuration/key error,
 *             3 NFQUEUE not available (not root / module missing).
 */
#include "tcpseal/common.h"
#include "tcpseal/config.h"
#include "tcpseal/daemon.h"
#include "tcpseal/keys.h"

#include <stdio.h>
#include <string.h>

static void usage(FILE *out)
{
    (void)fprintf(
        out,
        "usage: tcpseal <command> [options]\n\n"
        "Inline AES-GCM protection of TCP payloads.\n\n"
        "commands:\n"
        "  keygen --name NAME [--dir DIR] [--force]  generate an Ed25519 identity key pair\n"
        "  check-config CONFIG                       validate a configuration file and its keys\n"
        "  run CONFIG                                run the gateway daemon (needs root / CAP_NET_ADMIN)\n"
        "  --version                                 print the version\n");
}

static int cmd_keygen(int argc, char **argv)
{
    const char *name = NULL, *dir = "local/keys";
    int force = 0;
    for (int i = 0; i < argc; ++i) {
        if (strcmp(argv[i], "--name") == 0 && i + 1 < argc) {
            name = argv[++i];
        } else if (strcmp(argv[i], "--dir") == 0 && i + 1 < argc) {
            dir = argv[++i];
        } else if (strcmp(argv[i], "--force") == 0) {
            force = 1;
        } else {
            usage(stderr);
            return 2;
        }
    }
    if (name == NULL) {
        (void)fprintf(stderr, "error: keygen needs --name\n");
        return 2;
    }
    char private_path[PATH_MAX], public_path[PATH_MAX], err[TS_ERR_LEN], fp[17];
    if (ts_keygen(dir, name, force, private_path, public_path, sizeof(private_path), err) != 0) {
        (void)fprintf(stderr, "error: %s\n", err);
        return 2;
    }
    EVP_PKEY *pub = ts_load_public(public_path, err);
    ts_fingerprint(pub, fp);
    EVP_PKEY_free(pub);
    (void)printf("private key (keep secret, never commit): %s\n", private_path);
    (void)printf("public key  (copy to the peer device):   %s\n", public_path);
    (void)printf("fingerprint: %s\n", fp);
    return 0;
}

static int load_config(const char *path, ts_config *cfg)
{
    char err[TS_ERR_LEN];
    if (ts_config_load(path, cfg, err) != 0) {
        (void)fprintf(stderr, "error: %s\n", err);
        return -1;
    }
    return 0;
}

static int cmd_check_config(const char *path)
{
    static ts_config cfg;
    char err[TS_ERR_LEN], own[17], peer_fp[17];
    if (load_config(path, &cfg) != 0) {
        return 2;
    }
    EVP_PKEY *identity = ts_load_private(cfg.identity_key, err);
    EVP_PKEY *peer = identity != NULL ? ts_load_public(cfg.peer_public_key, err) : NULL;
    if (identity == NULL || peer == NULL) {
        (void)fprintf(stderr, "error: %s\n", err);
        EVP_PKEY_free(identity);
        return 2;
    }
    ts_fingerprint(identity, own);
    ts_fingerprint(peer, peer_fp);
    (void)printf("OK: role=%s control=%s:%u queues=%u/%u peer_mtu=%u\n", cfg.role, cfg.control_address,
                 cfg.control_port, cfg.encrypt_queue, cfg.decrypt_queue, cfg.peer_mtu);
    (void)printf("own key fingerprint:  %s\n", own);
    (void)printf("peer key fingerprint: %s\n", peer_fp);
    EVP_PKEY_free(identity);
    EVP_PKEY_free(peer);
    return 0;
}

static int cmd_run(const char *path)
{
    static ts_config cfg;
    if (load_config(path, &cfg) != 0) {
        return 2;
    }
    ts_log_setup(cfg.log_level, cfg.role);
    return ts_daemon_run(&cfg);
}

int main(int argc, char **argv)
{
    if (argc < 2) {
        usage(stderr);
        return 2;
    }
    const char *command = argv[1];
    if (strcmp(command, "--version") == 0) {
        (void)printf("tcpseal %s\n", TS_VERSION);
        return 0;
    }
    if (strcmp(command, "-h") == 0 || strcmp(command, "--help") == 0) {
        usage(stdout);
        return 0;
    }
    if (strcmp(command, "keygen") == 0) {
        return cmd_keygen(argc - 2, argv + 2);
    }
    if (strcmp(command, "check-config") == 0 && argc == 3) {
        return cmd_check_config(argv[2]);
    }
    if (strcmp(command, "run") == 0 && argc == 3) {
        return cmd_run(argv[2]);
    }
    usage(stderr);
    return 2;
}
