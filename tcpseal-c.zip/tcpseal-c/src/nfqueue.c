/*
 * nfqueue.c - minimal NFQUEUE netlink client.
 */
#include "tcpseal/nfqueue.h"

#include "tcpseal/common.h"

#include <linux/netlink.h>

#include <errno.h>
#include <poll.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#define BUFFER_SIZE (256 * 1024)
#define CFG_CMD_BIND 1
#define CFG_CMD_UNBIND 2
#define COPY_PACKET 2
#define ALIGN4(x) (((x) + 3u) & ~(size_t)3u)

static uint16_t msg_type_full(uint8_t msg_type) { return (uint16_t)((TS_NFQ_SUBSYS_QUEUE << 8) | msg_type); }

size_t ts_nl_put_attr(uint8_t *buf, size_t len, size_t cap, uint16_t type, const void *data, size_t data_len)
{
    size_t attr_len = 4 + data_len;
    if (attr_len > 0xFFFF || len + ALIGN4(attr_len) > cap) {
        return 0;
    }
    struct nlattr *attr = (struct nlattr *)(void *)(buf + len);
    attr->nla_len = (uint16_t)attr_len;
    attr->nla_type = type;
    if (data_len > 0) {
        memcpy(buf + len + 4, data, data_len);
    }
    memset(buf + len + attr_len, 0, ALIGN4(attr_len) - attr_len); /* padding */
    return len + ALIGN4(attr_len);
}

size_t ts_nfq_begin(uint8_t *buf, size_t cap, uint8_t msg_type, uint16_t flags, uint32_t seq, uint16_t queue)
{
    if (cap < TS_NLMSG_HDRLEN + TS_NFGENMSG_LEN) {
        return 0;
    }
    struct nlmsghdr *nlh = (struct nlmsghdr *)(void *)buf;
    nlh->nlmsg_len = 0;
    nlh->nlmsg_type = msg_type_full(msg_type);
    nlh->nlmsg_flags = flags;
    nlh->nlmsg_seq = seq;
    nlh->nlmsg_pid = 0;
    uint8_t *gen = buf + TS_NLMSG_HDRLEN; /* struct nfgenmsg */
    gen[0] = 0;                           /* AF_UNSPEC */
    gen[1] = 0;                           /* NFNETLINK_V0 */
    ts_put16(gen + 2, queue);             /* res_id = queue number, big-endian */
    return TS_NLMSG_HDRLEN + TS_NFGENMSG_LEN;
}

void ts_nfq_end(uint8_t *buf, size_t len) { ((struct nlmsghdr *)(void *)buf)->nlmsg_len = (uint32_t)len; }

const uint8_t *ts_nl_find_attr(const uint8_t *attrs, size_t len, uint16_t type, size_t *out_len)
{
    size_t offset = 0;
    while (offset + 4 <= len) {
        const struct nlattr *attr = (const struct nlattr *)(const void *)(attrs + offset);
        if (attr->nla_len < 4 || offset + attr->nla_len > len) {
            break;
        }
        if ((attr->nla_type & NLA_TYPE_MASK) == type) {
            *out_len = attr->nla_len - 4u;
            return attrs + offset + 4;
        }
        offset += ALIGN4(attr->nla_len);
    }
    return NULL;
}

int ts_nfq_parse_packet(const uint8_t *body, size_t body_len, ts_queued_packet *out)
{
    size_t header_len = 0;
    if (body_len < TS_NFGENMSG_LEN) {
        return -1;
    }
    out->queue = ts_get16(body + 2);
    const uint8_t *attrs = body + TS_NFGENMSG_LEN;
    size_t attrs_len = body_len - TS_NFGENMSG_LEN;
    const uint8_t *header = ts_nl_find_attr(attrs, attrs_len, TS_NFQA_PACKET_HDR, &header_len);
    if (header == NULL || header_len < 4) {
        return -1;
    }
    out->packet_id = ts_get32(header);
    out->payload = ts_nl_find_attr(attrs, attrs_len, TS_NFQA_PAYLOAD, &out->payload_len);
    if (out->payload == NULL) {
        out->payload_len = 0;
    }
    return 0;
}

/* Send a config request and wait for the kernel's ACK. Returns 0 or errno. */
static int configure(ts_nfqueue *q, uint16_t queue, uint16_t attr_type, const void *data, size_t data_len)
{
    uint8_t msg[64];
    uint32_t seq = ++q->seq;
    size_t len =
        ts_nfq_begin(msg, sizeof(msg), TS_NFQ_MSG_CONFIG, TS_NLM_F_REQUEST | TS_NLM_F_ACK, seq, queue);
    len = ts_nl_put_attr(msg, len, sizeof(msg), attr_type, data, data_len);
    ts_nfq_end(msg, len);
    if (send(q->fd, msg, len, 0) < 0) {
        return errno;
    }
    for (;;) {
        struct pollfd pfd = {.fd = q->fd, .events = POLLIN};
        if (poll(&pfd, 1, 2000) <= 0) {
            return ETIMEDOUT;
        }
        ssize_t n = recv(q->fd, q->buffer, BUFFER_SIZE, 0);
        if (n < 0) {
            return errno;
        }
        size_t offset = 0;
        while (offset + TS_NLMSG_HDRLEN <= (size_t)n) {
            const struct nlmsghdr *nlh = (const struct nlmsghdr *)(void *)(q->buffer + offset);
            if (nlh->nlmsg_len < TS_NLMSG_HDRLEN || offset + nlh->nlmsg_len > (size_t)n) {
                break;
            }
            const uint8_t *body = q->buffer + offset + TS_NLMSG_HDRLEN;
            size_t body_len = nlh->nlmsg_len - TS_NLMSG_HDRLEN;
            if (nlh->nlmsg_type == NLMSG_ERROR && nlh->nlmsg_seq == seq) {
                int error;
                memcpy(&error, body, sizeof(error));
                return -error; /* 0 = ACK, otherwise negative errno */
            }
            ts_queued_packet packet;
            if (nlh->nlmsg_type == msg_type_full(TS_NFQ_MSG_PACKET) &&
                ts_nfq_parse_packet(body, body_len, &packet) == 0) {
                /* A packet arrived while we were still configuring: fail closed. */
                (void)ts_nfq_verdict(q, packet.queue, packet.packet_id, 0, NULL, 0);
            }
            offset += ALIGN4(nlh->nlmsg_len);
        }
    }
}

int ts_nfq_open(ts_nfqueue *q, const uint16_t *queues, int count, char *err)
{
    memset(q, 0, sizeof(*q));
    q->fd = socket(AF_NETLINK, SOCK_RAW | SOCK_CLOEXEC, NETLINK_NETFILTER);
    q->buffer = malloc(BUFFER_SIZE);
    if (q->fd < 0 || q->buffer == NULL) {
        int code = q->fd < 0 ? errno : ENOMEM;
        ts_set_error(err, "cannot open netfilter socket: %s", strerror(code));
        ts_nfq_close(q);
        return code;
    }
    struct sockaddr_nl address = {.nl_family = AF_NETLINK};
    int rcvbuf = 4 * 1024 * 1024;
    (void)setsockopt(q->fd, SOL_SOCKET, SO_RCVBUF, &rcvbuf, sizeof(rcvbuf));
    if (bind(q->fd, (struct sockaddr *)&address, sizeof(address)) != 0) {
        int code = errno;
        ts_set_error(err, "cannot bind netlink socket: %s", strerror(code));
        ts_nfq_close(q);
        return code;
    }
    for (int i = 0; i < count && i < 2; ++i) {
        uint8_t bind_cmd[4] = {CFG_CMD_BIND, 0, 0, 0};
        uint8_t params[5];
        uint8_t maxlen[4];
        ts_put32(params, 0xFFFF); /* copy range: whole packet */
        params[4] = COPY_PACKET;
        ts_put32(maxlen, 4096);
        int code = configure(q, queues[i], TS_NFQA_CFG_CMD, bind_cmd, sizeof(bind_cmd));
        if (code == 0) {
            q->queues[q->queue_count++] = queues[i];
            code = configure(q, queues[i], TS_NFQA_CFG_PARAMS, params, sizeof(params));
        }
        if (code == 0) {
            code = configure(q, queues[i], TS_NFQA_CFG_QUEUE_MAXLEN, maxlen, sizeof(maxlen));
        }
        if (code != 0) {
            if (code == EPERM) {
                ts_set_error(err, "binding NFQUEUE needs root or CAP_NET_ADMIN");
            } else {
                ts_set_error(err, "NFQUEUE %u configuration failed: %s", queues[i], strerror(code));
            }
            ts_nfq_close(q);
            return code;
        }
    }
    return 0;
}

int ts_nfq_verdict(ts_nfqueue *q, uint16_t queue, uint32_t packet_id, int accept, const uint8_t *payload,
                   size_t payload_len)
{
    uint8_t header[64];
    uint8_t verdict[8];
    ts_put32(verdict, accept ? TS_NF_ACCEPT : TS_NF_DROP);
    ts_put32(verdict + 4, packet_id);
    size_t len = ts_nfq_begin(header, sizeof(header), TS_NFQ_MSG_VERDICT, TS_NLM_F_REQUEST, ++q->seq, queue);
    len = ts_nl_put_attr(header, len, sizeof(header), TS_NFQA_VERDICT_HDR, verdict, sizeof(verdict));

    /* The replacement packet is sent from its own buffer with sendmsg (no copy). */
    struct nlattr payload_attr = {.nla_len = (uint16_t)(4 + payload_len), .nla_type = TS_NFQA_PAYLOAD};
    static const uint8_t padding[4] = {0};
    struct iovec iov[4] = {{header, len}};
    int iov_count = 1;
    size_t total = len;
    if (payload != NULL) {
        if (payload_len > TS_NFQ_MAX_PAYLOAD) {
            return -1;
        }
        iov[1] = (struct iovec){&payload_attr, 4};
        iov[2] = (struct iovec){(void *)payload, payload_len};
        iov[3] = (struct iovec){(void *)padding, ALIGN4(payload_len) - payload_len};
        iov_count = 4;
        total += 4 + ALIGN4(payload_len);
    }
    ts_nfq_end(header, total);
    struct sockaddr_nl kernel = {.nl_family = AF_NETLINK};
    struct msghdr msg = {
        .msg_name = &kernel, .msg_namelen = sizeof(kernel), .msg_iov = iov, .msg_iovlen = (size_t)iov_count};
    return sendmsg(q->fd, &msg, 0) < 0 ? -1 : 0;
}

int ts_nfq_receive(ts_nfqueue *q, int timeout_ms, ts_packet_callback cb, void *ctx)
{
    struct pollfd pfd = {.fd = q->fd, .events = POLLIN};
    int ready = poll(&pfd, 1, timeout_ms);
    if (ready <= 0) {
        return (ready < 0 && errno != EINTR) ? -1 : 0;
    }
    ssize_t n = recv(q->fd, q->buffer, BUFFER_SIZE, 0);
    if (n < 0) {
        if (errno == ENOBUFS) { /* kernel queue overflow: it dropped packets (fail-closed) */
            q->overflows++;
            return 0;
        }
        return errno == EINTR ? 0 : -1;
    }
    size_t offset = 0;
    while (offset + TS_NLMSG_HDRLEN <= (size_t)n) {
        const struct nlmsghdr *nlh = (const struct nlmsghdr *)(void *)(q->buffer + offset);
        if (nlh->nlmsg_len < TS_NLMSG_HDRLEN || offset + nlh->nlmsg_len > (size_t)n) {
            break;
        }
        ts_queued_packet packet;
        if (nlh->nlmsg_type == msg_type_full(TS_NFQ_MSG_PACKET) &&
            ts_nfq_parse_packet(q->buffer + offset + TS_NLMSG_HDRLEN, nlh->nlmsg_len - TS_NLMSG_HDRLEN,
                                &packet) == 0) {
            cb(ctx, &packet);
        }
        offset += ALIGN4(nlh->nlmsg_len);
    }
    return 0;
}

void ts_nfq_close(ts_nfqueue *q)
{
    if (q->fd >= 0) {
        for (int i = 0; i < q->queue_count; ++i) {
            uint8_t msg[64];
            uint8_t unbind[4] = {CFG_CMD_UNBIND, 0, 0, 0};
            size_t len =
                ts_nfq_begin(msg, sizeof(msg), TS_NFQ_MSG_CONFIG, TS_NLM_F_REQUEST, ++q->seq, q->queues[i]);
            len = ts_nl_put_attr(msg, len, sizeof(msg), TS_NFQA_CFG_CMD, unbind, sizeof(unbind));
            ts_nfq_end(msg, len);
            (void)send(q->fd, msg, len, 0);
        }
        (void)close(q->fd);
    }
    free(q->buffer);
    q->fd = -1;
    q->buffer = NULL;
    q->queue_count = 0;
}
