/*
 * common.c - logging, error buffers, clock and secure erase.
 */
#include "tcpseal/common.h"

#include <openssl/crypto.h>

#include <pthread.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <sys/time.h>
#include <time.h>

static int g_level = TS_LOG_INFO;
static char g_role[16] = "tcpseal";
static pthread_mutex_t g_log_lock = PTHREAD_MUTEX_INITIALIZER;
static const char *const LEVEL_NAMES[] = {"DEBUG", "INFO", "WARNING", "ERROR"};

void ts_log_setup(int level, const char *role)
{
    g_level = level;
    if (role != NULL) {
        (void)snprintf(g_role, sizeof(g_role), "%s", role);
    }
}

int ts_log_level_from_name(const char *name)
{
    static const char *const names[] = {"debug", "info", "warning", "error"};
    for (int i = 0; i < 4; ++i) {
        if (strcasecmp(name, names[i]) == 0) {
            return i;
        }
    }
    return -1;
}

void ts_log(int level, const char *component, const char *fmt, ...)
{
    if (level < g_level) {
        return;
    }
    struct timeval tv;
    struct tm tm;
    char stamp[32];
    (void)gettimeofday(&tv, NULL);
    (void)localtime_r(&tv.tv_sec, &tm);
    (void)strftime(stamp, sizeof(stamp), "%Y-%m-%d %H:%M:%S", &tm);

    va_list args;
    va_start(args, fmt);
    (void)pthread_mutex_lock(&g_log_lock);
    (void)fprintf(stderr, "%s,%03ld %s %s %s: ", stamp, (long)(tv.tv_usec / 1000), g_role, LEVEL_NAMES[level],
                  component);
    (void)vfprintf(stderr, fmt, args);
    (void)fputc('\n', stderr);
    (void)fflush(stderr);
    (void)pthread_mutex_unlock(&g_log_lock);
    va_end(args);
}

void ts_set_error(char *err, const char *fmt, ...)
{
    if (err == NULL) {
        return;
    }
    va_list args;
    va_start(args, fmt);
    (void)vsnprintf(err, TS_ERR_LEN, fmt, args);
    va_end(args);
}

double ts_now(void)
{
    struct timespec ts;
    (void)clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec / 1e9;
}

void ts_secure_zero(void *data, size_t len)
{
    if (data != NULL && len > 0) {
        OPENSSL_cleanse(data, len);
    }
}
