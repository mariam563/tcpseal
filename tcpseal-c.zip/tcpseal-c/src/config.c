/*
 * config.c - small strict INI parser and validation.
 */
#include "tcpseal/config.h"

#include "tcpseal/common.h"

#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#define MAX_VALUE 512

typedef struct {
    const char *section;
    const char *key;
    bool required;
    const char *default_value;
    char value[MAX_VALUE];
    bool seen;
} entry;

/* The schema: every allowed key with its default. */
static entry SCHEMA_TEMPLATE[] = {
    {"device", "role", true, NULL, "", false},
    {"device", "identity_key", true, NULL, "", false},
    {"device", "peer_public_key", true, NULL, "", false},
    {"control", "address", true, NULL, "", false},
    {"control", "port", false, "47100", "", false},
    {"control", "handshake_timeout", false, "5", "", false},
    {"dataplane", "encrypt_queue", false, "100", "", false},
    {"dataplane", "decrypt_queue", false, "101", "", false},
    {"dataplane", "peer_mtu", false, "1500", "", false},
    {"session", "rekey_interval", false, "240", "", false},
    {"session", "lifetime", false, "300", "", false},
    {"session", "max_packets", false, "200000", "", false},
    {"logging", "level", false, "info", "", false},
};
#define SCHEMA_SIZE (sizeof(SCHEMA_TEMPLATE) / sizeof(SCHEMA_TEMPLATE[0]))

static char *trim(char *s)
{
    while (isspace((unsigned char)*s)) {
        ++s;
    }
    char *end = s + strlen(s);
    while (end > s && isspace((unsigned char)end[-1])) {
        *--end = '\0';
    }
    return s;
}

/* Remove a comment: ';' or '#' at the start or preceded by whitespace. */
static void strip_comment(char *line)
{
    for (char *p = line; *p != '\0'; ++p) {
        if ((*p == ';' || *p == '#') && (p == line || isspace((unsigned char)p[-1]))) {
            *p = '\0';
            return;
        }
    }
}

static bool known_section(const char *name)
{
    for (size_t i = 0; i < SCHEMA_SIZE; ++i) {
        if (strcmp(SCHEMA_TEMPLATE[i].section, name) == 0) {
            return true;
        }
    }
    return false;
}

static entry *find(entry *schema, const char *section, const char *key)
{
    for (size_t i = 0; i < SCHEMA_SIZE; ++i) {
        if (strcmp(schema[i].section, section) == 0 && strcmp(schema[i].key, key) == 0) {
            return &schema[i];
        }
    }
    return NULL;
}

static const char *get(entry *schema, const char *section, const char *key)
{
    return find(schema, section, key)->value;
}

static int parse_long(entry *schema, const char *section, const char *key, long low, long high, long *out,
                      char *err)
{
    const char *text = get(schema, section, key);
    char *end = NULL;
    errno = 0;
    long value = strtol(text, &end, 10);
    if (errno != 0 || end == text || *end != '\0') {
        ts_set_error(err, "[%s] %s: '%s' is not an integer", section, key, text);
        return -1;
    }
    if (value < low || value > high) {
        ts_set_error(err, "[%s] %s: %ld is outside %ld..%ld", section, key, value, low, high);
        return -1;
    }
    *out = value;
    return 0;
}

static int parse_double(entry *schema, const char *section, const char *key, double low, double high,
                        double *out, char *err)
{
    const char *text = get(schema, section, key);
    char *end = NULL;
    errno = 0;
    double value = strtod(text, &end);
    if (errno != 0 || end == text || *end != '\0') {
        ts_set_error(err, "[%s] %s: '%s' is not a number", section, key, text);
        return -1;
    }
    if (value < low || value > high) {
        ts_set_error(err, "[%s] %s: %g is outside %g..%g", section, key, value, low, high);
        return -1;
    }
    *out = value;
    return 0;
}

static int resolve_path(const char *config_dir, const char *value, char *out, char *err)
{
    int n = value[0] == '/' ? snprintf(out, PATH_MAX, "%s", value)
                            : snprintf(out, PATH_MAX, "%s/%s", config_dir, value);
    if (n < 0 || n >= PATH_MAX) {
        ts_set_error(err, "path too long: %s", value);
        return -1;
    }
    return 0;
}

static int read_file(const char *path, entry *schema, char *err)
{
    FILE *f = fopen(path, "r");
    if (f == NULL) {
        ts_set_error(err, "configuration file not found: %s", path);
        return -1;
    }
    char line[1024];
    char section[64] = "";
    bool section_seen[8] = {false};
    static const char *const sections[] = {"device", "control", "dataplane", "session", "logging"};
    int number = 0;
    int result = 0;

    while (result == 0 && fgets(line, sizeof(line), f) != NULL) {
        ++number;
        strip_comment(line);
        char *text = trim(line);
        if (*text == '\0') {
            continue;
        }
        if (*text == '[') {
            char *close = strchr(text, ']');
            if (close == NULL || close[1] != '\0') {
                ts_set_error(err, "cannot parse %s line %d: bad section header", path, number);
                result = -1;
                break;
            }
            *close = '\0';
            (void)snprintf(section, sizeof(section), "%s", trim(text + 1));
            if (!known_section(section)) {
                ts_set_error(err, "unknown section [%s]", section);
                result = -1;
                break;
            }
            for (int i = 0; i < 5; ++i) {
                if (strcmp(sections[i], section) == 0) {
                    if (section_seen[i]) {
                        ts_set_error(err, "duplicate section [%s]", section);
                        result = -1;
                    }
                    section_seen[i] = true;
                }
            }
            continue;
        }
        char *equals = strchr(text, '=');
        if (equals == NULL || section[0] == '\0') {
            ts_set_error(err, "cannot parse %s line %d: expected 'key = value' inside a section", path,
                         number);
            result = -1;
            break;
        }
        *equals = '\0';
        char *key = trim(text);
        char *value = trim(equals + 1);
        for (char *p = key; *p != '\0'; ++p) {
            *p = (char)tolower((unsigned char)*p); /* keys are case-insensitive */
        }
        entry *e = find(schema, section, key);
        if (e == NULL) {
            ts_set_error(err, "unknown key '%s' in [%s]", key, section);
            result = -1;
        } else if (e->seen) {
            ts_set_error(err, "duplicate key '%s' in [%s]", key, section);
            result = -1;
        } else {
            e->seen = true;
            (void)snprintf(e->value, sizeof(e->value), "%s", value);
        }
    }
    (void)fclose(f);
    return result;
}

int ts_config_load(const char *path, ts_config *cfg, char *err)
{
    entry schema[SCHEMA_SIZE];
    memcpy(schema, SCHEMA_TEMPLATE, sizeof(schema));
    memset(cfg, 0, sizeof(*cfg));

    if (read_file(path, schema, err) != 0) {
        return -1;
    }
    for (size_t i = 0; i < SCHEMA_SIZE; ++i) {
        if (schema[i].value[0] == '\0') {
            if (schema[i].required) {
                ts_set_error(err, "missing required value [%s] %s", schema[i].section, schema[i].key);
                return -1;
            }
            (void)snprintf(schema[i].value, sizeof(schema[i].value), "%s", schema[i].default_value);
        }
    }

    const char *role = get(schema, "device", "role");
    if (strcasecmp(role, "device1") != 0 && strcasecmp(role, "device2") != 0) {
        ts_set_error(err, "[device] role must be 'device1' or 'device2'");
        return -1;
    }
    (void)snprintf(cfg->role, sizeof(cfg->role), "%s",
                   strcasecmp(role, "device1") == 0 ? "device1" : "device2");
    cfg->is_initiator = strcmp(cfg->role, "device1") == 0;

    char real_config[PATH_MAX];
    char config_dir[PATH_MAX];
    if (realpath(path, real_config) == NULL) {
        ts_set_error(err, "cannot resolve %s: %s", path, strerror(errno));
        return -1;
    }
    (void)snprintf(config_dir, sizeof(config_dir), "%s", real_config);
    char *slash = strrchr(config_dir, '/'); /* realpath() is absolute: always found */
    if (slash == config_dir) {
        slash[1] = '\0'; /* config file directly in "/" */
    } else if (slash != NULL) {
        *slash = '\0';
    }
    if (resolve_path(config_dir, get(schema, "device", "identity_key"), cfg->identity_key, err) != 0 ||
        resolve_path(config_dir, get(schema, "device", "peer_public_key"), cfg->peer_public_key, err) != 0) {
        return -1;
    }

    const char *address = get(schema, "control", "address");
    struct in_addr parsed;
    if (inet_pton(AF_INET, address, &parsed) != 1) {
        ts_set_error(err, "[control] address: '%s' is not an IPv4 address", address);
        return -1;
    }
    if (cfg->is_initiator && parsed.s_addr == 0) {
        ts_set_error(err, "[control] address on device1 must be Device2's real address");
        return -1;
    }
    /* inet_pton accepted it, so it is at most 15 characters long */
    (void)snprintf(cfg->control_address, sizeof(cfg->control_address), "%.15s", address);

    long number;
    double real;
    if (parse_long(schema, "control", "port", 1, 65535, &number, err) != 0) {
        return -1;
    }
    cfg->control_port = (uint16_t)number;
    if (parse_double(schema, "control", "handshake_timeout", 0.5, 60, &real, err) != 0) {
        return -1;
    }
    cfg->handshake_timeout = real;
    if (parse_long(schema, "dataplane", "encrypt_queue", 0, 65535, &number, err) != 0) {
        return -1;
    }
    cfg->encrypt_queue = (uint16_t)number;
    if (parse_long(schema, "dataplane", "decrypt_queue", 0, 65535, &number, err) != 0) {
        return -1;
    }
    cfg->decrypt_queue = (uint16_t)number;
    if (cfg->encrypt_queue == cfg->decrypt_queue) {
        ts_set_error(err, "[dataplane] encrypt_queue and decrypt_queue must differ");
        return -1;
    }
    if (parse_long(schema, "dataplane", "peer_mtu", 576, 65000, &number, err) != 0) {
        return -1;
    }
    cfg->peer_mtu = (uint32_t)number;
    if (parse_double(schema, "session", "rekey_interval", 1, 86400, &cfg->limits.rekey_after_seconds, err) !=
            0 ||
        parse_double(schema, "session", "lifetime", 2, 86400, &cfg->limits.lifetime_seconds, err) != 0) {
        return -1;
    }
    if (cfg->limits.rekey_after_seconds >= cfg->limits.lifetime_seconds) {
        ts_set_error(err, "[session] rekey_interval must be smaller than lifetime");
        return -1;
    }
    if (parse_long(schema, "session", "max_packets", 100, 10000000, &number, err) != 0) {
        return -1;
    }
    cfg->limits.max_packets = (uint64_t)number;
    cfg->log_level = ts_log_level_from_name(get(schema, "logging", "level"));
    if (cfg->log_level < 0) {
        ts_set_error(err, "[logging] level must be one of debug, info, warning, error");
        return -1;
    }
    return 0;
}
