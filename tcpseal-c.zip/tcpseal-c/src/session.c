/*
 * session.c - session keys, nonce sets, AES-GCM seal/open, session manager.
 */
#include "tcpseal/session.h"

#include <openssl/evp.h>
#include <openssl/hmac.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ------------------------------------------------------------ nonce set */
#define SLOT_SIZE 16
#define INITIAL_CAPACITY 1024

static size_t slot_index(const uint8_t nonce[TS_NONCE_LEN], size_t capacity)
{
    /* Nonces are HMAC outputs, i.e. already uniformly random. */
    uint64_t h;
    memcpy(&h, nonce, sizeof(h));
    return (size_t)(h & (capacity - 1));
}

static uint8_t *find_slot(uint8_t *slots, size_t capacity, const uint8_t nonce[TS_NONCE_LEN])
{
    size_t i = slot_index(nonce, capacity);
    for (;;) { /* linear probing; the table is never more than half full */
        uint8_t *slot = slots + i * SLOT_SIZE;
        if (slot[TS_NONCE_LEN] == 0 || memcmp(slot, nonce, TS_NONCE_LEN) == 0) {
            return slot;
        }
        i = (i + 1) & (capacity - 1);
    }
}

int ts_nonce_set_init(ts_nonce_set *set)
{
    set->slots = calloc(INITIAL_CAPACITY, SLOT_SIZE);
    set->capacity = INITIAL_CAPACITY;
    set->count = 0;
    return set->slots != NULL ? 0 : -1;
}

bool ts_nonce_set_contains(const ts_nonce_set *set, const uint8_t nonce[TS_NONCE_LEN])
{
    return find_slot(set->slots, set->capacity, nonce)[TS_NONCE_LEN] != 0;
}

static int grow(ts_nonce_set *set)
{
    size_t capacity = set->capacity * 2;
    uint8_t *slots = calloc(capacity, SLOT_SIZE);
    if (slots == NULL) {
        return -1;
    }
    for (size_t i = 0; i < set->capacity; ++i) {
        const uint8_t *old = set->slots + i * SLOT_SIZE;
        if (old[TS_NONCE_LEN] != 0) {
            memcpy(find_slot(slots, capacity, old), old, SLOT_SIZE);
        }
    }
    free(set->slots);
    set->slots = slots;
    set->capacity = capacity;
    return 0;
}

int ts_nonce_set_add(ts_nonce_set *set, const uint8_t nonce[TS_NONCE_LEN])
{
    if ((set->count + 1) * 2 > set->capacity && grow(set) != 0) {
        return -1;
    }
    uint8_t *slot = find_slot(set->slots, set->capacity, nonce);
    if (slot[TS_NONCE_LEN] != 0) {
        return 1;
    }
    memcpy(slot, nonce, TS_NONCE_LEN);
    slot[TS_NONCE_LEN] = 1;
    set->count++;
    return 0;
}

void ts_nonce_set_free(ts_nonce_set *set)
{
    free(set->slots);
    set->slots = NULL;
    set->capacity = set->count = 0;
}

/* ------------------------------------------------------------ session */
struct ts_session {
    char id[17];
    ts_direction_keys tx, rx;
    ts_limits limits;
    double created;
    uint64_t tx_count, rx_count;
    ts_nonce_set tx_used, rx_seen;
    EVP_CIPHER_CTX *tx_ctx, *rx_ctx;
};

ts_session *ts_session_new(const char *session_id, const ts_direction_keys *tx, const ts_direction_keys *rx,
                           const ts_limits *limits)
{
    ts_session *s = calloc(1, sizeof(*s));
    if (s == NULL) {
        return NULL;
    }
    (void)snprintf(s->id, sizeof(s->id), "%s", session_id);
    s->tx = *tx;
    s->rx = *rx;
    s->limits = *limits;
    s->created = ts_now();
    s->tx_ctx = EVP_CIPHER_CTX_new();
    s->rx_ctx = EVP_CIPHER_CTX_new();
    if (s->tx_ctx == NULL || s->rx_ctx == NULL || ts_nonce_set_init(&s->tx_used) != 0 ||
        ts_nonce_set_init(&s->rx_seen) != 0 ||
        /* Set cipher and key once; only the nonce changes per packet. */
        EVP_EncryptInit_ex(s->tx_ctx, EVP_aes_256_gcm(), NULL, s->tx.aes_key, NULL) != 1 ||
        EVP_DecryptInit_ex(s->rx_ctx, EVP_aes_256_gcm(), NULL, s->rx.aes_key, NULL) != 1) {
        ts_session_free(s);
        return NULL;
    }
    return s;
}

void ts_session_free(ts_session *s)
{
    if (s == NULL) {
        return;
    }
    EVP_CIPHER_CTX_free(s->tx_ctx);
    EVP_CIPHER_CTX_free(s->rx_ctx);
    ts_nonce_set_free(&s->tx_used);
    ts_nonce_set_free(&s->rx_seen);
    ts_secure_zero(s, sizeof(*s)); /* erase keys */
    free(s);
}

const char *ts_session_id(const ts_session *s) { return s->id; }
uint64_t ts_session_tx_count(const ts_session *s) { return s->tx_count; }
uint64_t ts_session_rx_count(const ts_session *s) { return s->rx_count; }
double ts_session_age(const ts_session *s, double now) { return now - s->created; }
void ts_session_set_created(ts_session *s, double created) { s->created = created; }

bool ts_session_expired(const ts_session *s, double now)
{
    return ts_session_age(s, now) >= s->limits.lifetime_seconds || s->tx_count >= s->limits.max_packets ||
           s->rx_count >= s->limits.max_packets;
}

bool ts_session_needs_rekey(const ts_session *s, double now)
{
    uint64_t soft = s->limits.max_packets / 10 * 8; /* 80 % */
    return ts_session_age(s, now) >= s->limits.rekey_after_seconds || s->tx_count >= soft ||
           s->rx_count >= soft;
}

void ts_derive_nonce(const uint8_t nonce_key[TS_KEY_LEN], const uint8_t *header, size_t header_len,
                     uint8_t nonce[TS_NONCE_LEN])
{
    uint8_t mac[32];
    unsigned int mac_len = sizeof(mac);
    (void)HMAC(EVP_sha256(), nonce_key, TS_KEY_LEN, header, header_len, mac, &mac_len);
    memcpy(nonce, mac, TS_NONCE_LEN);
    ts_secure_zero(mac, sizeof(mac));
}

int ts_session_seal(ts_session *s, const uint8_t *aad, size_t aad_len, const uint8_t *plaintext,
                    size_t plaintext_len, uint8_t *out)
{
    uint8_t nonce[TS_NONCE_LEN];
    int len = 0;

    if (ts_session_expired(s, ts_now())) {
        return TS_ERR_EXPIRED;
    }
    ts_derive_nonce(s->tx.nonce_key, aad, aad_len, nonce);
    /* Reserve the nonce BEFORE encrypting so it can never be used twice. */
    int added = ts_nonce_set_add(&s->tx_used, nonce);
    if (added == 1) {
        return TS_ERR_NONCE_REUSE;
    }
    if (added < 0) {
        return TS_ERR_INTERNAL;
    }
    s->tx_count++;

    if (EVP_EncryptInit_ex(s->tx_ctx, NULL, NULL, NULL, nonce) != 1 ||
        EVP_EncryptUpdate(s->tx_ctx, NULL, &len, aad, (int)aad_len) != 1 ||
        (plaintext_len > 0 && EVP_EncryptUpdate(s->tx_ctx, out, &len, plaintext, (int)plaintext_len) != 1) ||
        EVP_EncryptFinal_ex(s->tx_ctx, out + plaintext_len, &len) != 1 ||
        EVP_CIPHER_CTX_ctrl(s->tx_ctx, EVP_CTRL_GCM_GET_TAG, TS_TAG_LEN, out + plaintext_len) != 1) {
        return TS_ERR_INTERNAL;
    }
    return TS_OK;
}

int ts_session_open(ts_session *s, const uint8_t *aad, size_t aad_len, const uint8_t *protected_data,
                    size_t protected_len, uint8_t *out)
{
    uint8_t nonce[TS_NONCE_LEN];
    uint8_t tag[TS_TAG_LEN];
    int len = 0;

    if (protected_len < TS_TAG_LEN) {
        return TS_ERR_AUTH;
    }
    size_t ct_len = protected_len - TS_TAG_LEN;
    ts_derive_nonce(s->rx.nonce_key, aad, aad_len, nonce);
    if (ts_nonce_set_contains(&s->rx_seen, nonce)) {
        return TS_ERR_REPLAY;
    }
    memcpy(tag, protected_data + ct_len, TS_TAG_LEN);
    if (EVP_DecryptInit_ex(s->rx_ctx, NULL, NULL, NULL, nonce) != 1 ||
        EVP_DecryptUpdate(s->rx_ctx, NULL, &len, aad, (int)aad_len) != 1 ||
        (ct_len > 0 && EVP_DecryptUpdate(s->rx_ctx, out, &len, protected_data, (int)ct_len) != 1) ||
        EVP_CIPHER_CTX_ctrl(s->rx_ctx, EVP_CTRL_GCM_SET_TAG, TS_TAG_LEN, tag) != 1) {
        return TS_ERR_INTERNAL;
    }
    if (EVP_DecryptFinal_ex(s->rx_ctx, out + ct_len, &len) != 1) {
        ts_secure_zero(out, ct_len); /* never release unauthenticated plaintext */
        return TS_ERR_AUTH;
    }
    if (ts_nonce_set_add(&s->rx_seen, nonce) < 0) {
        return TS_ERR_INTERNAL;
    }
    s->rx_count++;
    return TS_OK;
}

/* ------------------------------------------------------------ manager */
void ts_manager_init(ts_manager *m, double grace_seconds)
{
    memset(m, 0, sizeof(*m));
    (void)pthread_mutex_init(&m->lock, NULL);
    m->grace_seconds = grace_seconds;
}

void ts_manager_destroy(ts_manager *m)
{
    ts_manager_clear(m);
    (void)pthread_mutex_destroy(&m->lock);
}

void ts_manager_lock(ts_manager *m) { (void)pthread_mutex_lock(&m->lock); }
void ts_manager_unlock(ts_manager *m) { (void)pthread_mutex_unlock(&m->lock); }

void ts_manager_add_pending(ts_manager *m, ts_session *s)
{
    ts_manager_lock(m);
    if (m->pending != NULL && m->pending != m->current) {
        ts_session_free(m->pending);
    }
    m->pending = s;
    ts_manager_unlock(m);
}

void ts_manager_discard_pending(ts_manager *m)
{
    ts_manager_lock(m);
    if (m->pending != NULL && m->pending != m->current) {
        ts_session_free(m->pending);
    }
    m->pending = NULL;
    ts_manager_unlock(m);
}

void ts_manager_install(ts_manager *m, ts_session *s)
{
    ts_manager_lock(m);
    if (m->current != NULL && m->current != s) {
        ts_session_free(m->previous);
        m->previous = m->current;
        m->previous_until = ts_now() + m->grace_seconds;
    }
    m->current = s;
    if (m->pending == s) {
        m->pending = NULL;
    }
    ts_manager_unlock(m);
}

void ts_manager_clear(ts_manager *m)
{
    ts_manager_lock(m);
    if (m->pending != m->current) {
        ts_session_free(m->pending);
    }
    ts_session_free(m->current);
    ts_session_free(m->previous);
    m->current = m->previous = m->pending = NULL;
    ts_manager_unlock(m);
}

ts_session *ts_manager_tx_locked(ts_manager *m, double now)
{
    if (m->current == NULL || ts_session_expired(m->current, now)) {
        return NULL;
    }
    return m->current;
}

size_t ts_manager_rx_locked(ts_manager *m, double now, ts_session *out[3])
{
    if (m->previous != NULL && now >= m->previous_until) {
        ts_session_free(m->previous); /* grace period over: forget old keys */
        m->previous = NULL;
    }
    ts_session *candidates[3] = {m->pending, m->current, m->previous};
    size_t n = 0;
    for (size_t i = 0; i < 3; ++i) {
        if (candidates[i] != NULL && !ts_session_expired(candidates[i], now)) {
            out[n++] = candidates[i];
        }
    }
    return n;
}

bool ts_manager_current_info(ts_manager *m, double now, ts_session_info *info)
{
    bool found = false;
    ts_manager_lock(m);
    if (m->current != NULL) {
        memcpy(info->id, m->current->id, sizeof(info->id));
        info->age = ts_session_age(m->current, now);
        info->tx = m->current->tx_count;
        info->rx = m->current->rx_count;
        info->needs_rekey = ts_session_needs_rekey(m->current, now);
        found = true;
    }
    ts_manager_unlock(m);
    return found;
}
