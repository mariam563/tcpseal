/*
 * daemon.c - gateway daemon.
 *
 * Threads: main thread = NFQUEUE packet loop, control thread = handshakes.
 * Fail-closed: the firewall rules have no "bypass", so selected packets are
 * dropped by the kernel while the daemon is not running, and the daemon
 * drops them itself while it has no valid session.
 */
#include "tcpseal/daemon.h"

#include "tcpseal/control.h"
#include "tcpseal/keys.h"

#include <errno.h>
#include <pthread.h>
#include <signal.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define STATS_INTERVAL_SECONDS 10.0
static const char LOG[] = "tcpseal.daemon";
static atomic_int g_stop;

int ts_processor_handle(ts_processor *p, const ts_queued_packet *packet, const uint8_t **out, size_t *out_len)
{
    int encrypt = packet->queue == p->config->encrypt_queue;
    const char *direction = encrypt ? "encrypt" : "decrypt";
    if (packet->payload == NULL) {
        if (encrypt) {
            p->stats.encrypt_no_payload++;
        } else {
            p->stats.decrypt_no_payload++;
        }
        return 0;
    }
    int reason = encrypt
                     ? ts_protect(packet->payload, packet->payload_len, p->sessions, p->config->peer_mtu,
                                  p->buffer, out_len)
                     : ts_unprotect(packet->payload, packet->payload_len, p->sessions, p->buffer, out_len);
    if (reason == TS_PASS) {
        if (encrypt) {
            p->stats.encrypted++;
        } else {
            p->stats.decrypted++;
        }
        ts_log(TS_LOG_DEBUG, LOG, "%s: %zu -> %zu bytes", direction, packet->payload_len, *out_len);
        *out = p->buffer;
        return 1;
    }
    uint64_t *drops = encrypt ? p->stats.encrypt_drops : p->stats.decrypt_drops;
    unsigned *warned = encrypt ? &p->warned_encrypt : &p->warned_decrypt;
    drops[reason]++;
    if ((*warned & (1u << reason)) == 0) { /* warn once per reason, then only count */
        *warned |= 1u << reason;
        ts_log(TS_LOG_WARNING, LOG, "%s: dropping packet (%s); further drops are counted in stats", direction,
               ts_drop_reason_name(reason));
    } else {
        ts_log(TS_LOG_DEBUG, LOG, "%s: dropping packet (%s)", direction, ts_drop_reason_name(reason));
    }
    return 0;
}

/* Append "key": value to a JSON object being built (keys added in sorted order). */
static void json_add(char *out, size_t size, const char *key, uint64_t value)
{
    if (value == 0) {
        return;
    }
    size_t len = strlen(out);
    (void)snprintf(out + len, size - len, "%s\"%s\": %llu", len > 1 ? ", " : "", key,
                   (unsigned long long)value);
}

typedef struct {
    char key[48];
    uint64_t value;
} kv;

static int kv_compare(const void *a, const void *b)
{
    return strcmp(((const kv *)a)->key, ((const kv *)b)->key);
}

void ts_stats_json(const ts_stats *stats, char *out, size_t size)
{
    kv items[2 * TS_DROP_COUNT + 6];
    size_t n = 0;
    (void)snprintf(items[n].key, sizeof(items[n].key), "encrypted");
    items[n++].value = stats->encrypted;
    (void)snprintf(items[n].key, sizeof(items[n].key), "decrypted");
    items[n++].value = stats->decrypted;
    (void)snprintf(items[n].key, sizeof(items[n].key), "encrypt_drop_no_payload");
    items[n++].value = stats->encrypt_no_payload;
    (void)snprintf(items[n].key, sizeof(items[n].key), "decrypt_drop_no_payload");
    items[n++].value = stats->decrypt_no_payload;
    (void)snprintf(items[n].key, sizeof(items[n].key), "kernel_queue_overflow");
    items[n++].value = stats->kernel_queue_overflow;
    for (int r = 1; r < TS_DROP_COUNT; ++r) {
        (void)snprintf(items[n].key, sizeof(items[n].key), "encrypt_drop_%s", ts_drop_reason_name(r));
        items[n++].value = stats->encrypt_drops[r];
        (void)snprintf(items[n].key, sizeof(items[n].key), "decrypt_drop_%s", ts_drop_reason_name(r));
        items[n++].value = stats->decrypt_drops[r];
    }
    qsort(items, n, sizeof(items[0]), kv_compare);
    (void)snprintf(out, size, "{");
    for (size_t i = 0; i < n; ++i) {
        json_add(out, size, items[i].key, items[i].value);
    }
    size_t len = strlen(out);
    (void)snprintf(out + len, size - len, "}");
}

typedef struct {
    ts_processor *processor;
    ts_nfqueue *queue;
} loop_ctx;

static void on_packet(void *arg, const ts_queued_packet *packet)
{
    loop_ctx *ctx = arg;
    const uint8_t *replacement = NULL;
    size_t replacement_len = 0;
    int accept = ts_processor_handle(ctx->processor, packet, &replacement, &replacement_len);
    (void)ts_nfq_verdict(ctx->queue, packet->queue, packet->packet_id, accept, accept ? replacement : NULL,
                         replacement_len);
}

static void on_signal(int signum)
{
    (void)signum;
    atomic_store(&g_stop, 1); /* lock-free atomics are async-signal-safe */
}

int ts_daemon_run(const ts_config *config)
{
    char err[TS_ERR_LEN];
    char own_fp[17], peer_fp[17], json[1024];
    int exit_code = 1;

    EVP_PKEY *identity = ts_load_private(config->identity_key, err);
    EVP_PKEY *peer = identity != NULL ? ts_load_public(config->peer_public_key, err) : NULL;
    if (identity == NULL || peer == NULL) {
        (void)fprintf(stderr, "error: %s\n", err);
        EVP_PKEY_free(identity);
        return 2;
    }
    ts_fingerprint(identity, own_fp);
    ts_fingerprint(peer, peer_fp);
    ts_log(TS_LOG_INFO, LOG, "starting as %s; own key %s, pinned peer key %s", config->role, own_fp, peer_fp);

    struct sigaction action;
    memset(&action, 0, sizeof(action));
    action.sa_handler = on_signal;
    (void)sigaction(SIGINT, &action, NULL);
    (void)sigaction(SIGTERM, &action, NULL);
    atomic_store(&g_stop, 0);

    ts_processor *processor = calloc(1, sizeof(*processor)); /* 64 KiB buffer: not on the stack */
    ts_manager sessions;
    ts_nfqueue queue;
    ts_channel channel;
    pthread_t control_thread;
    if (processor == NULL) {
        (void)fprintf(stderr, "error: out of memory\n");
        EVP_PKEY_free(identity);
        EVP_PKEY_free(peer);
        return 1;
    }
    ts_manager_init(&sessions, TS_PREVIOUS_GRACE_SECONDS);
    processor->config = config;
    processor->sessions = &sessions;

    /* Open the queues first: if that fails (no root), nothing else starts. */
    uint16_t queues[2] = {config->encrypt_queue, config->decrypt_queue};
    int code = ts_nfq_open(&queue, queues, 2, err);
    if (code != 0) {
        (void)fprintf(stderr, "error: %s (are you root? is nfnetlink_queue available?)\n", err);
        exit_code = 3;
        goto out_keys;
    }
    ts_log(TS_LOG_INFO, LOG, "bound to NFQUEUE encrypt=%u decrypt=%u", config->encrypt_queue,
           config->decrypt_queue);

    ts_channel_init(&channel, config->control_address, config->control_port, identity, peer, &sessions,
                    &config->limits, config->handshake_timeout, &g_stop);
    if (!config->is_initiator && ts_responder_listen(&channel, err) != 0) {
        (void)fprintf(stderr, "error: %s\n", err);
        goto out_queue;
    }
    if (pthread_create(&control_thread, NULL, config->is_initiator ? ts_initiator_run : ts_responder_run,
                       &channel) != 0) {
        (void)fprintf(stderr, "error: cannot start control thread\n");
        goto out_queue;
    }

    loop_ctx ctx = {processor, &queue};
    double next_stats = ts_now() + STATS_INTERVAL_SECONDS;
    exit_code = 0;
    while (!atomic_load(&g_stop)) {
        if (ts_nfq_receive(&queue, 500, on_packet, &ctx) != 0) {
            ts_log(TS_LOG_ERROR, LOG, "NFQUEUE receive failed: %s", strerror(errno));
            exit_code = 1;
            break;
        }
        if (ts_now() >= next_stats) {
            ts_session_info info;
            next_stats += STATS_INTERVAL_SECONDS;
            processor->stats.kernel_queue_overflow = queue.overflows;
            ts_stats_json(&processor->stats, json, sizeof(json));
            ts_log(TS_LOG_INFO, LOG, "stats session=%s %s",
                   ts_manager_current_info(&sessions, ts_now(), &info) ? info.id : "none", json);
        }
    }
    atomic_store(&g_stop, 1);
    (void)pthread_join(control_thread, NULL);
out_queue:
    ts_nfq_close(&queue);
out_keys:
    ts_manager_destroy(&sessions); /* frees sessions and erases their keys */
    ts_stats_json(&processor->stats, json, sizeof(json));
    ts_log(TS_LOG_INFO, LOG, "final stats %s", json);
    ts_secure_zero(processor, sizeof(*processor)); /* last packet may be plaintext */
    free(processor);
    EVP_PKEY_free(identity);
    EVP_PKEY_free(peer);
    return exit_code;
}
