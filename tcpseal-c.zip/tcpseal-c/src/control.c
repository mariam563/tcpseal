/*
 * control.c - handshake transport, rekeying and reconnection.
 */
#include "tcpseal/control.h"

#include "tcpseal/handshake.h"

#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <poll.h>
#include <string.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>

#define POLL_MS 500
static const char LOG[] = "tcpseal.control";

void ts_channel_init(ts_channel *c, const char *address, uint16_t port, EVP_PKEY *identity,
                     EVP_PKEY *peer_identity, ts_manager *sessions, const ts_limits *limits, double timeout,
                     atomic_int *stop)
{
    memset(c, 0, sizeof(*c));
    (void)snprintf(c->address, sizeof(c->address), "%s", address);
    c->port = port;
    c->identity = identity;
    c->peer_identity = peer_identity;
    c->sessions = sessions;
    c->limits = *limits;
    c->timeout = timeout;
    c->stop = stop;
    c->listen_fd = -1;
    atomic_init(&c->handshakes_completed, 0);
    atomic_init(&c->handshakes_failed, 0);
}

static void sleep_interruptible(const ts_channel *c, double seconds)
{
    double end = ts_now() + seconds;
    while (!atomic_load(c->stop) && ts_now() < end) {
        struct timespec ts = {0, 100 * 1000 * 1000};
        (void)nanosleep(&ts, NULL);
    }
}

/* ------------------------------------------------------------ framing */
static void set_timeout(int fd, double seconds)
{
    struct timeval tv = {(time_t)seconds, (suseconds_t)((seconds - (double)(time_t)seconds) * 1e6)};
    (void)setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    (void)setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
}

static int send_all(int fd, const uint8_t *data, size_t len)
{
    while (len > 0) {
        ssize_t n = send(fd, data, len, MSG_NOSIGNAL);
        if (n < 0 && errno == EINTR) {
            continue;
        }
        if (n <= 0) {
            return -1;
        }
        data += n;
        len -= (size_t)n;
    }
    return 0;
}

static int recv_all(int fd, uint8_t *data, size_t len)
{
    while (len > 0) {
        ssize_t n = recv(fd, data, len, 0);
        if (n < 0 && errno == EINTR) {
            continue;
        }
        if (n <= 0) {
            return n == 0 ? -2 : -1; /* -2: peer closed the connection */
        }
        data += n;
        len -= (size_t)n;
    }
    return 0;
}

static int send_message(int fd, const uint8_t *msg, size_t len)
{
    uint8_t prefix[2];
    ts_put16(prefix, (uint16_t)len);
    return send_all(fd, prefix, 2) == 0 && send_all(fd, msg, len) == 0 ? 0 : -1;
}

/* Returns message length, -1 on error/timeout, -2 if the peer closed. */
static int recv_message(int fd, uint8_t *buf, size_t cap, char *err)
{
    uint8_t prefix[2];
    int r = recv_all(fd, prefix, 2);
    if (r == -2) {
        ts_set_error(err, "control connection closed by peer");
        return r;
    }
    if (r != 0) {
        ts_set_error(err, "control receive failed: %s", strerror(errno));
        return r;
    }
    size_t len = ts_get16(prefix);
    if (len == 0 || len > cap) {
        ts_set_error(err, "control message length %zu is invalid", len);
        return -1;
    }
    if (recv_all(fd, buf, len) != 0) {
        ts_set_error(err, "control message truncated");
        return -1;
    }
    return (int)len;
}

static ts_session *make_session(const ts_session_keys *keys, const ts_limits *limits)
{
    return ts_session_new(keys->session_id, &keys->tx, &keys->rx, limits);
}

/* ------------------------------------------------------------ Device1 */
static int initiator_handshake(ts_channel *c, int fd, char *err)
{
    ts_handshake hs;
    ts_session_keys keys;
    uint8_t out[TS_HS_MAX_LEN];
    uint8_t in[TS_HS_MAX_LEN];
    int result = -1;

    if (ts_handshake_init(&hs, c->identity, c->peer_identity, err) != 0) {
        return -1;
    }
    int n;
    if (ts_initiator_hello(&hs, out) != 0 || send_message(fd, out, TS_HS_HELLO_LEN) != 0) {
        ts_set_error(err, "cannot send hello");
    } else if ((n = recv_message(fd, in, sizeof(in), err)) > 0 &&
               ts_initiator_finish(&hs, in, (size_t)n, out, &keys, err) == 0) {
        ts_session *session = make_session(&keys, &c->limits);
        if (session == NULL) {
            ts_set_error(err, "out of memory");
        } else {
            /* Device2 may use the new keys as soon as it verified M3, i.e.
             * before we receive M4: be able to decrypt already. */
            ts_manager_add_pending(c->sessions, session);
            if (send_message(fd, out, TS_HS_FINISH_LEN) == 0 &&
                (n = recv_message(fd, in, sizeof(in), err)) > 0 &&
                ts_initiator_confirm(&hs, in, (size_t)n, err) == 0) {
                ts_manager_install(c->sessions, session); /* now also used to encrypt */
                int count = atomic_fetch_add(&c->handshakes_completed, 1) + 1;
                ts_log(TS_LOG_INFO, LOG, "session %s established (handshake #%d)", keys.session_id, count);
                result = 0;
            } else {
                ts_manager_discard_pending(c->sessions);
            }
        }
    }
    ts_secure_zero(&keys, sizeof(keys));
    ts_handshake_clear(&hs);
    return result;
}

static int peer_closed(int fd)
{
    struct pollfd pfd = {.fd = fd, .events = POLLIN};
    if (poll(&pfd, 1, 0) <= 0) {
        return 0;
    }
    uint8_t byte;
    return recv(fd, &byte, 1, MSG_PEEK | MSG_DONTWAIT) == 0 || (pfd.revents & (POLLERR | POLLHUP));
}

static int connect_to(const ts_channel *c, char *err)
{
    struct sockaddr_in addr = {.sin_family = AF_INET, .sin_port = htons(c->port)};
    (void)inet_pton(AF_INET, c->address, &addr.sin_addr);
    int fd = socket(AF_INET, SOCK_STREAM | SOCK_CLOEXEC, 0);
    if (fd < 0) {
        ts_set_error(err, "socket: %s", strerror(errno));
        return -1;
    }
    set_timeout(fd, c->timeout);
    if (connect(fd, (struct sockaddr *)&addr, sizeof(addr)) != 0) {
        ts_set_error(err, "connect to %s:%u: %s", c->address, c->port, strerror(errno));
        (void)close(fd);
        return -1;
    }
    return fd;
}

void *ts_initiator_run(void *arg)
{
    ts_channel *c = arg;
    double backoff = 1.0;
    char err[TS_ERR_LEN];

    while (!atomic_load(c->stop)) {
        int fd = connect_to(c, err);
        if (fd >= 0) {
            ts_log(TS_LOG_INFO, LOG, "control connection to %s:%u open", c->address, c->port);
            int ok = initiator_handshake(c, fd, err) == 0;
            if (ok) {
                backoff = 1.0;
            }
            while (ok && !atomic_load(c->stop)) {
                ts_session_info info = {0};
                if (!ts_manager_current_info(c->sessions, ts_now(), &info) || info.needs_rekey) {
                    ts_log(TS_LOG_INFO, LOG, "rekey due (age=%.0fs, tx=%llu, rx=%llu)", info.age,
                           (unsigned long long)info.tx, (unsigned long long)info.rx);
                    ok = initiator_handshake(c, fd, err) == 0;
                    continue;
                }
                if (peer_closed(fd)) {
                    ts_set_error(err, "Device2 closed the control connection");
                    break;
                }
                sleep_interruptible(c, POLL_MS / 1000.0);
            }
            (void)close(fd);
            if (atomic_load(c->stop)) {
                break;
            }
        }
        atomic_fetch_add(&c->handshakes_failed, 1);
        ts_log(TS_LOG_WARNING, LOG, "handshake/control failure: %s; retrying in %.0fs", err, backoff);
        sleep_interruptible(c, backoff);
        backoff = backoff * 2 > TS_MAX_BACKOFF_SECONDS ? TS_MAX_BACKOFF_SECONDS : backoff * 2;
    }
    return NULL;
}

/* ------------------------------------------------------------ Device2 */
int ts_responder_listen(ts_channel *c, char *err)
{
    struct sockaddr_in addr = {.sin_family = AF_INET, .sin_port = htons(c->port)};
    int one = 1;
    (void)inet_pton(AF_INET, c->address, &addr.sin_addr);
    c->listen_fd = socket(AF_INET, SOCK_STREAM | SOCK_CLOEXEC, 0);
    if (c->listen_fd < 0 || setsockopt(c->listen_fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one)) != 0 ||
        bind(c->listen_fd, (struct sockaddr *)&addr, sizeof(addr)) != 0 || listen(c->listen_fd, 4) != 0) {
        ts_set_error(err, "cannot listen on %s:%u: %s", c->address, c->port, strerror(errno));
        if (c->listen_fd >= 0) {
            (void)close(c->listen_fd);
        }
        c->listen_fd = -1;
        return -1;
    }
    socklen_t len = sizeof(addr);
    (void)getsockname(c->listen_fd, (struct sockaddr *)&addr, &len);
    c->port = ntohs(addr.sin_port);
    return 0;
}

/* Answer one handshake whose first message (len bytes) is in hello. */
static int responder_handshake(ts_channel *c, int fd, const uint8_t *hello, size_t len, char *err)
{
    ts_handshake hs;
    ts_session_keys keys;
    uint8_t out[TS_HS_MAX_LEN];
    uint8_t in[TS_HS_MAX_LEN];
    int result = -1;
    int n;

    if (ts_handshake_init(&hs, c->identity, c->peer_identity, err) != 0) {
        return -1;
    }
    if (ts_responder_reply(&hs, hello, len, out, err) == 0 && send_message(fd, out, TS_HS_REPLY_LEN) == 0 &&
        (n = recv_message(fd, in, sizeof(in), err)) > 0 &&
        ts_responder_confirm(&hs, in, (size_t)n, out, &keys, err) == 0) {
        ts_session *session = make_session(&keys, &c->limits);
        if (session != NULL) {
            /* Install BEFORE sending M4: Device1 switches to the new keys only
             * after M4, so we are guaranteed to be ready for its packets. */
            ts_manager_install(c->sessions, session);
            if (send_message(fd, out, TS_HS_CONFIRM_LEN) == 0) {
                int count = atomic_fetch_add(&c->handshakes_completed, 1) + 1;
                ts_log(TS_LOG_INFO, LOG, "session %s established (handshake #%d)", keys.session_id, count);
                result = 0;
            }
        }
    }
    ts_secure_zero(&keys, sizeof(keys));
    ts_handshake_clear(&hs);
    return result;
}

void *ts_responder_run(void *arg)
{
    ts_channel *c = arg;
    int conn = -1;
    char peer[INET_ADDRSTRLEN] = "?";
    char err[TS_ERR_LEN];
    uint8_t buf[TS_HS_MAX_LEN];

    ts_log(TS_LOG_INFO, LOG, "waiting for Device1 on control port %u", c->port);
    while (!atomic_load(c->stop)) {
        struct pollfd pfd[2] = {{.fd = c->listen_fd, .events = POLLIN}, {.fd = conn, .events = POLLIN}};
        if (poll(pfd, conn >= 0 ? 2 : 1, POLL_MS) <= 0) {
            continue;
        }
        if (pfd[0].revents & POLLIN) {
            struct sockaddr_in from;
            socklen_t from_len = sizeof(from);
            int fd = accept4(c->listen_fd, (struct sockaddr *)&from, &from_len, SOCK_CLOEXEC);
            if (fd >= 0) {
                if (conn >= 0) {
                    (void)close(conn); /* the newest connection wins (e.g. Device1 restarted) */
                }
                conn = fd;
                (void)inet_ntop(AF_INET, &from.sin_addr, peer, sizeof(peer));
                set_timeout(conn, c->timeout);
                ts_log(TS_LOG_INFO, LOG, "control connection from %s", peer);
            }
            continue;
        }
        if (conn >= 0 && (pfd[1].revents & (POLLIN | POLLHUP | POLLERR))) {
            int n = recv_message(conn, buf, sizeof(buf), err);
            if (n == -2) {
                ts_log(TS_LOG_INFO, LOG, "control connection from %s closed", peer);
            } else if (n < 0 || responder_handshake(c, conn, buf, (size_t)n, err) != 0) {
                atomic_fetch_add(&c->handshakes_failed, 1);
                ts_log(TS_LOG_WARNING, LOG, "handshake with %s failed: %s", peer, err);
            } else {
                continue; /* keep the connection for the next rekey */
            }
            (void)close(conn);
            conn = -1;
        }
    }
    if (conn >= 0) {
        (void)close(conn);
    }
    (void)close(c->listen_fd);
    c->listen_fd = -1;
    return NULL;
}
