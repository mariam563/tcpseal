/*
 * packet.c - IPv4/TCP parsing, checksums, rebuilding and canonical header.
 */
#include "tcpseal/packet.h"

#include "tcpseal/common.h"

#include <string.h>

#define IP_TOS 1
#define IP_TOTAL_LENGTH 2
#define IP_FLAGS_FRAGMENT 6
#define IP_TTL 8
#define IP_PROTOCOL 9
#define IP_CHECKSUM 10
#define TCP_CHECKSUM 16
#define IPPROTO_TCP_NUMBER 6
#define FLAG_MORE_FRAGMENTS 0x2000u
#define FRAGMENT_OFFSET_MASK 0x1FFFu
#define ECN_MASK 0x03u

int ts_packet_parse(const uint8_t *data, size_t len, ts_packet *out, char *err)
{
    if (len < 20) {
        ts_set_error(err, "packet shorter than an IPv4 header");
        return -1;
    }
    if ((data[0] >> 4) != 4) {
        ts_set_error(err, "not an IPv4 packet");
        return -1;
    }
    size_t ihl = (size_t)(data[0] & 0x0F) * 4;
    if (ihl < 20 || len < ihl) {
        ts_set_error(err, "invalid IPv4 header length");
        return -1;
    }
    size_t total = ts_get16(data + IP_TOTAL_LENGTH);
    if (total < ihl + 20 || total > len) {
        ts_set_error(err, "invalid IPv4 total length");
        return -1;
    }
    if (data[IP_PROTOCOL] != IPPROTO_TCP_NUMBER) {
        ts_set_error(err, "not a TCP packet");
        return -1;
    }
    if ((ts_get16(data + IP_FLAGS_FRAGMENT) & (FLAG_MORE_FRAGMENTS | FRAGMENT_OFFSET_MASK)) != 0) {
        ts_set_error(err, "IPv4 fragments are not supported");
        return -1;
    }
    size_t tcp_len = (size_t)(data[ihl + 12] >> 4) * 4;
    if (tcp_len < 20 || ihl + tcp_len > total) {
        ts_set_error(err, "invalid TCP header length");
        return -1;
    }
    out->data = data;
    out->ip_len = ihl;
    out->tcp_len = tcp_len;
    out->payload_len = total - ihl - tcp_len; /* bytes after total (padding) are ignored */
    return 0;
}

/* Add 16-bit big-endian words to a 32-bit accumulator. */
static uint32_t sum_words(uint32_t sum, const uint8_t *data, size_t len)
{
    size_t i = 0;
    for (; i + 1 < len; i += 2) {
        sum += (uint32_t)((data[i] << 8) | data[i + 1]);
    }
    if (i < len) {
        sum += (uint32_t)(data[i] << 8); /* odd length: pad with a zero byte */
    }
    return sum;
}

static uint16_t fold(uint32_t sum)
{
    while (sum >> 16) {
        sum = (sum & 0xFFFFu) + (sum >> 16);
    }
    return (uint16_t)(~sum & 0xFFFFu);
}

uint16_t ts_internet_checksum(const uint8_t *data, size_t len) { return fold(sum_words(0, data, len)); }

uint16_t ts_tcp_checksum(const uint8_t *ip_header, const uint8_t *segment, size_t segment_len)
{
    uint8_t pseudo[12];
    memcpy(pseudo, ip_header + 12, 8); /* source and destination address */
    pseudo[8] = 0;
    pseudo[9] = IPPROTO_TCP_NUMBER;
    ts_put16(pseudo + 10, (uint16_t)segment_len);
    return fold(sum_words(sum_words(0, pseudo, sizeof(pseudo)), segment, segment_len));
}

void ts_packet_finalize(uint8_t *pkt, size_t ip_len, size_t total_len)
{
    ts_put16(pkt + IP_TOTAL_LENGTH, (uint16_t)total_len);
    ts_put16(pkt + IP_CHECKSUM, 0);
    ts_put16(pkt + IP_CHECKSUM, ts_internet_checksum(pkt, ip_len));
    ts_put16(pkt + ip_len + TCP_CHECKSUM, 0);
    ts_put16(pkt + ip_len + TCP_CHECKSUM, ts_tcp_checksum(pkt, pkt + ip_len, total_len - ip_len));
}

int ts_packet_build(const uint8_t *headers, size_t ip_len, size_t tcp_len, const uint8_t *payload,
                    size_t payload_len, uint8_t *out, size_t out_cap, size_t *out_len)
{
    size_t total = ip_len + tcp_len + payload_len;
    if (total > TS_MAX_IPV4_PACKET || total > out_cap) {
        return -1;
    }
    memmove(out, headers, ip_len + tcp_len);
    if (payload_len > 0) {
        memmove(out + ip_len + tcp_len, payload, payload_len);
    }
    ts_packet_finalize(out, ip_len, total);
    *out_len = total;
    return 0;
}

bool ts_packet_checksums_valid(const uint8_t *data, size_t len)
{
    ts_packet p;
    char err[TS_ERR_LEN];
    if (ts_packet_parse(data, len, &p, err) != 0) {
        return false;
    }
    if (ts_internet_checksum(data, p.ip_len) != 0) {
        return false;
    }
    return ts_tcp_checksum(data, data + p.ip_len, p.tcp_len + p.payload_len) == 0;
}

size_t ts_canonical_header(const ts_packet *p, size_t plaintext_len, uint8_t *out)
{
    size_t headers = ts_packet_headers_len(p);
    memcpy(out, p->data, headers);
    out[IP_TOS] &= (uint8_t)~ECN_MASK;
    ts_put16(out + IP_TOTAL_LENGTH, (uint16_t)(headers + plaintext_len));
    out[IP_TTL] = 0;
    ts_put16(out + IP_CHECKSUM, 0);
    ts_put16(out + p->ip_len + TCP_CHECKSUM, 0);
    return headers;
}
