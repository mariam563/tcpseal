/*
 * handshake.c - X25519 + Ed25519 authenticated key exchange with HKDF.
 * See handshake.h for the message layout and key schedule.
 */
#include "tcpseal/handshake.h"

#include <openssl/core_names.h>
#include <openssl/crypto.h>
#include <openssl/hmac.h>
#include <openssl/kdf.h>
#include <openssl/params.h>
#include <openssl/rand.h>

#include <stdio.h>
#include <string.h>

#define MSG_HELLO 1
#define MSG_REPLY 2
#define MSG_FINISH 3
#define MSG_CONFIRM 4

static const char MAGIC[4] = {'T', 'S', 'L', '1'};
static const char LABEL_SIG_1[] = "tcpseal-v1 device1 sig";
static const char LABEL_SIG_2[] = "tcpseal-v1 device2 sig";
static const char LABEL_FIN_1[] = "tcpseal-v1 device1 finished";
static const char LABEL_FIN_2[] = "tcpseal-v1 device2 finished";
static const char LABEL_KEYS[] = "tcpseal-v1 session keys";

enum { STAGE_NEW, STAGE_HELLO_SENT, STAGE_KEYS, STAGE_DONE };

/* ------------------------------------------------------------ helpers */
static int check_message(const uint8_t *msg, size_t len, int type, size_t expected_len, char *err)
{
    if (len < TS_HS_HEADER_LEN || memcmp(msg, MAGIC, sizeof(MAGIC)) != 0) {
        ts_set_error(err, "bad magic / protocol version");
        return -1;
    }
    if (msg[4] != type) {
        ts_set_error(err, "expected message type %d, got %d", type, msg[4]);
        return -1;
    }
    if (len != expected_len) {
        ts_set_error(err, "message type %d has wrong length %zu", type, len - TS_HS_HEADER_LEN);
        return -1;
    }
    return 0;
}

static void put_header(uint8_t *msg, int type)
{
    memcpy(msg, MAGIC, sizeof(MAGIC));
    msg[4] = (uint8_t)type;
}

/* data = label || th, written into buf (>= 64 bytes); returns its length */
static size_t labelled(uint8_t *buf, const char *label, const uint8_t th[32])
{
    size_t n = strlen(label);
    memcpy(buf, label, n);
    memcpy(buf + n, th, 32);
    return n + 32;
}

static int sign(EVP_PKEY *key, const char *label, const uint8_t th[32], uint8_t sig[TS_HS_SIG_LEN])
{
    uint8_t data[96];
    size_t data_len = labelled(data, label, th);
    size_t sig_len = TS_HS_SIG_LEN;
    EVP_MD_CTX *ctx = EVP_MD_CTX_new();
    int ok = ctx != NULL && EVP_DigestSignInit(ctx, NULL, NULL, NULL, key) == 1 &&
             EVP_DigestSign(ctx, sig, &sig_len, data, data_len) == 1 && sig_len == TS_HS_SIG_LEN;
    EVP_MD_CTX_free(ctx);
    return ok ? 0 : -1;
}

static int verify(EVP_PKEY *key, const char *label, const uint8_t th[32], const uint8_t *sig, char *err)
{
    uint8_t data[96];
    size_t data_len = labelled(data, label, th);
    EVP_MD_CTX *ctx = EVP_MD_CTX_new();
    int ok = ctx != NULL && EVP_DigestVerifyInit(ctx, NULL, NULL, NULL, key) == 1 &&
             EVP_DigestVerify(ctx, sig, TS_HS_SIG_LEN, data, data_len) == 1;
    EVP_MD_CTX_free(ctx);
    if (!ok) {
        ts_set_error(err, "peer signature invalid (wrong identity key or tampering)");
        return -1;
    }
    return 0;
}

static void finished(const uint8_t *confirm_key, const char *label, const uint8_t th[32],
                     uint8_t out[TS_HS_MAC_LEN])
{
    uint8_t data[96];
    size_t data_len = labelled(data, label, th);
    unsigned int out_len = TS_HS_MAC_LEN;
    (void)HMAC(EVP_sha256(), confirm_key, TS_KEY_LEN, data, data_len, out, &out_len);
}

static int x25519(EVP_PKEY *own, const uint8_t peer_public[TS_HS_PUB_LEN], uint8_t shared[32], char *err)
{
    static const uint8_t zero[32] = {0};
    size_t shared_len = 32;
    EVP_PKEY *peer = EVP_PKEY_new_raw_public_key(EVP_PKEY_X25519, NULL, peer_public, TS_HS_PUB_LEN);
    EVP_PKEY_CTX *ctx = EVP_PKEY_CTX_new(own, NULL);
    /* OpenSSL rejects low-order points (all-zero result) in EVP_PKEY_derive. */
    int ok = peer != NULL && ctx != NULL && EVP_PKEY_derive_init(ctx) == 1 &&
             EVP_PKEY_derive_set_peer(ctx, peer) == 1 && EVP_PKEY_derive(ctx, shared, &shared_len) == 1 &&
             shared_len == 32 && CRYPTO_memcmp(shared, zero, 32) != 0;
    EVP_PKEY_CTX_free(ctx);
    EVP_PKEY_free(peer);
    if (!ok) {
        ts_set_error(err, "invalid peer Diffie-Hellman public key");
        return -1;
    }
    return 0;
}

int ts_derive_keys(const uint8_t *shared, size_t shared_len, const uint8_t random_1[32],
                   const uint8_t random_2[32], const uint8_t th[32], uint8_t okm[TS_HS_OKM_LEN])
{
    uint8_t salt[64];
    uint8_t info[sizeof(LABEL_KEYS) - 1 + 32];
    memcpy(salt, random_1, 32);
    memcpy(salt + 32, random_2, 32);
    memcpy(info, LABEL_KEYS, sizeof(LABEL_KEYS) - 1);
    memcpy(info + sizeof(LABEL_KEYS) - 1, th, 32);

    EVP_KDF *kdf = EVP_KDF_fetch(NULL, "HKDF", NULL);
    EVP_KDF_CTX *ctx = kdf != NULL ? EVP_KDF_CTX_new(kdf) : NULL;
    OSSL_PARAM params[] = {
        OSSL_PARAM_construct_utf8_string(OSSL_KDF_PARAM_DIGEST, (char *)"SHA256", 0),
        OSSL_PARAM_construct_octet_string(OSSL_KDF_PARAM_KEY, (void *)shared, shared_len),
        OSSL_PARAM_construct_octet_string(OSSL_KDF_PARAM_SALT, salt, sizeof(salt)),
        OSSL_PARAM_construct_octet_string(OSSL_KDF_PARAM_INFO, info, sizeof(info)),
        OSSL_PARAM_construct_end(),
    };
    int ok = ctx != NULL && EVP_KDF_derive(ctx, okm, TS_HS_OKM_LEN, params) == 1;
    EVP_KDF_CTX_free(ctx);
    EVP_KDF_free(kdf);
    return ok ? 0 : -1;
}

/* Orient the five derived keys for the local device. */
static void session_keys(const ts_handshake *hs, int local_device, ts_session_keys *keys)
{
    ts_direction_keys d1_to_d2, d2_to_d1;
    memcpy(d1_to_d2.aes_key, hs->okm + 0 * TS_KEY_LEN, TS_KEY_LEN);
    memcpy(d2_to_d1.aes_key, hs->okm + 1 * TS_KEY_LEN, TS_KEY_LEN);
    memcpy(d1_to_d2.nonce_key, hs->okm + 2 * TS_KEY_LEN, TS_KEY_LEN);
    memcpy(d2_to_d1.nonce_key, hs->okm + 3 * TS_KEY_LEN, TS_KEY_LEN);
    for (int i = 0; i < 8; ++i) {
        (void)snprintf(keys->session_id + 2 * i, 3, "%02x", hs->th[i]);
    }
    keys->tx = local_device == 1 ? d1_to_d2 : d2_to_d1;
    keys->rx = local_device == 1 ? d2_to_d1 : d1_to_d2;
    ts_secure_zero(&d1_to_d2, sizeof(d1_to_d2));
    ts_secure_zero(&d2_to_d1, sizeof(d2_to_d1));
}

static const uint8_t *confirm_key(const ts_handshake *hs) { return hs->okm + 4 * TS_KEY_LEN; }

static int write_hello_body(ts_handshake *hs, uint8_t *msg)
{
    size_t pub_len = TS_HS_PUB_LEN;
    memcpy(msg + TS_HS_HEADER_LEN, hs->random, TS_HS_RANDOM_LEN);
    return EVP_PKEY_get_raw_public_key(hs->ephemeral, msg + TS_HS_HEADER_LEN + TS_HS_RANDOM_LEN, &pub_len) ==
                       1 &&
                   pub_len == TS_HS_PUB_LEN
               ? 0
               : -1;
}

/* ------------------------------------------------------------ common */
int ts_handshake_init(ts_handshake *hs, EVP_PKEY *identity, EVP_PKEY *peer_identity, char *err)
{
    memset(hs, 0, sizeof(*hs));
    hs->identity = identity;
    hs->peer_identity = peer_identity;
    hs->ephemeral = EVP_PKEY_Q_keygen(NULL, NULL, "X25519");
    if (hs->ephemeral == NULL || RAND_bytes(hs->random, sizeof(hs->random)) != 1) {
        ts_set_error(err, "cannot create ephemeral key or random");
        EVP_PKEY_free(hs->ephemeral);
        hs->ephemeral = NULL;
        return -1;
    }
    return 0;
}

void ts_handshake_clear(ts_handshake *hs)
{
    EVP_PKEY_free(hs->ephemeral);
    ts_secure_zero(hs, sizeof(*hs));
}

/* ------------------------------------------------------------ Device1 */
int ts_initiator_hello(ts_handshake *hs, uint8_t out[TS_HS_HELLO_LEN])
{
    put_header(out, MSG_HELLO);
    if (write_hello_body(hs, out) != 0) {
        return -1;
    }
    memcpy(hs->hello, out, TS_HS_HELLO_LEN);
    hs->stage = STAGE_HELLO_SENT;
    return 0;
}

int ts_initiator_finish(ts_handshake *hs, const uint8_t *reply, size_t reply_len,
                        uint8_t out[TS_HS_FINISH_LEN], ts_session_keys *keys, char *err)
{
    uint8_t shared[32];
    if (hs->stage != STAGE_HELLO_SENT) {
        ts_set_error(err, "finish() called before hello()");
        return -1;
    }
    if (check_message(reply, reply_len, MSG_REPLY, TS_HS_REPLY_LEN, err) != 0) {
        return -1;
    }
    const uint8_t *random_2 = reply + TS_HS_HEADER_LEN;
    const uint8_t *peer_public = random_2 + TS_HS_RANDOM_LEN;
    const uint8_t *signature = peer_public + TS_HS_PUB_LEN;

    /* th = SHA-256(M1 || M2 without signature) */
    EVP_MD_CTX *md = EVP_MD_CTX_new();
    int ok = md != NULL && EVP_DigestInit_ex(md, EVP_sha256(), NULL) == 1 &&
             EVP_DigestUpdate(md, hs->hello, TS_HS_HELLO_LEN) == 1 &&
             EVP_DigestUpdate(md, reply, TS_HS_REPLY_LEN - TS_HS_SIG_LEN) == 1 &&
             EVP_DigestFinal_ex(md, hs->th, NULL) == 1;
    EVP_MD_CTX_free(md);
    if (!ok) {
        ts_set_error(err, "SHA-256 failed");
        return -1;
    }
    if (verify(hs->peer_identity, LABEL_SIG_2, hs->th, signature, err) != 0 ||
        x25519(hs->ephemeral, peer_public, shared, err) != 0) {
        return -1;
    }
    ok = ts_derive_keys(shared, sizeof(shared), hs->random, random_2, hs->th, hs->okm) == 0;
    ts_secure_zero(shared, sizeof(shared));
    put_header(out, MSG_FINISH);
    if (!ok || sign(hs->identity, LABEL_SIG_1, hs->th, out + TS_HS_HEADER_LEN) != 0) {
        ts_set_error(err, "key derivation or signing failed");
        return -1;
    }
    finished(confirm_key(hs), LABEL_FIN_1, hs->th, out + TS_HS_HEADER_LEN + TS_HS_SIG_LEN);
    session_keys(hs, 1, keys);
    hs->stage = STAGE_KEYS;
    return 0;
}

int ts_initiator_confirm(ts_handshake *hs, const uint8_t *msg, size_t msg_len, char *err)
{
    uint8_t expected[TS_HS_MAC_LEN];
    if (hs->stage != STAGE_KEYS) {
        ts_set_error(err, "confirm() called before finish()");
        return -1;
    }
    if (check_message(msg, msg_len, MSG_CONFIRM, TS_HS_CONFIRM_LEN, err) != 0) {
        return -1;
    }
    finished(confirm_key(hs), LABEL_FIN_2, hs->th, expected);
    if (CRYPTO_memcmp(expected, msg + TS_HS_HEADER_LEN, TS_HS_MAC_LEN) != 0) {
        ts_set_error(err, "Device2 finished MAC invalid");
        return -1;
    }
    hs->stage = STAGE_DONE;
    return 0;
}

/* ------------------------------------------------------------ Device2 */
int ts_responder_reply(ts_handshake *hs, const uint8_t *hello, size_t hello_len, uint8_t out[TS_HS_REPLY_LEN],
                       char *err)
{
    uint8_t shared[32];
    if (check_message(hello, hello_len, MSG_HELLO, TS_HS_HELLO_LEN, err) != 0) {
        return -1;
    }
    const uint8_t *random_1 = hello + TS_HS_HEADER_LEN;
    const uint8_t *peer_public = random_1 + TS_HS_RANDOM_LEN;
    if (x25519(hs->ephemeral, peer_public, shared, err) != 0) {
        return -1;
    }
    put_header(out, MSG_REPLY);
    if (write_hello_body(hs, out) != 0) { /* random_2 | x25519_pub_2 */
        ts_set_error(err, "cannot export ephemeral key");
        return -1;
    }
    EVP_MD_CTX *md = EVP_MD_CTX_new();
    int ok = md != NULL && EVP_DigestInit_ex(md, EVP_sha256(), NULL) == 1 &&
             EVP_DigestUpdate(md, hello, TS_HS_HELLO_LEN) == 1 &&
             EVP_DigestUpdate(md, out, TS_HS_REPLY_LEN - TS_HS_SIG_LEN) == 1 &&
             EVP_DigestFinal_ex(md, hs->th, NULL) == 1;
    EVP_MD_CTX_free(md);
    ok = ok && ts_derive_keys(shared, sizeof(shared), random_1, hs->random, hs->th, hs->okm) == 0;
    ts_secure_zero(shared, sizeof(shared));
    if (!ok || sign(hs->identity, LABEL_SIG_2, hs->th, out + TS_HS_REPLY_LEN - TS_HS_SIG_LEN) != 0) {
        ts_set_error(err, "key derivation or signing failed");
        return -1;
    }
    hs->stage = STAGE_KEYS;
    return 0;
}

int ts_responder_confirm(ts_handshake *hs, const uint8_t *finish, size_t finish_len,
                         uint8_t out[TS_HS_CONFIRM_LEN], ts_session_keys *keys, char *err)
{
    uint8_t expected[TS_HS_MAC_LEN];
    if (hs->stage != STAGE_KEYS) {
        ts_set_error(err, "confirm() called before reply()");
        return -1;
    }
    if (check_message(finish, finish_len, MSG_FINISH, TS_HS_FINISH_LEN, err) != 0 ||
        verify(hs->peer_identity, LABEL_SIG_1, hs->th, finish + TS_HS_HEADER_LEN, err) != 0) {
        return -1;
    }
    finished(confirm_key(hs), LABEL_FIN_1, hs->th, expected);
    if (CRYPTO_memcmp(expected, finish + TS_HS_HEADER_LEN + TS_HS_SIG_LEN, TS_HS_MAC_LEN) != 0) {
        ts_set_error(err, "Device1 finished MAC invalid");
        return -1;
    }
    put_header(out, MSG_CONFIRM);
    finished(confirm_key(hs), LABEL_FIN_2, hs->th, out + TS_HS_HEADER_LEN);
    session_keys(hs, 2, keys);
    hs->stage = STAGE_DONE;
    return 0;
}
