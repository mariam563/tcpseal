/*
 * protector.c - protect (encrypt + append tag) and unprotect (verify + decrypt).
 */
#include "tcpseal/protector.h"

#include "tcpseal/packet.h"

#include <string.h>

const char *ts_drop_reason_name(int reason)
{
    static const char *const names[TS_DROP_COUNT] = {
        "pass",           "malformed",           "too_big",
        "no_session",     "NonceReuseError",     "SessionExpiredError",
        "no_tag",         "AuthenticationError", "ReplayError",
        "internal_error",
    };
    return (reason >= 0 && reason < TS_DROP_COUNT) ? names[reason] : "unknown";
}

static int reason_from_session(int result)
{
    switch (result) {
    case TS_ERR_NONCE_REUSE: return TS_DROP_NONCE_REUSE;
    case TS_ERR_EXPIRED: return TS_DROP_EXPIRED;
    case TS_ERR_REPLAY: return TS_DROP_REPLAY;
    case TS_ERR_AUTH: return TS_DROP_AUTH;
    default: return TS_DROP_INTERNAL;
    }
}

int ts_protect(const uint8_t *in, size_t in_len, ts_manager *m, size_t peer_mtu, uint8_t *out,
               size_t *out_len)
{
    ts_packet pkt;
    char err[TS_ERR_LEN];
    uint8_t aad[TS_MAX_HEADERS];

    if (ts_packet_parse(in, in_len, &pkt, err) != 0) {
        return TS_DROP_MALFORMED;
    }
    size_t headers = ts_packet_headers_len(&pkt);
    size_t protected_len = headers + pkt.payload_len + TS_TAG_LEN;
    if (protected_len > peer_mtu) {
        return TS_DROP_TOO_BIG; /* would not fit on the inter-device link */
    }
    size_t aad_len = ts_canonical_header(&pkt, pkt.payload_len, aad);

    ts_manager_lock(m);
    ts_session *s = ts_manager_tx_locked(m, ts_now());
    if (s == NULL) {
        ts_manager_unlock(m);
        return TS_DROP_NO_SESSION;
    }
    memcpy(out, in, headers); /* original headers, unchanged */
    int result = ts_session_seal(s, aad, aad_len, ts_packet_payload(&pkt), pkt.payload_len, out + headers);
    ts_manager_unlock(m);
    if (result != TS_OK) {
        return reason_from_session(result);
    }
    ts_packet_finalize(out, pkt.ip_len, protected_len);
    *out_len = protected_len;
    return TS_PASS;
}

int ts_unprotect(const uint8_t *in, size_t in_len, ts_manager *m, uint8_t *out, size_t *out_len)
{
    ts_packet pkt;
    char err[TS_ERR_LEN];
    uint8_t aad[TS_MAX_HEADERS];
    ts_session *candidates[3];

    if (ts_packet_parse(in, in_len, &pkt, err) != 0) {
        return TS_DROP_MALFORMED;
    }
    if (pkt.payload_len < TS_TAG_LEN) {
        return TS_DROP_NO_TAG;
    }
    size_t headers = ts_packet_headers_len(&pkt);
    size_t plaintext_len = pkt.payload_len - TS_TAG_LEN;
    size_t aad_len = ts_canonical_header(&pkt, plaintext_len, aad);

    ts_manager_lock(m);
    size_t n = ts_manager_rx_locked(m, ts_now(), candidates);
    int reason = n == 0 ? TS_DROP_NO_SESSION : TS_DROP_AUTH;
    for (size_t i = 0; i < n; ++i) { /* at most three: pending, current, previous */
        int result = ts_session_open(candidates[i], aad, aad_len, ts_packet_payload(&pkt), pkt.payload_len,
                                     out + headers);
        if (result == TS_OK) {
            ts_manager_unlock(m);
            memcpy(out, in, headers);
            ts_packet_finalize(out, pkt.ip_len, headers + plaintext_len);
            *out_len = headers + plaintext_len;
            return TS_PASS;
        }
        if (result == TS_ERR_REPLAY) {
            reason = TS_DROP_REPLAY;
        }
    }
    ts_manager_unlock(m);
    return reason;
}
