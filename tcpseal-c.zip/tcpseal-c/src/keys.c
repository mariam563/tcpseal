/*
 * keys.c - Ed25519 identity key generation and loading.
 */
#include "tcpseal/keys.h"

#include "tcpseal/common.h"

#include <openssl/pem.h>
#include <openssl/sha.h>

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

static int valid_name(const char *name)
{
    if (*name == '\0') {
        return 0;
    }
    for (const char *p = name; *p != '\0'; ++p) {
        if (!isalnum((unsigned char)*p) && *p != '-' && *p != '_') {
            return 0;
        }
    }
    return 1;
}

/* mkdir -p with mode 0700 for the last component */
static int make_dirs(const char *dir)
{
    char path[4096];
    (void)snprintf(path, sizeof(path), "%s", dir);
    for (char *p = path + 1; *p != '\0'; ++p) {
        if (*p == '/') {
            *p = '\0';
            if (mkdir(path, 0755) != 0 && errno != EEXIST) {
                return -1;
            }
            *p = '/';
        }
    }
    if (mkdir(path, 0700) != 0 && errno != EEXIST) {
        return -1;
    }
    return chmod(path, 0700);
}

int ts_keygen(const char *dir, const char *name, int overwrite, char *private_path, char *public_path,
              size_t path_size, char *err)
{
    if (!valid_name(name)) {
        ts_set_error(err, "key name may only contain letters, digits, '-' and '_'");
        return -1;
    }
    if (make_dirs(dir) != 0) {
        ts_set_error(err, "cannot create directory %s: %s", dir, strerror(errno));
        return -1;
    }
    (void)snprintf(private_path, path_size, "%s/%s.key", dir, name);
    (void)snprintf(public_path, path_size, "%s/%s.pub", dir, name);
    if (!overwrite && (access(private_path, F_OK) == 0 || access(public_path, F_OK) == 0)) {
        ts_set_error(err, "%s or %s already exists (use --force)", private_path, public_path);
        return -1;
    }

    EVP_PKEY *key = EVP_PKEY_Q_keygen(NULL, NULL, "ED25519");
    if (key == NULL) {
        ts_set_error(err, "Ed25519 key generation failed");
        return -1;
    }
    int result = -1;
    FILE *priv = NULL, *pub = NULL;
    /* Create the private key file with mode 0600 from the start. */
    int fd = open(private_path, O_WRONLY | O_CREAT | O_TRUNC, 0600);
    if (fd >= 0 && fchmod(fd, 0600) == 0) {
        priv = fdopen(fd, "w");
    } else if (fd >= 0) {
        (void)close(fd);
    }
    pub = fopen(public_path, "w");
    if (priv != NULL && pub != NULL && PEM_write_PrivateKey(priv, key, NULL, NULL, 0, NULL, NULL) == 1 &&
        PEM_write_PUBKEY(pub, key) == 1) {
        result = 0;
    } else {
        ts_set_error(err, "cannot write key files in %s", dir);
    }
    if (priv != NULL && fclose(priv) != 0) {
        result = -1;
    }
    if (pub != NULL && fclose(pub) != 0) {
        result = -1;
    }
    EVP_PKEY_free(key);
    return result;
}

static int is_ed25519(const EVP_PKEY *key) { return EVP_PKEY_get_id(key) == EVP_PKEY_ED25519; }

EVP_PKEY *ts_load_private(const char *path, char *err)
{
    struct stat st;
    if (stat(path, &st) != 0 || !S_ISREG(st.st_mode)) {
        ts_set_error(err, "identity key not found: %s (generate it with 'tcpseal keygen')", path);
        return NULL;
    }
    if ((st.st_mode & 077) != 0) {
        ts_set_error(err, "identity key %s has unsafe permissions %o; run: chmod 600 %s", path,
                     (unsigned)(st.st_mode & 0777), path);
        return NULL;
    }
    FILE *f = fopen(path, "r");
    if (f == NULL) {
        ts_set_error(err, "cannot open identity key %s: %s", path, strerror(errno));
        return NULL;
    }
    EVP_PKEY *key = PEM_read_PrivateKey(f, NULL, NULL, NULL);
    (void)fclose(f);
    if (key == NULL) {
        ts_set_error(err, "cannot parse identity key %s", path);
        return NULL;
    }
    if (!is_ed25519(key)) {
        ts_set_error(err, "%s is not an Ed25519 private key", path);
        EVP_PKEY_free(key);
        return NULL;
    }
    return key;
}

EVP_PKEY *ts_load_public(const char *path, char *err)
{
    struct stat st;
    if (stat(path, &st) != 0 || !S_ISREG(st.st_mode)) {
        ts_set_error(err, "peer public key not found: %s (copy <peer>.pub from the other device)", path);
        return NULL;
    }
    FILE *f = fopen(path, "r");
    if (f == NULL) {
        ts_set_error(err, "cannot open public key %s: %s", path, strerror(errno));
        return NULL;
    }
    EVP_PKEY *key = PEM_read_PUBKEY(f, NULL, NULL, NULL);
    (void)fclose(f);
    if (key == NULL) {
        ts_set_error(err, "cannot parse public key %s", path);
        return NULL;
    }
    if (!is_ed25519(key)) {
        ts_set_error(err, "%s is not an Ed25519 public key", path);
        EVP_PKEY_free(key);
        return NULL;
    }
    return key;
}

void ts_fingerprint(const EVP_PKEY *key, char out[17])
{
    uint8_t raw[32];
    uint8_t digest[SHA256_DIGEST_LENGTH];
    size_t raw_len = sizeof(raw);
    out[0] = '\0';
    if (EVP_PKEY_get_raw_public_key(key, raw, &raw_len) != 1) {
        return;
    }
    (void)SHA256(raw, raw_len, digest);
    for (int i = 0; i < 8; ++i) {
        (void)snprintf(out + 2 * i, 3, "%02x", digest[i]);
    }
}
