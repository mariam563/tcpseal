# tcpseal (C implementation)

**Inline AES-256-GCM protection of TCP payloads between two Linux security
gateways**, written in C11 with OpenSSL 3. An educational prototype for a
networking and cybersecurity course.

```
PC1 ──── Device1 ════ protected TCP/IPv4 ════ Device2 ──── PC2
         (encrypt / decrypt)        (decrypt / encrypt)
```

Device1 and Device2 run an authenticated Diffie–Hellman handshake, derive
directional AES-256-GCM keys with HKDF, and then encrypt only the **payload**
of selected TCP/IPv4 packets. The IP and TCP headers stay in place, the
16-byte GCM tag is appended, lengths and checksums are recomputed, and the
original TCP connection between PC1 and PC2 is untouched. There is no
tunnel, no UDP encapsulation and no extra protocol header.

> [!WARNING]
> This is a **teaching prototype**, not production security software. It has
> not been audited and has documented limitations. Use WireGuard, IPsec or
> TLS for real traffic.

---

## Contents

1. [Purpose and scope](#purpose-and-scope)
2. [Architecture](#architecture)
3. [Security design](#security-design) — threat model, authentication, nonces, packet processing
4. [Limitations](#known-limitations-and-technical-constraints)
5. [Installation and build](#installation-and-build)
6. [Configuration and secrets](#configuration-and-safe-secret-generation)
7. [Running Device1 and Device2](#running-device1-and-device2-on-real-machines-or-vms)
8. [Tests](#tests)
9. [Namespace demonstration](#network-namespace-demonstration)
10. [Cleanup](#cleanup)
11. [Troubleshooting](#troubleshooting)
12. [Repository layout](#repository-layout)
13. [Contributing, licence, attribution](#contributing)

Detailed documents: [docs/DESIGN.md](docs/DESIGN.md) ·
[docs/TECHNICAL_REVIEW.md](docs/TECHNICAL_REVIEW.md) ·
[docs/TESTING.md](docs/TESTING.md) · [docs/ATTRIBUTION.md](docs/ATTRIBUTION.md) ·
[docs/GITHUB_SETUP.md](docs/GITHUB_SETUP.md)

## Purpose and scope

The project shows, end to end, how a pair of inline devices can:

* intercept selected TCP traffic with netfilter **NFQUEUE** (netlink API
  used directly, no libnetfilter_queue);
* agree on keys with **X25519**, authenticated by **Ed25519** signatures;
* derive per-direction keys with **HKDF-SHA256**;
* encrypt TCP payloads with **AES-256-GCM** while keeping the packet a valid
  TCP/IPv4 packet;
* manage GCM nonces safely **without** sending them;
* rekey, expire sessions and fail closed.

Scope: IPv4, TCP, one protected TCP service port, two devices on a direct
link. IPv6, UDP, NAT and multiple peers are out of scope.

The wire protocol is identical to the Python version of tcpseal; a C device
and a Python device can talk to each other.

## Architecture

| Layer | File | Role |
|---|---|---|
| Packet I/O | `src/nfqueue.c` | Minimal NFQUEUE netlink client: bind queues, receive packets, send verdicts |
| Packet format | `src/packet.c` | IPv4/TCP parsing, RFC 1071 checksums, canonical header |
| Data plane | `src/protector.c` | `ts_protect()` / `ts_unprotect()` |
| Sessions | `src/session.c` | Directional keys, nonce derivation, nonce hash sets, AES-GCM, lifetime, session manager |
| Key exchange | `src/handshake.c` | X25519 + Ed25519 + HKDF (no sockets → easy to unit-test) |
| Control plane | `src/control.c` | Runs handshakes over TCP; rekey, reconnect, back-off |
| Glue | `src/daemon.c`, `src/main.c`, `src/config.c`, `src/keys.c`, `src/common.c` | Daemon loop, CLI, strict INI config, key files, logging |
| Tools | `tools/tcp_transfer.c`, `tools/link_sniffer.c` | Echo transfer test, capture counters for the demo |

Each device runs one `bin/tcpseal run` process with two threads: the
**packet loop** (NFQUEUE verdicts) and the **control thread** (handshakes).
The session manager is protected by a mutex; the packet loop holds it while
it encrypts or decrypts, so a rekey can never free a session that is in use.

Firewall rules from `scripts/device-rules.sh` decide which packets reach the
daemon:

| On each device | Hook | Queue |
|---|---|---|
| Packets leaving towards the other device (host_if → peer_if) | `FORWARD` | encrypt (default 100) |
| Packets arriving from the other device (peer_if) | `PREROUTING`, raw priority | decrypt (default 101) |

Decryption runs before routing so that the kernel's forwarding MTU check
towards the PC only sees the original packet size
([DESIGN §3.1](docs/DESIGN.md#31-firewall-hooks-scriptsdevice-rulessh)).

## Security design

### Threat model

The attacker controls the Device1↔Device2 link: they can read, drop, delay,
reorder, replay, modify and inject packets, and can connect to the control
port.

* **Protected:** confidentiality of selected TCP payloads; integrity of
  payloads and of all non-mutable header fields (addresses, ports, sequence
  and ACK numbers, flags, window, options, IP ID, length); authenticity of
  TCP control packets (forged RST/FIN are rejected); replay within a session;
  man-in-the-middle on the handshake; forward secrecy between sessions.
* **Not protected:** packet sizes, timing, addresses and ports (headers stay
  in clear by design); unselected traffic; the PC↔device segments;
  compromised devices or stolen private keys; denial of service (including
  someone repeatedly opening control connections); side channels.

### Authentication design and limitations

* Each device has a long-term **Ed25519 identity key**, generated locally
  with `bin/tcpseal keygen` (mode 0600). Private keys readable by group or
  others are refused.
* Each device is configured with the **peer's public key** (pinning, like
  SSH `known_hosts`). `bin/tcpseal check-config` prints fingerprints to
  compare on both devices.
* Handshake (4 fixed-size messages): ephemeral X25519 keys and randoms are
  exchanged; both sides sign the transcript hash; both send an HMAC
  "finished" value. Data is encrypted only after this key confirmation.
* Key material is erased with `OPENSSL_cleanse` when a handshake or session
  ends.

Limitations: no certificate authority or revocation; one peer per device;
the handshake is a custom design inspired by SIGMA/TLS 1.3 and has not been
reviewed — a real product would use IKEv2, TLS 1.3 or Noise.

### Session lifetime

Device1 rekeys after `rekey_interval` seconds or at 80 % of `max_packets`.
A session is never used after `lifetime` seconds or `max_packets` packets
(both devices enforce this). After a rekey the previous session may still
decrypt for 10 s. If Device2 restarts, Device1 notices the closed control
connection and runs a new handshake; failed handshakes are retried with
exponential back-off (1–30 s). Without a valid session, selected traffic is
**dropped**.

### Nonce-management design and limitations

The assignment forbids a custom header, so the nonce cannot be sent. tcpseal
derives it from data the receiver already has:

```
nonce = HMAC-SHA256(nonce_key[direction], canonical_header)[0..11]
```

The *canonical header* is the IPv4 + TCP header (with options) where TTL,
checksums and ECN bits are zeroed and the total length is the plaintext
length. It differs for every packet a normal TCP stack sends (sequence/ACK
numbers, IP identification, TCP timestamp) and is also the GCM associated
data.

* **Uniqueness is enforced:** the sender stores every nonce of the session in
  a hash set and *drops* a packet whose nonce was already used.
* **Independent nonce spaces:** separate nonce keys and AES keys per
  direction; new keys and empty sets for every session.
* **Reordering and loss:** irrelevant — there is no counter to keep in sync.
* **Replay:** the receiver rejects any nonce it has accepted before.
* **Retransmissions:** Linux retransmits with a new IP ID and timestamp →
  new nonce (verified in the demo with 10 % loss).

Limitation: a TCP stack that sends **byte-identical** retransmissions
(constant IP ID, no timestamps) would have them dropped, so the connection
could stall — never a nonce reuse. Memory for the sets is bounded by
`max_packets`. Details and rejected alternatives:
[DESIGN §5](docs/DESIGN.md#5-nonce-management-without-a-header).

### Packet-processing design

Encrypt: parse → check `size + 16 ≤ peer_mtu` → canonical header → nonce →
AES-GCM(payload, aad = canonical header) → headers + ciphertext + tag →
`ts_packet_finalize()` (IPv4 length, IPv4 checksum, TCP checksum) →
`NF_ACCEPT` with the new packet.

Decrypt: parse → payload ≥ 16 → canonical header with plaintext length =
payload − 16 → try pending/current/previous session (≤ 3 attempts) → replay
check → verify tag and decrypt (plaintext is wiped on failure) → finalize →
`NF_ACCEPT`. Any failure → `NF_DROP`.

Packets **without** payload (SYN, ACK, FIN, RST) get a tag-only payload on
the inter-device link and are therefore authenticated too.

## Known limitations and technical constraints

| Topic | What to know |
|---|---|
| MTU | Protected packets are 16 bytes larger. The Device1↔Device2 link MTU must be ≥ endpoint MTU + 16 (examples use 1600). Otherwise full-size segments are dropped (`encrypt_drop_too_big`) without an ICMP error. Alternative: PC MTU 1484. |
| Fragments | IPv4 fragments on the protected path are dropped. |
| Retransmissions | See the nonce limitation above. |
| NAT / header-rewriting middleboxes between the devices | Not supported (headers are authenticated). |
| Offloads | NFQUEUE re-segments GSO packets; the rules script disables GRO/GSO/TSO/LRO if `ethtool` is installed. |
| IPv6, UDP, several ports or peers | Not implemented. |
| Performance | One packet thread; fine for a lab, not tuned for line rate. |

## Installation and build

### Tested environment

Ubuntu 24.04 userland, Linux 6.18 kernel, gcc 13.3 / clang 18, OpenSSL
3.0.13, iptables 1.8.10, nftables 1.0.9. Should work on any Linux with
OpenSSL ≥ 3.0 (Ubuntu 22.04+, Debian 12+, Fedora). Please run the namespace
demo once on your own machine; [docs/TESTING.md](docs/TESTING.md) lists
exactly what was and was not executed.

### Dependencies

* Build: a C11 compiler, `make`, OpenSSL 3 development headers
  (`libssl-dev`), `pkg-config`.
* Devices and demo: `iproute2`, `nftables` and/or `iptables`; kernel
  modules `nfnetlink_queue` and `nft_queue` or `xt_NFQUEUE` (standard
  distribution kernels have them). Optional: `ethtool`.
* Optional development tools: `clang-format`, `clang-tidy`, `valgrind`.

### Fresh Ubuntu/Debian system

```bash
sudo apt update
sudo apt install -y git build-essential pkg-config libssl-dev iproute2 nftables iptables ethtool
# optional: sudo apt install -y clang clang-format clang-tidy valgrind

git clone https://github.com/USERNAME/tcpseal-c.git
cd tcpseal-c
make            # builds bin/tcpseal, bin/tcp_transfer, bin/link_sniffer
make test       # unit + integration tests, no root needed
bin/tcpseal --version
```

## Configuration and safe secret generation

All machine-specific files live in **`local/`**, which git ignores (except
its README). Nothing secret is ever committed.

**On Device1:**

```bash
bin/tcpseal keygen --name device1 --dir local/keys   # device1.key (0600) + device1.pub
cp examples/device1.example.ini local/device1.ini
```

**On Device2:**

```bash
bin/tcpseal keygen --name device2 --dir local/keys
cp examples/device2.example.ini local/device2.ini
```

Exchange **only the public keys**: copy `device1.pub` into `local/keys/` on
Device2 and `device2.pub` into `local/keys/` on Device1 (e.g. with `scp`).
Never copy `.key` files. Then edit and validate:

```bash
bin/tcpseal check-config local/device1.ini
# OK: role=device1 control=10.0.12.2:47100 queues=100/101 peer_mtu=1600
# own key fingerprint:  …
# peer key fingerprint: …   ← must equal the "own" fingerprint printed on Device2
```

| Section / key | Meaning | Default |
|---|---|---|
| `[device] role` | `device1` (initiator) or `device2` (responder) | required |
| `[device] identity_key` | own private key, relative to the config file | required |
| `[device] peer_public_key` | pinned public key of the other device | required |
| `[control] address` | Device1: Device2's address. Device2: address to listen on | required |
| `[control] port` / `handshake_timeout` | control TCP port / seconds per handshake message | 47100 / 5 |
| `[dataplane] encrypt_queue` / `decrypt_queue` | NFQUEUE numbers (must match the rules) | 100 / 101 |
| `[dataplane] peer_mtu` | MTU of the inter-device link | 1500 |
| `[session] rekey_interval` / `lifetime` / `max_packets` | soft rekey time, hard lifetime (s), hard packet limit | 240 / 300 / 200000 |
| `[logging] level` | `debug`, `info`, `warning`, `error` | info |

Unknown sections or keys, duplicates, missing values and out-of-range
numbers stop the program with a clear message.

## Running Device1 and Device2 on real machines or VMs

Example addressing (private ranges, adapt to your lab):

| Node | Interface | Address |
|---|---|---|
| PC1 | – | 10.0.1.2/24, gateway 10.0.1.1 |
| Device1 | `host0` / `peer0` | 10.0.1.1/24 / 10.0.12.1/30, route 10.0.2.0/24 via 10.0.12.2 |
| Device2 | `peer0` / `host0` | 10.0.12.2/30 / 10.0.2.1/24, route 10.0.1.0/24 via 10.0.12.1 |
| PC2 | – | 10.0.2.2/24, gateway 10.0.2.1 |

```bash
# On both devices: room for the 16-byte tag on the inter-device link
sudo ip link set dev peer0 mtu 1600

# Device2 (start it first)
sudo scripts/device-rules.sh apply device2 host0 peer0 5001
sudo bin/tcpseal run local/device2.ini

# Device1
sudo scripts/device-rules.sh apply device1 host0 peer0 5001
sudo bin/tcpseal run local/device1.ini

# PC2: service on the protected port; PC1: client (copy bin/tcp_transfer there)
./tcp_transfer server --bind 10.0.2.2 --port 5001
./tcp_transfer client --host 10.0.2.2 --port 5001 --size 1000000
```

Privileges: the daemon and the rules script need **root** or
**CAP_NET_ADMIN** (NFQUEUE binding, firewall rules, sysctl). Without them
`tcpseal run` exits with code 3 and a clear message. Kernel modules:
`nfnetlink_queue` plus `nft_queue` or `xt_NFQUEUE` (loaded automatically).
`device-rules.sh apply` also sets `net.ipv4.ip_forward=1`.

Every 10 s the daemon logs statistics such as
`stats session=3f… {"decrypted": 1941, "encrypted": 1446}`; drops appear as
`encrypt_drop_<reason>` / `decrypt_drop_<reason>`.

Exit codes: 0 ok, 1 runtime error, 2 configuration or key error,
3 NFQUEUE unavailable.

## Tests

| Kind | Root? | Command |
|---|---|---|
| Unit tests (6 programs) | no | `make unit` |
| Integration (handshake over TCP on 127.0.0.1, rekey, restart; CLI exit codes) | no | `make integration` |
| Both | no | `make test` → `ALL TESTS PASSED` |
| AddressSanitizer + UBSan | no | `make asan` |
| valgrind | no | `make valgrind` |
| clang-tidy / clang-format | no | `make lint`, `make format-check` |
| Namespace end-to-end test | **yes** | `sudo make privileged` |

The mapping of the twelve assignment test requirements to individual tests
is in [docs/TESTING.md](docs/TESTING.md).

## Network-namespace demonstration

```bash
make
sudo scripts/netns-demo.sh
```

Four namespaces and veth links replace the four computers. Fresh keys are
generated in a temporary directory (deleted afterwards), then eight phases
run: handshake, 2 MB transfer in both directions, confidentiality check on
the inter-device link, 10 % packet loss, tampering, automatic rekey,
fail-closed with Device1 stopped, restart of both devices. Expected output
(abridged):

```
[PASS] both devices established session 29ac7c1ba2b92727
[PASS] 2 MB echo transfer PC1 <-> PC2 (sent=2000000 received=2000000 sha256_match=True)
[PASS] marker seen 2306 times at PC2 but 0 times in 3502 protected packets on the Device1<->Device2 link
[PASS] transfer succeeded although every 10th protected packet was dropped
[PASS] modified packets were not delivered (transfer failed as expected)
[PASS] Device2 rejected tampered packets (AES-GCM authentication failure)
[PASS] session renewed (357f0acb35f32b6f -> 274cdcefea733cc4) and traffic continued
[PASS] no traffic passes while Device1 is not running (queue without bypass)
[PASS] fresh session f7a41928975bbc1e after restart; transfer succeeded
DEMO RESULT: ALL PHASES PASSED
```

IDs and counts differ on every run. Options: `KEEP_LOGS=1`,
`LOG_LEVEL=debug`, `FIREWALL=nft|iptables`, and
`DEVICE1_CMD` / `DEVICE2_CMD` to run one device with another binary, e.g.
the sanitizer build (`build-asan/bin/tcpseal` after `make asan`) or the
Python implementation:

```bash
sudo DEVICE2_CMD="env PYTHONPATH=../tcpseal/src python3 -m tcpseal" scripts/netns-demo.sh
```

## Cleanup

```bash
sudo scripts/netns-cleanup.sh          # demo: kill demo processes, delete ts-* namespaces (+ veths, routes, rules)
sudo scripts/device-rules.sh remove    # real device: remove only the tcpseal table/chains
sudo ip link set dev peer0 mtu 1500    # real device: restore the MTU if you changed it
sudo sysctl -w net.ipv4.ip_forward=0   # only if forwarding was off before
make clean                             # remove build/, build-asan/, bin/
```

The demo cleans up automatically on exit, also after errors or Ctrl-C.
Stop a daemon with Ctrl-C or `kill <pid>` (SIGTERM).

## Troubleshooting

| Symptom | Cause / fix |
|---|---|
| `fatal error: openssl/evp.h: No such file` | `sudo apt install libssl-dev` |
| `error: binding NFQUEUE needs root or CAP_NET_ADMIN` (exit 3) | Run with `sudo`. |
| `identity key ... has unsafe permissions` | `chmod 600 local/keys/deviceN.key` |
| `peer signature invalid (wrong identity key or tampering)` | The pinned `peer_public_key` does not match the peer; compare fingerprints. |
| `handshake/control failure: connect ... Connection refused` | Device2 not running, wrong `[control] address`/`port`, or TCP 47100 blocked. Device1 keeps retrying. |
| Small requests work, large transfers hang | MTU: raise the peer-link MTU to ≥ 1516 or lower the PC MTUs to 1484 (`encrypt_drop_too_big` in the stats). |
| `nftables 'queue' unavailable, using iptables NFQUEUE` | Normal on kernels without `nft_queue`. |
| `tcpseal rules already installed` | `sudo scripts/device-rules.sh remove` first. |
| Demo: `missing bin/tcpseal` | Run `make` before the demo. |
| Demo: `Cannot create namespace ... File exists` | A previous run was killed: `sudo scripts/netns-cleanup.sh`. |
| All selected traffic stops | No valid session or the daemon is not running — intended fail-closed behaviour. |

## Repository layout

```
tcpseal-c/
├── include/tcpseal/       # public headers, one per module (documented)
├── src/
│   ├── packet.c           # IPv4/TCP parsing, checksums, canonical header
│   ├── session.c          # keys, nonce sets, AES-GCM, lifetime, manager
│   ├── protector.c        # encrypt/decrypt one packet
│   ├── handshake.c        # X25519 + Ed25519 + HKDF
│   ├── control.c          # handshake transport, rekey, reconnect
│   ├── nfqueue.c          # NFQUEUE netlink client
│   ├── daemon.c           # packet loop, statistics, signals
│   ├── config.c, keys.c   # strict INI parser, key files
│   ├── common.c           # logging, clock, secure erase
│   └── main.c             # tcpseal keygen | check-config | run
├── tools/                 # tcp_transfer.c, link_sniffer.c
├── tests/
│   ├── test.h, helpers.h  # tiny test framework and packet/session helpers
│   ├── unit/              # 6 test programs, no root
│   ├── integration/       # test_control.c (127.0.0.1), test_cli.sh
│   └── privileged/        # namespace end-to-end test (root)
├── scripts/               # device-rules.sh, netns-demo.sh, netns-cleanup.sh
├── examples/              # device1/device2 example configs – placeholders only
├── docs/                  # design, technical review, testing, attribution, GitHub guide
├── local/                 # YOUR configs and keys (git-ignored)
├── .github/               # CI workflow, issue and PR templates
├── Makefile, .clang-format, .clang-tidy
└── LICENSE, SECURITY.md, CONTRIBUTING.md
```

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md). Run `make format-check test asan`
before opening a pull request, and never commit keys, real configurations,
logs or packet captures.

## License

MIT — see [LICENSE](LICENSE). Uses OpenSSL 3 (Apache-2.0) as a system
library; nothing third-party is bundled.

## Academic integrity and attribution

An earlier student implementation in C was available as a reference. tcpseal
was redesigned independently: no code or text was copied (a line comparison
finds only 12 generic boilerplate/API lines in common), and the reference's
weaknesses — committed demo PSK, no rekeying, counter desynchronisation after
packet loss, unauthenticated control packets — were deliberately addressed.
Shared standard techniques, external libraries, specifications and a note on
AI-assisted development (adapt it to your course's rules) are listed in
[docs/ATTRIBUTION.md](docs/ATTRIBUTION.md).
