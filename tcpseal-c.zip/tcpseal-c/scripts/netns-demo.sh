#!/usr/bin/env bash
# Automated end-to-end demonstration in four Linux network namespaces:
#
#   ts-pc1 (10.0.1.2) -- ts-d1 (Device1) == ts-d2 (Device2) -- ts-pc2 (10.0.2.2)
#                     10.0.1.0/24      10.0.12.0/30        10.0.2.0/24
#
# Usage:  make && sudo scripts/netns-demo.sh        (from the repository root)
#
# Interoperability: DEVICE1_CMD / DEVICE2_CMD replace the daemon command of one
# device, e.g. to run Device2 with the Python implementation of tcpseal:
#   sudo DEVICE2_CMD="env PYTHONPATH=../tcpseal/src python3 -m tcpseal" scripts/netns-demo.sh
#
# Phases (each prints PASS or FAIL):
#   1. handshake        both daemons establish the same session
#   2. transfer         echo transfer PC1 <-> PC2 succeeds (both directions)
#   3. confidentiality  plaintext marker absent on the Device1<->Device2 link
#   4. loss             10 % of protected packets dropped -> TCP retransmits, transfer still succeeds
#   5. tamper           one byte modified on the link -> Device2 rejects, nothing delivered
#   6. rekey            session is renewed automatically, traffic continues
#   7. fail-closed      Device1 stopped -> no traffic passes at all
#   8. restart          Device1 and Device2 restarted -> new session, traffic works again
#
# Keys and configs are generated in a temporary directory that is deleted at
# the end. Nothing is written into the repository. All namespaces are removed
# on exit (also on error / Ctrl-C).
set -euo pipefail

REPO=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
PORT=5001
MARKER="TCPSEAL-PLAINTEXT-MARKER"
TCPSEAL=$REPO/bin/tcpseal
TRANSFER=$REPO/bin/tcp_transfer
SNIFFER=$REPO/bin/link_sniffer
WORK=$(mktemp -d -t tcpseal-demo.XXXXXX)
chmod 700 "$WORK"
FAILURES=0
declare -A DAEMON_PID=()
SNIFFER_PIDS=()

log()  { printf '\n=== %s\n' "$*"; }
pass() { printf '[PASS] %s\n' "$*"; }
fail() { printf '[FAIL] %s\n' "$*"; FAILURES=$((FAILURES + 1)); }
in_ns() { local ns=$1; shift; ip netns exec "$ns" "$@"; }

cleanup() {
    set +e
    for pid in "${DAEMON_PID[@]}" "${SNIFFER_PIDS[@]}"; do kill "$pid" 2>/dev/null; done
    sleep 0.5
    "$REPO/scripts/netns-cleanup.sh" >/dev/null
    if [[ ${KEEP_LOGS:-0} == 1 ]]; then
        echo "logs kept in $WORK"
    else
        rm -rf -- "$WORK"
    fi
}
trap cleanup EXIT

# ------------------------------------------------------------ prerequisites
[[ ${EUID} -eq 0 ]] || { echo "run as root: sudo $0" >&2; exit 1; }
for cmd in ip nft sysctl; do
    command -v "$cmd" >/dev/null 2>&1 || { echo "missing command: $cmd" >&2; exit 1; }
done
for binary in "$TCPSEAL" "$TRANSFER" "$SNIFFER"; do
    [[ -x $binary ]] || { echo "missing $binary - run 'make' first" >&2; exit 1; }
done
"$REPO/scripts/netns-cleanup.sh" >/dev/null   # remove leftovers of an aborted run

# ------------------------------------------------------------ topology
log "creating namespaces and links"
for ns in ts-pc1 ts-d1 ts-d2 ts-pc2; do
    ip netns add "$ns"
    ip -n "$ns" link set lo up
done
ip link add ts-pc1 type veth peer name ts-d1h
ip link add ts-d1p type veth peer name ts-d2p
ip link add ts-d2h type veth peer name ts-pc2
ip link set ts-pc1 netns ts-pc1
ip link set ts-d1h netns ts-d1
ip link set ts-d1p netns ts-d1
ip link set ts-d2p netns ts-d2
ip link set ts-d2h netns ts-d2
ip link set ts-pc2 netns ts-pc2

ip -n ts-pc1 addr add 10.0.1.2/24 dev ts-pc1
ip -n ts-d1  addr add 10.0.1.1/24 dev ts-d1h
ip -n ts-d1  addr add 10.0.12.1/30 dev ts-d1p
ip -n ts-d2  addr add 10.0.12.2/30 dev ts-d2p
ip -n ts-d2  addr add 10.0.2.1/24 dev ts-d2h
ip -n ts-pc2 addr add 10.0.2.2/24 dev ts-pc2
# The protected packet is 16 bytes longer: give the inter-device link room.
ip -n ts-d1 link set ts-d1p mtu 1600
ip -n ts-d2 link set ts-d2p mtu 1600
for pair in ts-pc1:ts-pc1 ts-d1:ts-d1h ts-d1:ts-d1p ts-d2:ts-d2p ts-d2:ts-d2h ts-pc2:ts-pc2; do
    ip -n "${pair%%:*}" link set "${pair##*:}" up
done
ip -n ts-pc1 route add default via 10.0.1.1
ip -n ts-pc2 route add default via 10.0.2.1
ip -n ts-d1 route add 10.0.2.0/24 via 10.0.12.2
ip -n ts-d2 route add 10.0.1.0/24 via 10.0.12.1

in_ns ts-d1 "$REPO/scripts/device-rules.sh" apply device1 ts-d1h ts-d1p "$PORT" 100 101
in_ns ts-d2 "$REPO/scripts/device-rules.sh" apply device2 ts-d2h ts-d2p "$PORT" 100 101

# ------------------------------------------------------------ keys + configs
log "generating fresh identity keys and configs in a temporary directory"
mkdir -p "$WORK/keys"
"$TCPSEAL" keygen --name device1 --dir "$WORK/keys" >/dev/null
"$TCPSEAL" keygen --name device2 --dir "$WORK/keys" >/dev/null
write_config() {  # role address
    cat > "$WORK/$1.ini" <<EOF
[device]
role = $1
identity_key = keys/$1.key
peer_public_key = keys/$([[ $1 == device1 ]] && echo device2 || echo device1).pub
[control]
address = $2
port = 47100
handshake_timeout = 3
[dataplane]
encrypt_queue = 100
decrypt_queue = 101
peer_mtu = 1600
[session]
rekey_interval = 6
lifetime = 30
max_packets = 200000
[logging]
level = ${LOG_LEVEL:-info}
EOF
}
write_config device1 10.0.12.2
write_config device2 10.0.12.2

start_daemon() {  # role namespace
    local cmd_var=${1^^}_CMD   # DEVICE1_CMD or DEVICE2_CMD
    local -a cmd
    read -r -a cmd <<<"${!cmd_var:-$TCPSEAL}"
    ip netns exec "$2" "${cmd[@]}" run "$WORK/$1.ini" >>"$WORK/$1.log" 2>&1 &
    DAEMON_PID[$1]=$!
}
stop_daemon() {  # role
    kill "${DAEMON_PID[$1]}" 2>/dev/null || true
    wait "${DAEMON_PID[$1]}" 2>/dev/null || true
    unset "DAEMON_PID[$1]"
}
count_established() { grep -c "established" "$WORK/$1.log" 2>/dev/null || true; }
wait_for_established() {  # role minimum_count
    for _ in $(seq 1 60); do
        (( $(count_established "$1") >= $2 )) && return 0
        sleep 0.25
    done
    return 1
}
last_session() { grep -o "session [0-9a-f]\{16\} established" "$WORK/$1.log" | tail -1 | cut -d' ' -f2; }
transfer() {  # size timeout
    in_ns ts-pc1 "$TRANSFER" client --host 10.0.2.2 --port "$PORT" \
        --size "$1" --timeout "$2" >>"$WORK/transfer.log" 2>&1
}

# ------------------------------------------------------------ phase 1
log "phase 1: handshake"
ip netns exec ts-pc2 "$TRANSFER" server --bind 10.0.2.2 --port "$PORT" >"$WORK/server.log" 2>&1 &
SNIFFER_PIDS+=($!)
start_daemon device2 ts-d2
sleep 0.5
start_daemon device1 ts-d1
if wait_for_established device1 1 && wait_for_established device2 1 \
   && [[ $(last_session device1) == "$(last_session device2)" ]]; then
    pass "both devices established session $(last_session device1)"
else
    fail "handshake did not complete"; tail -n 20 "$WORK"/device*.log; exit 1
fi

# ------------------------------------------------------------ phases 2 + 3
log "phase 2+3: transfer and confidentiality"
ip netns exec ts-d2  "$SNIFFER" --interface ts-d2p --port "$PORT" --marker "$MARKER" --out "$WORK/link.json" &
SNIFFER_PIDS+=($!); LINK_SNIFFER=$!
ip netns exec ts-pc2 "$SNIFFER" --interface ts-pc2 --port "$PORT" --marker "$MARKER" --out "$WORK/pc2.json" &
SNIFFER_PIDS+=($!); PC2_SNIFFER=$!
for _ in $(seq 1 40); do [[ -e $WORK/link.json.ready && -e $WORK/pc2.json.ready ]] && break; sleep 0.1; done
if transfer 2000000 20; then pass "2 MB echo transfer PC1 <-> PC2 ($(tail -1 "$WORK/transfer.log"))"
else fail "transfer failed"; fi
sleep 0.5
kill -TERM "$LINK_SNIFFER" "$PC2_SNIFFER"; wait "$LINK_SNIFFER" "$PC2_SNIFFER" 2>/dev/null || true
json_value() { grep -o "\"$2\": [0-9]*" "$1" | grep -o '[0-9]*$'; }
link_hits=$(json_value "$WORK/link.json" marker_hits)
link_pkts=$(json_value "$WORK/link.json" with_payload)
pc2_hits=$(json_value "$WORK/pc2.json" marker_hits)
if (( link_pkts > 0 && link_hits == 0 && pc2_hits > 0 )); then
    pass "marker seen $pc2_hits times at PC2 but 0 times in $link_pkts protected packets on the Device1<->Device2 link"
else
    fail "confidentiality check: link_packets=$link_pkts link_marker_hits=$link_hits pc2_marker_hits=$pc2_hits"
fi

# ------------------------------------------------------------ phase 4
log "phase 4: packet loss / retransmission"
in_ns ts-d1 nft add table ip tsdemo
in_ns ts-d1 nft 'add chain ip tsdemo post { type filter hook postrouting priority 0; }'
in_ns ts-d1 nft add rule ip tsdemo post oifname ts-d1p tcp dport "$PORT" numgen inc mod 10 == 0 counter drop
if transfer 500000 30; then pass "transfer succeeded although every 10th protected packet was dropped"
else fail "transfer failed under packet loss"; fi
dropped=$(in_ns ts-d1 nft list table ip tsdemo | grep -o 'packets [0-9]*' | head -1)
echo "     link drops: $dropped"
in_ns ts-d1 nft delete table ip tsdemo

# ------------------------------------------------------------ phase 5
log "phase 5: tampering on the inter-device link"
in_ns ts-d1 nft add table ip tsdemo
in_ns ts-d1 nft 'add chain ip tsdemo post { type filter hook postrouting priority 0; }'
# Overwrite one byte 32 bytes into the TCP header area (TCP options or payload).
in_ns ts-d1 nft add rule ip tsdemo post oifname ts-d1p tcp dport "$PORT" @th,256,8 set 0x58 counter
before=$(grep -c "AuthenticationError" "$WORK/device2.log" || true)
if transfer 20000 4; then fail "transfer succeeded although packets were modified"
else pass "modified packets were not delivered (transfer failed as expected)"; fi
in_ns ts-d1 nft delete table ip tsdemo
sleep 1
if grep -q '"decrypt_drop_AuthenticationError"' "$WORK/device2.log" || \
   (( $(grep -c "AuthenticationError" "$WORK/device2.log" || true) > before )); then
    pass "Device2 rejected tampered packets (AES-GCM authentication failure)"
else
    fail "Device2 did not report authentication failures"
fi

# ------------------------------------------------------------ phase 6
log "phase 6: automatic rekey"
first=$(last_session device1)
wait_for_established device1 $(( $(count_established device1) + 1 )) || true
sleep 1
second=$(last_session device1)
if [[ $first != "$second" ]] && transfer 200000 20; then
    pass "session renewed ($first -> $second) and traffic continued"
else
    fail "rekey check (first=$first second=$second)"
fi

# ------------------------------------------------------------ phase 7
log "phase 7: fail-closed without Device1 daemon"
stop_daemon device1
if transfer 20000 4; then fail "traffic passed while Device1 was down"
else pass "no traffic passes while Device1 is not running (queue without bypass)"; fi

# ------------------------------------------------------------ phase 8
log "phase 8: restart both devices"
stop_daemon device2
d1_before=$(count_established device1)
start_daemon device2 ts-d2
sleep 0.5
start_daemon device1 ts-d1
if wait_for_established device1 $((d1_before + 1)) && sleep 0.5 && transfer 200000 20; then
    pass "fresh session $(last_session device1) after restart; transfer succeeded"
else
    fail "restart recovery"
fi

# ------------------------------------------------------------ summary
stop_daemon device1
stop_daemon device2
echo
echo "Device1 final stats: $(grep 'final stats' "$WORK/device1.log" | tail -1 | sed 's/.*final stats //')"
echo "Device2 final stats: $(grep 'final stats' "$WORK/device2.log" | tail -1 | sed 's/.*final stats //')"
if (( FAILURES == 0 )); then
    echo "DEMO RESULT: ALL PHASES PASSED"
else
    echo "DEMO RESULT: $FAILURES PHASE(S) FAILED (rerun with KEEP_LOGS=1 to inspect logs)"
fi
exit $(( FAILURES > 0 ))
