#!/usr/bin/env bash
# Install or remove the firewall rules that send selected TCP traffic to tcpseal.
#
#   sudo scripts/device-rules.sh apply  ROLE HOST_IF PEER_IF PORT [ENCRYPT_Q DECRYPT_Q]
#   sudo scripts/device-rules.sh remove
#   sudo scripts/device-rules.sh show
#
# ROLE     device1 (PC1 side) or device2 (PC2 side)
# HOST_IF  interface facing the local PC
# PEER_IF  interface facing the other security device
# PORT     TCP port of the protected service running on PC2
#
# Backend: nftables ("queue" statement) is used when the kernel supports it,
# otherwise iptables ("-j NFQUEUE"). Force one with FIREWALL=nft|iptables.
# All rules live in a private table/chain named "tcpseal", so removal never
# touches other firewall rules on the machine.
#
# The queue rules have no "bypass" option: if the daemon is not running, the
# kernel DROPS selected packets instead of forwarding them unprotected.
set -euo pipefail

NAME="tcpseal"

die() { echo "device-rules.sh: $*" >&2; exit 1; }
usage() { sed -n '2,19p' "$0" | sed 's/^# \{0,1\}//'; exit 2; }
require_root() { [[ ${EUID} -eq 0 ]] || die "must run as root (needs CAP_NET_ADMIN)"; }
is_number() { [[ $1 =~ ^[0-9]+$ ]] && (( $1 >= 0 && $1 <= 65535 )); }
have() { command -v "$1" >/dev/null 2>&1; }

# Where the rules go (both backends):
#
#   encrypt  FORWARD hook, HOST_IF -> PEER_IF. Runs after the kernel's
#            forwarding MTU check (done with the original size); the bigger
#            protected packet is then only checked against the PEER_IF MTU.
#   decrypt  PREROUTING hook (raw priority) for packets arriving on PEER_IF.
#            Runs *before* routing, so the forwarding MTU check towards the PC
#            and connection tracking only ever see the original-size packet.
#            Packets addressed to the device itself are never queued.
direction_flags() {  # role -> "<encrypt port match> <decrypt port match>"
    if [[ $1 == device1 ]]; then echo "dport sport"; else echo "sport dport"; fi
}

apply_nft() {
    local host_if=$1 peer_if=$2 port=$3 enc_flag=$4 dec_flag=$5 enc_q=$6 dec_q=$7
    nft -f - <<RULES
table ip $NAME {
    chain forward {
        type filter hook forward priority 0; policy accept;
        # Fragments cannot be processed, and non-first fragments carry no TCP
        # ports (they could bypass the port match): drop them on this path.
        iifname "$host_if" oifname "$peer_if" ip protocol tcp ip frag-off & 0x3fff != 0 counter drop
        iifname "$host_if" oifname "$peer_if" tcp $enc_flag $port counter queue num $enc_q
    }
    chain prerouting {
        type filter hook prerouting priority raw; policy accept;
        iifname "$peer_if" ip protocol tcp ip frag-off & 0x3fff != 0 fib daddr type != local counter drop
        iifname "$peer_if" tcp $dec_flag $port fib daddr type != local counter queue num $dec_q
    }
}
RULES
}

apply_iptables() {
    local host_if=$1 peer_if=$2 port=$3 enc_flag=$4 dec_flag=$5 enc_q=$6 dec_q=$7
    iptables -w -N "$NAME"
    iptables -w -I FORWARD 1 -j "$NAME"
    # -f matches non-first fragments; first fragments are rejected by the daemon.
    iptables -w -A "$NAME" -i "$host_if" -o "$peer_if" -p tcp -f -j DROP
    iptables -w -A "$NAME" -i "$host_if" -o "$peer_if" -p tcp --"$enc_flag" "$port" \
        -j NFQUEUE --queue-num "$enc_q"
    iptables -w -t raw -N "$NAME"
    iptables -w -t raw -I PREROUTING 1 -j "$NAME"
    iptables -w -t raw -A "$NAME" -i "$peer_if" -p tcp -f -m addrtype ! --dst-type LOCAL -j DROP
    iptables -w -t raw -A "$NAME" -i "$peer_if" -p tcp --"$dec_flag" "$port" \
        -m addrtype ! --dst-type LOCAL -j NFQUEUE --queue-num "$dec_q"
}

installed_backend() {
    if have nft && nft list table ip "$NAME" >/dev/null 2>&1; then echo nft; return; fi
    if have iptables && iptables -w -S "$NAME" >/dev/null 2>&1; then echo iptables; return; fi
    echo none
}

apply_rules() {
    local role=$1 host_if=$2 peer_if=$3 port=$4 enc_q=${5:-100} dec_q=${6:-101}
    [[ $role == device1 || $role == device2 ]] || die "ROLE must be device1 or device2"
    for value in "$port" "$enc_q" "$dec_q"; do is_number "$value" || die "invalid number: $value"; done
    (( port > 0 )) || die "PORT must be 1..65535"
    [[ $enc_q != "$dec_q" ]] || die "encrypt and decrypt queue numbers must differ"
    for interface in "$host_if" "$peer_if"; do
        [[ -e /sys/class/net/$interface ]] || die "interface does not exist: $interface"
    done
    [[ $(installed_backend) == none ]] || die "tcpseal rules already installed; run '$0 remove' first"

    sysctl -q -w net.ipv4.ip_forward=1   # the device routes between its interfaces

    # Offloads (GRO/GSO/TSO/LRO) merge segments into large buffers. NFQUEUE
    # re-segments GSO packets itself, but disabling them keeps the
    # one-packet-at-a-time view predictable. Optional (needs ethtool).
    if have ethtool; then
        for interface in "$host_if" "$peer_if"; do
            ethtool -K "$interface" gro off gso off tso off lro off >/dev/null 2>&1 || true
        done
    fi

    local backend=${FIREWALL:-auto} enc_flag dec_flag
    read -r enc_flag dec_flag <<<"$(direction_flags "$role")"
    local args=("$host_if" "$peer_if" "$port" "$enc_flag" "$dec_flag" "$enc_q" "$dec_q")
    if [[ $backend == auto || $backend == nft ]] && have nft && apply_nft "${args[@]}" 2>/dev/null; then
        backend=nft
    elif [[ $backend == auto || $backend == iptables ]] && have iptables; then
        [[ ${FIREWALL:-auto} == auto ]] && echo "nftables 'queue' unavailable, using iptables NFQUEUE"
        apply_iptables "${args[@]}"
        backend=iptables
    else
        die "could not install rules (need nftables with nft_queue, or iptables with NFQUEUE)"
    fi
    echo "tcpseal rules installed ($backend) for $role: host=$host_if peer=$peer_if port=$port queues=$enc_q/$dec_q"
}

remove_rules() {
    case $(installed_backend) in
        nft) nft delete table ip "$NAME" ;;
        iptables)
            iptables -w -D FORWARD -j "$NAME" 2>/dev/null || true
            iptables -w -F "$NAME"
            iptables -w -X "$NAME"
            iptables -w -t raw -D PREROUTING -j "$NAME" 2>/dev/null || true
            iptables -w -t raw -F "$NAME" 2>/dev/null || true
            iptables -w -t raw -X "$NAME" 2>/dev/null || true
            ;;
        none) echo "no tcpseal rules installed"; return ;;
    esac
    echo "tcpseal rules removed (net.ipv4.ip_forward was left unchanged)"
}

[[ $# -ge 1 ]] || usage
case $1 in
    apply)  [[ $# -eq 5 || $# -eq 7 ]] || usage; require_root; shift; apply_rules "$@" ;;
    remove) require_root; remove_rules ;;
    show)
        require_root
        case $(installed_backend) in
            nft) nft list table ip "$NAME" ;;
            iptables) iptables -w -L "$NAME" -v -n; iptables -w -t raw -L "$NAME" -v -n ;;
            none) echo "no tcpseal rules installed" ;;
        esac
        ;;
    *) usage ;;
esac
