#!/usr/bin/env bash
# Remove everything created by scripts/netns-demo.sh:
# processes inside the demo namespaces, the namespaces themselves (which also
# destroys their veth interfaces, routes and nftables rules), and nothing else.
# Safe to run several times.
set -uo pipefail

NAMESPACES=(ts-pc1 ts-d1 ts-d2 ts-pc2)

if [[ ${EUID} -ne 0 ]]; then
    echo "netns-cleanup.sh: must run as root" >&2
    exit 1
fi

for ns in "${NAMESPACES[@]}"; do
    if ip netns list 2>/dev/null | awk '{print $1}' | grep -Fxq "$ns"; then
        pids=$(ip netns pids "$ns" 2>/dev/null || true)
        if [[ -n $pids ]]; then
            # shellcheck disable=SC2086
            kill $pids 2>/dev/null || true
            sleep 0.5
            # shellcheck disable=SC2086
            kill -9 $pids 2>/dev/null || true
        fi
        ip netns del "$ns" && echo "removed namespace $ns"
    fi
done
echo "netns cleanup complete"
