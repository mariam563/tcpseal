# Security Policy

tcpseal is a **university prototype** and must not be used to protect real
traffic. It has not been audited. Known limitations are listed in
[docs/DESIGN.md](docs/DESIGN.md) and [docs/TECHNICAL_REVIEW.md](docs/TECHNICAL_REVIEW.md).

If you find a flaw in the design or the code, please open a GitHub issue (no
private disclosure process exists for this educational project). Never post
private keys or captures of real traffic in an issue.
