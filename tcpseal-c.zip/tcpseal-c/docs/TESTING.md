# Testing (C implementation)

| Level | Location | Needs | Command |
|---|---|---|---|
| Unit | `tests/unit/test_*.c` (6 programs) | C compiler, OpenSSL 3 headers. No root, no network. | `make unit` |
| Integration | `tests/integration/test_control.c`, `tests/integration/test_cli.sh` | Same, plus TCP sockets on `127.0.0.1`. No root. | `make integration` |
| Both | | | `make test` |
| Sanitizers | all unit + integration tests built with `-fsanitize=address,undefined` | gcc or clang | `make asan` |
| Memory checker | unit tests under valgrind | `valgrind` | `make valgrind` |
| Static analysis | clang-tidy (clang analyzer + bugprone checks, see `.clang-tidy`) | `clang-tidy` | `make lint` |
| Formatting | clang-format (`.clang-format`) | `clang-format` | `make format-check` |
| Privileged | `tests/privileged/test_netns_demo.sh` → `scripts/netns-demo.sh` | **root**, `ip`, `nft`, `iptables` or nft `queue`, modules `nfnetlink_queue` + `xt_NFQUEUE`/`nft_queue` | `sudo make privileged` |

The tests use a ~40-line framework in `tests/test.h` (`TEST`, `CHECK`,
`CHECK_EQ`, `RUN`), so no test library has to be installed.

## Requirement coverage

| # | Requirement | Where it is tested |
|---|---|---|
| 1 | Successful DH key exchange | `test_handshake: successful_exchange_gives_matching_directional_keys`, `test_control: handshake_over_tcp_and_data_protection`, demo phase 1 |
| 2 | Session-key derivation | `test_handshake: key_schedule_matches_independent_hkdf`, `hkdf_rfc5869_test_case_1`, `every_handshake_creates_fresh_keys` |
| 3 | AES-GCM encryption/decryption | `test_protector: roundtrip_restores_original_packet`, `wire_format_is_headers_ciphertext_tag` |
| 4 | Unique nonces | `test_session: distinct_headers_give_distinct_nonces`, `sender_refuses_to_reuse_a_nonce`, `nonce_set_add_contains_and_grow`, `directions_use_independent_keys` |
| 5 | Tag verification | `test_protector: roundtrip_*`, `empty_payload_control_packet_is_authenticated` |
| 6 | Rejection of modified ciphertext/tag/header | `test_protector: any_modification_is_rejected` (ciphertext, tag, port, seq, address), demo phase 5 |
| 7 | IPv4/TCP checksum recalculation | `test_packet: ipv4_checksum_known_vector`, `build_produces_valid_checksums` (cross-checked with an independent implementation), `test_protector: decrypted_packet_valid_after_ttl_change` |
| 8 | Forwarding PC1 ↔ PC2 | demo phase 2 (2 MB echo, SHA-256 verified, both directions) |
| 9 | Retransmission and reordering | `test_protector: reordering_and_loss_do_not_desynchronise`, `tcp_retransmission_gets_new_nonce`, `byte_identical_retransmission_is_dropped`, `replayed_packet_is_rejected`, demo phase 4 (10 % loss) |
| 10 | Handshake failures | `test_handshake: wrong_pinned_key_is_rejected`, `man_in_the_middle_replacing_dh_key_is_detected`, `any_modified_message_fails`, `malformed_and_low_order_hello_rejected`, `test_control: wrong_peer_key_never_creates_a_session`, `initiator_retries_until_responder_appears` |
| 11 | Configuration validation | `test_config_keys: invalid_configs_fail_clearly` (12 cases), `shipped_examples_are_valid` |
| 12 | Missing secrets / permissions | `test_config_keys: world_readable_private_key_is_refused`, `missing_and_wrong_type_keys`, `test_cli.sh` (missing key → exit 2, unsafe permissions → exit 2, no CAP_NET_ADMIN → exit 3) |
| – | Rekey, expiry, restart | `test_session: soft_and_hard_limits`, `test_protector: packets_in_flight_during_rekey_are_accepted`, `test_control: automatic_rekey`, `device2_restart_triggers_new_session`, demo phases 6–8 |
| – | Fail-closed | `test_protector: no_session_means_drop`, demo phase 7 |

## Namespace demonstration

`sudo scripts/netns-demo.sh` (after `make`) builds four namespaces and runs
eight phases: handshake, transfer, confidentiality (capture on the link with
`bin/link_sniffer`), 10 % loss, tampering, rekey, fail-closed, restart.
Expected last line: `DEMO RESULT: ALL PHASES PASSED`. Options:
`KEEP_LOGS=1`, `LOG_LEVEL=debug`, `FIREWALL=nft|iptables`,
`DEVICE1_CMD=...` / `DEVICE2_CMD=...` (run one device with another binary,
e.g. the ASan build or the Python implementation).

## Results recorded during development

Executed in the development sandbox (Ubuntu 24.04 userland, Linux 6.18
kernel, gcc 13.3, clang 18, OpenSSL 3.0.13, iptables 1.8.10, nftables 1.0.9):

* `make test` → **68 checks in 8 test programs, 0 failed** (55 C unit/integration
  tests + 13 CLI checks).
* `make asan` → all tests pass with AddressSanitizer + UndefinedBehaviorSanitizer
  (including LeakSanitizer).
* `make valgrind` → no errors, no definite leaks.
* `make lint` → no clang-tidy findings with the checks in `.clang-tidy`.
* Build with `-Wall -Wextra -Wpedantic -Wshadow -Wformat=2 ...` → no warnings.
* `sudo make privileged` → **all 8 demo phases passed** (repeated 4 times).
* Demo with both daemons built with ASan/UBSan → all phases passed, no
  sanitizer reports.
* **Interoperability**: demo with C Device1 + Python Device2, and with
  Python Device1 + C Device2 → all phases passed.

Limits of that environment (so the results are not over-stated):

* The kernel had no `nft_queue` module, so the **iptables NFQUEUE backend**
  of `device-rules.sh` was exercised; the nftables ruleset was only
  validated with the queue statement replaced by `accept`.
* The sandbox had no iproute2; the demo was run with a small test-only
  replacement for the `ip` subcommands it uses. Please run the demo once on
  a normal Ubuntu/Debian machine before relying on it.
* The GitHub Actions workflow has not been executed yet.
