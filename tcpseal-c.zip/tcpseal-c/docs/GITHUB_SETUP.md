# Publishing on GitHub

## Suggested repository

* **Name:** `tcpseal-c` (or `tcpseal` if you publish only the C version)
* **Description:** *Educational Linux prototype in C: inline AES-256-GCM
  protection of TCP payloads between two security gateways (NFQUEUE netlink,
  OpenSSL 3, X25519/Ed25519 handshake, header-derived nonces, netns demo).*
* **Topics:** `c`, `openssl`, `networking`, `cryptography`, `aes-gcm`, `nfqueue`, `linux`,
  `network-namespaces`, `education`

## What is committed and what stays local

| Commit | Keep local (ignored by `.gitignore`) |
|---|---|
| `src/`, `include/`, `tests/`, `scripts/`, `tools/`, `docs/`, `examples/*.example.ini` | `local/` (your real configs and **all keys**) |
| `README.md`, `LICENSE`, `Makefile`, `.clang-format`, `.clang-tidy` | `*.key`, `*.pem`, `.env` |
| `.gitignore`, `.github/` | `build/`, `build-asan/`, `bin/`, `*.o`, `*.a`, core dumps |
| | `*.log`, `*.pcap`, `*.pcapng`, demo output, `*.zip` |
| | the reference implementation ZIP |

Public keys (`*.pub`) are not secret, but they identify your lab devices;
keep them in `local/` too.

## First push

Create an **empty** repository on GitHub (no README/licence, they already
exist here). Authenticate with `gh auth login`, SSH keys, or a credential
helper – never put a token into a file or a remote URL.

```bash
cd tcpseal-c
git init
git add .
git status            # check: no local/, no keys, no build/ or bin/, no logs
git commit -m "Initial independent implementation"
git branch -M main
git remote add origin https://github.com/USERNAME/tcpseal-c.git
git push -u origin main
```

Quick self-check before every push:

```bash
git ls-files | grep -v '^local/README.md$' | grep -Ei '\.(key|pem|pcap|log|zip)$|^local/' && echo "STOP: sensitive file tracked"
git grep -nE 'BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY' && echo "STOP: private key in repo"
```

## Recommended commit plan

If you rebuild the history step by step (useful for showing your own work
during evaluation), small commits in this order work well:

1. `chore: project skeleton, Makefile, licence, gitignore, clang-format/tidy`
2. `feat(packet): IPv4/TCP parser, checksums and canonical header` + `tests/unit/test_packet.c`, `tests/test.h`
3. `feat(session): directional keys, nonce hash set, AES-GCM seal/open, manager` + tests
4. `feat(protector): payload encryption with appended GCM tag` + tests
5. `feat(handshake): X25519 + Ed25519 authenticated key exchange with HKDF` + tests
6. `feat(keys,config): key generation and strict INI validation` + tests
7. `feat(control): handshake channel with rekey and reconnect` + `test_control.c`
8. `feat(nfqueue): minimal netlink NFQUEUE client` + codec tests
9. `feat(daemon,cli): gateway daemon and command line` + `test_cli.sh`
10. `feat(tools,scripts): transfer/sniffer tools, firewall rules, namespace demo, cleanup`
11. `test: privileged namespace test, sanitizer and valgrind targets`
12. `docs: README, design, technical review, testing, attribution`
13. `ci: GitHub Actions (gcc + clang, sanitizers, valgrind, clang-tidy)`

## Continuous integration

`.github/workflows/ci.yml` runs on every push and pull request:

* job **test** (gcc and clang on Ubuntu 24.04): build with warnings,
  `make format-check`, `make test`, `make asan`, `make valgrind`,
  `make lint` – no secrets and no root needed;
* job **netns-demo**: installs nftables/iptables/iproute2 and runs
  `sudo make privileged`. It is `continue-on-error` because hosted runners
  may not provide every netfilter module. It has not been executed by the
  author yet.
