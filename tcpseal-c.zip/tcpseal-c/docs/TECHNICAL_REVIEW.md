# Technical Review of the Assignment Constraints (C implementation)

The assignment asks for payload-only AES-GCM encryption, appended tag, no UDP
encapsulation, no custom header, preserved TCP connection, unique nonces, and
handling of retransmissions. This document checks whether these requirements
can coexist and records every deviation or limitation.

| # | Question | Finding | Resolution in tcpseal |
|---|---|---|---|
| 1 | Can the DH handshake be authenticated? | Plain DH is open to man-in-the-middle. A shared password/PSK is weak if it is a demo value committed to Git. | Ed25519 identity keys, generated locally, public keys pinned on the peer; transcript signatures + finished MACs. No secret is in the repository. |
| 2 | How does the receiver learn the nonce without a header? | It must reconstruct it from data already in the packet, or search. | Nonce = HMAC(direction key, canonical header)[:12]; uniqueness enforced at the sender (DESIGN §5). |
| 3 | TCP retransmissions | A retransmission may repeat the sequence number with the same or re-segmented data. Sequence numbers alone are not unique. | Retransmissions differ in IP ID / TSval on Linux → new nonce. A byte-identical header is *dropped*, never re-encrypted under the same nonce. **Limitation**: stacks with constant IP ID and no timestamps may stall on retransmission. |
| 4 | TCP sequence-number behaviour | The tag adds 16 bytes that are not part of the TCP byte stream. | The tag exists only on the inter-device link and is removed before PC2. Sequence and ACK numbers are never modified, so both endpoints see a consistent stream. |
| 5 | IPv4 fragmentation | A protected packet that is fragmented cannot be processed without reassembly; non-first fragments have no TCP ports. | Fragments on the protected path are dropped. DF is set by Linux TCP. Documented limitation. |
| 6 | TCP segmentation and MSS | Full-size segments (MSS 1460) become 1516 bytes. | Peer-link MTU ≥ 1516 is required (demo: 1600). Too-big packets are dropped and counted. Alternatives (documented, not automated): PC MTU 1484 or MSS clamping. Clamping on the devices was rejected because it would modify the original SYN header. |
| 7 | Length change | IPv4 total length, IPv4 checksum and TCP checksum must change. | Recomputed on both devices for every packet. The canonical header uses the *plaintext* length so both sides authenticate the same value. |
| 8 | Kernel MTU check on the receiving device | Discovered during testing: when decryption ran in the FORWARD hook, Device2 dropped every full-size protected segment, because the forwarding MTU check (towards PC2, MTU 1500) happens before FORWARD. | Decryption runs in PREROUTING (raw priority), before routing. |
| 9 | Checksum offloading | Queued packets may carry a partial checksum. | The kernel completes checksums before copying to NFQUEUE; tcpseal recomputes both checksums anyway. Offloads are disabled with ethtool when available. |
| 10 | Session identification | Without a header, the receiver cannot be told which session a packet belongs to. | The receiver tries at most three sessions (pending, current, previous-in-grace). Cost is bounded: 3 × (HMAC + GCM) per packet. |
| 11 | Replay protection | Counter windows reject old packets; header-derived nonces allow an exact set. | Exact set of accepted nonces per session; cleared at rekey. |
| 12 | Compatibility with the original TCP connection | Holds as long as nothing between the devices rewrites the authenticated header fields (no NAT, no header-modifying middlebox). | Documented. |
| 13 | Empty payloads / control packets | With payload-only encryption, SYN/ACK/FIN/RST would pass unauthenticated, enabling RST injection. | Every selected packet gets a tag; for an empty payload the tag is the only added data. This still matches "headers ‖ ciphertext ‖ tag". |
| 14 | Packet-processing loops | Re-injected packets and the handshake must not be queued again. | NF_ACCEPT continues after the queue rule; the control channel is local traffic and never matches FORWARD/non-local PREROUTING rules. |
| 15 | Reproducible demonstration | Four machines are not needed. | Four network namespaces with veth links (`scripts/netns-demo.sh`), nftables or iptables backend. |
| 16 | Public GitHub suitability | Keys, configs with addresses of a real lab, captures and logs must stay local. | Private keys only in `local/` (git-ignored) or temporary directories; examples use RFC 1918 sample addresses; the sniffer writes counters, never packet bytes. |

## Deviations from a literal reading

1. **Control packets are also protected** (tag-only). This goes beyond
   "encrypt the TCP payload" but keeps the required packet format.
2. **Nonce derivation from header fields** instead of a transmitted or
   searched counter. It meets "unique nonce per packet under the same key"
   by enforcement; the cost is the retransmission limitation in row 3.
3. **Retransmissions may be dropped** when they are byte-identical to an
   earlier packet: a deliberate safety-over-availability choice.
4. **The inter-device MTU must be raised by at least 16 bytes.**
