# Attribution and Academic-Integrity Notes

## Relationship to the reference implementation

Before this project was written, the author was given an earlier, independent
C implementation of a similar assignment (OpenSSL 3 + libnetfilter_queue) as a
reference. Although both projects are written in C, tcpseal was **redesigned
and written from scratch**: no source code, configuration files, scripts or
documentation text were copied.

A line-by-line comparison of the two source trees (ignoring whitespace, lines
of 25 characters or more) finds only 12 identical lines, all of them generic
boilerplate or the standard way to call an API, for example
`#include <openssl/rand.h>`, `int main(int argc, char **argv)`,
`(void)sigaction(SIGTERM, &action, NULL);` and
`EVP_KDF *kdf = EVP_KDF_fetch(NULL, "HKDF", NULL);`.

The C version is a port of the author's own Python design (`tcpseal`, same
protocol); the two implementations interoperate.

### Ideas shared with the reference (standard techniques)

| Idea | Note |
|---|---|
| Netfilter queue rules that select one TCP port and hand it to user space without `bypass` (fail-closed) | Standard NFQUEUE usage. tcpseal moves decryption to PREROUTING and supports nftables and iptables. |
| Canonicalising mutable header fields (TTL, checksums, length) before using the headers as AES-GCM associated data | Same principle as IPsec AH (RFC 4302). tcpseal also zeroes ECN bits and uses the canonical header for nonce derivation. |
| Separate keys per direction derived with HKDF | Standard practice (TLS 1.3, IPsec). |
| Raising the inter-device MTU; dropping IPv4 fragments | Direct consequences of the assignment constraints. |
| Four-namespace topology for automated testing | Common technique for network labs. |
| OpenSSL 3 EVP interfaces | Both projects use the documented OpenSSL APIs. |

### What was redesigned (and why)

| Area | Reference | tcpseal (C) |
|---|---|---|
| Packet I/O | libnetfilter_queue | NFQUEUE netlink protocol implemented directly (`src/nfqueue.c`, no extra library) |
| Key exchange | FFDHE2048, optional PSK | X25519 + Ed25519 signatures with pinned public keys (always authenticated) |
| Secrets in repository | Demo PSK committed in configs and test fixtures | No secrets; keys generated locally; private keys readable by group/others are refused |
| Nonce | `prefix ‖ counter`, receiver searches ±128 counters | `HMAC(direction key, canonical header)[:12]`; used-nonce hash set at the sender; exact replay set at the receiver |
| Loss / reordering | Permanent desynchronisation after more than the window of consecutive losses | No synchronisation state; any loss/reordering pattern works |
| Forged-packet cost | Up to ~256 GCM attempts | At most 3 (HMAC + GCM) attempts |
| Control packets (SYN/ACK/FIN/RST) | Passed unauthenticated | Authenticated with a tag-only payload |
| Session lifetime | One handshake at start-up; no rekey/expiry | Timed and packet-count rekey, hard expiry, grace period, pending session, recovery after peer restart |
| Threads | Single process loop | Packet loop + control thread, session manager protected by a mutex |
| Decrypt hook | FORWARD | PREROUTING (raw) – avoids the forwarding MTU drop of full-size protected packets |
| Tests | Unit tests + shell scripts, tcpdump | 8 test programs, ASan/UBSan, valgrind, clang-tidy, loss/tamper/rekey/restart demo phases, cross-implementation interop |

## External libraries and tools

| Component | Used for | License |
|---|---|---|
| OpenSSL 3 (libcrypto) | AES-256-GCM, X25519, Ed25519, HKDF, HMAC, SHA-256, PEM | Apache-2.0 |
| glibc / POSIX threads | sockets, netlink, threads | LGPL-2.1+ (system library) |
| Linux UAPI headers (`linux/netlink.h`, `linux/if_packet.h`) | netlink and packet-socket structures | GPL-2.0 WITH Linux-syscall-note |
| Linux netfilter, iproute2, nftables / iptables | interception, namespaces, routing (system tools, not redistributed) | GPL-2.0 |
| clang-format, clang-tidy, valgrind (development only) | formatting, static analysis, memory checking | Apache-2.0 WITH LLVM-exception / GPL-2.0 |

## Specifications consulted

RFC 791 (IPv4), RFC 9293 (TCP), RFC 1071 (Internet checksum), RFC 5116 and
NIST SP 800-38D (AES-GCM), RFC 5869 (HKDF), RFC 7748 (X25519), RFC 8032
(Ed25519), RFC 4302 (IPsec AH mutable fields), RFC 6864 (IPv4 ID), the Linux
headers `linux/netfilter/nfnetlink_queue.h` and `linux/netlink.h`, and the
OpenSSL 3 manual pages.

## Development assistance

Parts of this project were drafted with the help of an AI assistant. Check
your course's rules on AI tools and adapt this section (for example, by
describing what you wrote, changed or verified yourself) before submitting.
