# Design and Security Analysis (C implementation)

This document explains *how* tcpseal works and *why* each decision was made.
It is written so that every design choice can be defended in an oral exam.

## 1. Goal and topology

```
 PC1 ──────── Device1 ═══════════════ Device2 ──────── PC2
10.0.1.2   10.0.1.1 | 10.0.12.1   10.0.12.2 | 10.0.2.1   10.0.2.2
          host_if      peer_if     peer_if     host_if
```

* PC1 and PC2 run unmodified TCP stacks and keep **one** normal TCP
  connection between them.
* Device1 and Device2 are Linux **routers**, not proxies. They never
  terminate the TCP connection, never change ports or sequence numbers.
* On the `═══` link, the payload of every *selected* TCP packet is
  encrypted with AES-256-GCM and the 16-byte tag is appended.

## 2. Components

The C implementation uses OpenSSL 3 (libcrypto) for all cryptography,
POSIX threads for the control channel and the raw netlink API for NFQUEUE.
Its handshake and packet format are byte-for-byte identical to the Python
version of tcpseal; the two interoperate (verified by the namespace demo).


| Module | Responsibility |
|---|---|
| `src/packet.c` | Parse IPv4/TCP, compute RFC 1071 checksums, finalize lengths/checksums, build the canonical header |
| `src/session.c` | Directional keys, nonce derivation, nonce hash sets, AES-GCM seal/open, session limits, session manager (current/previous/pending) |
| `src/protector.c` | `ts_protect()` = encrypt + append tag, `ts_unprotect()` = verify + decrypt + strip tag |
| `src/handshake.c` | X25519 + Ed25519 authenticated key exchange, HKDF key schedule (pure functions, no sockets) |
| `src/control.c` | Runs the handshake over a TCP control connection; rekey, reconnect, back-off (pthread) |
| `src/nfqueue.c` | Minimal NFQUEUE netlink client (bind queues, receive packets, send verdicts) |
| `src/daemon.c` | Wires everything: control thread + packet loop, statistics, signals |
| `src/config.c`, `src/keys.c`, `src/main.c` | Strict INI parser/validation, key generation/loading, command line |

## 3. Packet path

### 3.1 Firewall hooks (scripts/device-rules.sh)

| Direction on a device | Hook | Match | Queue |
|---|---|---|---|
| host_if → peer_if (leaving towards the other device) | `FORWARD` | `tcp dport PORT` on Device1, `tcp sport PORT` on Device2 | encrypt |
| arriving on peer_if | `PREROUTING`, raw priority (‑300) | `tcp sport PORT` on Device1, `tcp dport PORT` on Device2, destination not local | decrypt |

Why two different hooks?

* **Encrypt in FORWARD.** The kernel's forwarding MTU check runs *before*
  the FORWARD hook, with the original size towards the peer link. After our
  verdict the packet is 16 bytes bigger and is checked once more, against the
  peer-link MTU, when it is transmitted.
* **Decrypt in PREROUTING (raw).** If decryption ran in FORWARD, the
  kernel would first compare the *protected* (+16 byte) packet with the MTU of
  the interface towards the PC and drop full-size segments. This bug was
  found while testing the namespace demo (1500‑byte segments vanished on
  Device2). Running before routing also means connection tracking on the
  devices only ever sees original-size packets.
* The control channel between the devices is *local* traffic
  (INPUT/OUTPUT, different port, local destination), so it can never be
  queued by these rules. A packet re-injected with `NF_ACCEPT` continues
  after the queue rule, so there are no processing loops.
* No `bypass` flag: if the daemon is not running the kernel drops queued
  packets (**fail-closed**).
* IPv4 fragments on the protected path are dropped by a rule; first fragments
  are also rejected by the parser.

### 3.2 Device1, encrypt (`protect`)

1. Parse IPv4 + TCP (options included); reject malformed packets and fragments.
2. Check `len(packet) + 16 <= peer_mtu`, otherwise drop (`too_big`).
3. Take the current, unexpired session (otherwise drop: `no_session`).
4. Build the canonical header *H* (section 5.2).
5. `nonce = HMAC-SHA256(nonce_key_d1→d2, H)[:12]`; refuse if already used.
6. `ciphertext‖tag = AES-256-GCM(key_d1→d2, nonce, payload, aad=H)`.
7. Rebuild: original headers + ciphertext + tag; update IPv4 total length,
   IPv4 header checksum and TCP checksum.
8. Verdict `NF_ACCEPT` with the modified packet; Linux routes it to Device2.

### 3.3 Device2, decrypt (`unprotect`)

1. Parse; the payload must be at least 16 bytes (the tag).
2. Build *H* with *plaintext length = payload length − 16*.
3. For each candidate session (pending, current, previous — at most three):
   derive the nonce from *H*, reject if already accepted (replay), verify the
   tag and decrypt.
4. On success: rebuild with the plaintext, fix length and checksums, accept.
5. If no session verifies the tag: `NF_DROP`.

The reverse direction (PC2 → PC1) is identical with the Device2→Device1 keys.

### 3.4 Control packets (SYN, pure ACK, FIN, RST)

They are protected too: the ciphertext is empty and only the 16-byte tag is
appended. The wire format is still *headers ‖ ciphertext ‖ tag*. Benefit: an
attacker on the inter-device link cannot inject a forged RST or FIN, and the
TCP three-way handshake is authenticated. Device2 removes the tag, so PC2
receives the original empty segment.

## 4. Handshake (authenticated Diffie–Hellman)

```
Device1                                              Device2
  M1: random_1, X25519 pub_1           ───────▶
                                       ◀───────  M2: random_2, X25519 pub_2,
                                                     Sign_D2("device2 sig" ‖ th)
  M3: Sign_D1("device1 sig" ‖ th),     ───────▶
      HMAC(confirm, "device1 finished" ‖ th)        (Device2 installs keys)
                                       ◀───────  M4: HMAC(confirm, "device2 finished" ‖ th)
  (Device1 installs keys)

th  = SHA-256(M1 ‖ M2 without signature)
okm = HKDF-SHA256(ikm = X25519 shared secret, salt = random_1 ‖ random_2,
                  info = "tcpseal-v1 session keys" ‖ th, L = 160)
    = aes_d1→d2 ‖ aes_d2→d1 ‖ nonce_d1→d2 ‖ nonce_d2→d1 ‖ confirm   (5 × 32 bytes)
```

* **Ephemeral X25519** for every handshake → each session has fresh keys
  (forward secrecy: stealing an identity key later does not decrypt
  recorded traffic).
* **Ed25519 identity keys with pinning.** Each device knows the other
  device's public key in advance (like SSH `known_hosts`). Both devices sign
  the transcript hash, which covers both ephemeral keys and both randoms, so a
  man-in-the-middle cannot substitute its own DH key without the private
  identity key. The signature labels contain the role, so a signature cannot
  be reflected.
* **Key confirmation.** The finished MACs prove both sides derived the same
  keys before any data packet is encrypted with them.
* **Ordering during rekey.** Device2 installs the new session *before*
  sending M4. Device1 can already decrypt with the new keys after M2
  ("pending" session) but only encrypts with them after verifying M4. So
  neither side ever receives packets under keys it does not have yet.
* All handshake messages have fixed sizes; wrong magic, type, length,
  signature, MAC or a low-order DH point abort the handshake.

### Session lifetime and failures

| Event | Behaviour |
|---|---|
| Session age ≥ `rekey_interval`, or 80 % of `max_packets` in either direction | Device1 starts a new handshake on the existing control connection |
| Session age ≥ `lifetime` or `max_packets` reached | The session is never used again (hard expiry, on both devices); traffic is dropped until a new handshake succeeds |
| After a rekey | The previous session may still **decrypt** for 10 s (packets in flight), never encrypt |
| Handshake fails (timeout, bad signature, bad MAC, connection refused) | Logged; Device1 retries with exponential back-off (1 s … 30 s); no new session is installed |
| Device2 restarts (loses its keys) | Device1 notices the closed control connection, reconnects and performs a fresh handshake |
| Device1 restarts | It connects again; Device2 answers and replaces its session |

## 5. Nonce management without a header

### 5.1 The problem

AES-GCM is catastrophically broken if one (key, nonce) pair is used for two
different messages: the XOR of the plaintexts leaks, and the GHASH
authentication key can be recovered, which allows forgeries. The receiver
must know the nonce, but the assignment forbids sending it in a custom header.

Options considered:

| Option | Verdict |
|---|---|
| Nonce = TCP sequence number (+ ports) | **Insecure.** A retransmission may re-segment the same sequence number with different data or length (different plaintext under the same nonce); sequence numbers wrap after 4 GiB; two connections can share numbers. |
| Implicit counter, receiver tries the next N counters (reference design) | Unique, but the receiver gets **permanently out of sync** after more than N consecutive losses, and every forged packet costs up to ~2N GCM attempts (CPU denial of service). |
| Put the counter into a header field (e.g. IP ID) | Modifies original header fields and 16 bits are far too few. |
| Send the counter in the packet | A custom header/trailer: forbidden. |
| **Derive the nonce from header fields with a secret key, and enforce uniqueness at the sender** | Chosen. Details below. |

### 5.2 Chosen design

```
H     = canonical header (IPv4 header + TCP header incl. options) with
        TTL = 0, IPv4 checksum = 0, TCP checksum = 0, ECN bits = 0,
        IPv4 total length = length of the *plaintext* packet
nonce = first 12 bytes of HMAC-SHA256(nonce_key_direction, H)
```

* *H* contains source/destination address, ports, sequence and
  acknowledgement number, IP identification, flags, window, TCP options
  (e.g. the TCP timestamp) and the plaintext length. The receiver sees
  exactly the same bytes, so it recomputes the nonce directly: **no search,
  no state that can get out of sync, loss and reordering do not matter**.
* The same *H* is the AES-GCM associated data, so every header field in *H*
  is authenticated. TTL, checksums and ECN are excluded because they may
  legitimately change on the way (the same idea as IPsec AH "mutable fields",
  RFC 4302).
* **Uniqueness is enforced, not assumed.** The sender stores every nonce used
  in the session. If a packet would map to an already used nonce (only
  possible if its canonical header is byte-identical to an earlier packet, or
  after a truncated-HMAC collision, probability ≈ n²/2⁹⁷ for n packets), the packet is **dropped instead of
  encrypted**. TCP then retransmits it later.
* **Independent nonce spaces per direction**: separate nonce keys *and*
  separate AES keys for Device1→Device2 and Device2→Device1.
* **Per-session**: a new handshake gives new keys and empty nonce sets.
* **Replay protection**: the receiver stores every nonce it has accepted;
  a replayed packet has the same header → same nonce → rejected. This is
  exact (no window), and reordering is harmless.
* **Memory bound**: both sets are bounded by `max_packets` per session
  (the hash sets grow on demand; 16 bytes per slot, at most half full, so
  at most about 8 MB per set at the default of 200 000 packets); rekeying at 80 % clears
  them.

### 5.3 Retransmissions

A TCP retransmission carries the same sequence number and the same data, but
Linux gives every transmitted segment a new IP identification value (per
socket counter) and, with TCP timestamps (on by default), a new `TSval`.
Therefore the canonical header differs and the retransmission gets a fresh
nonce and a fresh ciphertext. The namespace demo verifies this: with 10 % of
protected packets dropped, the transfer still succeeds and the counter
`encrypt_drop_NonceReuseError` stays at zero.

**Limitation:** a TCP stack that sends *byte-identical* retransmissions
(constant IP ID and no timestamps) would have those retransmissions dropped by
Device1. That reduces availability (the connection may stall) but never
weakens confidentiality or integrity. The prototype prefers the safe failure.

## 6. Threat model

**Attacker capabilities considered**: full control of the Device1↔Device2
link — read, drop, delay, reorder, replay, modify and inject packets; connect
to the control port; replay old handshake messages.

**Protected**

* Confidentiality of selected TCP payloads on the inter-device link.
* Integrity and authenticity of payloads *and* of the non-mutable header
  fields (addresses, ports, sequence/ack numbers, flags, window, options,
  IP ID, length), including for packets without payload.
* Replay of protected packets within a session; replay across sessions fails
  because keys differ.
* Man-in-the-middle on the handshake (signatures with pinned keys).
* Forward secrecy for past sessions (ephemeral X25519).

**Not protected / out of scope**

* Traffic analysis: packet sizes, timing, addresses and ports are visible
  (headers must stay in clear by assignment).
* Traffic that is not selected by the firewall rules (other ports, UDP,
  ICMP, IPv6) passes unchanged.
* The PC1↔Device1 and Device2↔PC2 segments (trusted local networks).
* Compromised devices or stolen identity private keys.
* Denial of service: an attacker on the link can always drop packets.
* Side channels. (Session keys and handshake secrets are erased with
  `OPENSSL_cleanse` when a session is freed, but a prototype cannot
  prevent swapping or core dumps.)

## 7. Known technical constraints

| Topic | Constraint and handling |
|---|---|
| Packet growth (+16 bytes) | Peer-link MTU must be ≥ endpoint MTU + 16 (demo: 1600). Otherwise Device1 drops full-size segments (`too_big`) and no ICMP is generated. Alternatives: lower the PC MTU to 1484, or MSS clamping on the PCs. |
| IPv4 fragmentation | Not supported; fragments on the protected path are dropped. |
| Checksum offload | Packets from NFQUEUE always carry a complete checksum (the kernel computes it before queueing), and tcpseal recomputes both checksums for every output packet. |
| GRO/GSO/TSO | NFQUEUE re-segments GSO packets when the `F_GSO` flag is not requested (tcpseal does not request it). The rules script also disables offloads if `ethtool` exists. |
| NAT between the devices | Not supported: addresses/ports are authenticated. |
| Middleboxes between the devices | Anything that rewrites headers or strips unknown data breaks authentication. Devices are expected to be directly connected (or via plain routers). |
| Performance | Single-threaded packet loop with one AES-GCM context per direction; adequate for a lab, not tuned for line rate. |
| Netlink attribute size | A modified packet must fit a 16-bit netlink attribute, so `peer_mtu` is limited to 65 000. |
