# Contributing

This is an educational prototype. Issues and pull requests that improve
clarity, correctness or tests are welcome.

1. Install the build dependencies (see README) and run `make`.
2. Keep changes small and explain *why* in the commit message.
3. Before opening a pull request run:
   `make format-check && make test && make asan` (and `make lint` if clang-tidy is installed).
4. If you touch packet handling or scripts, also run `sudo make privileged`.
5. Never commit keys, real lab configurations, logs or packet captures.
