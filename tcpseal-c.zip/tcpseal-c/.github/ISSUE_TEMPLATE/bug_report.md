---
name: Bug report
about: Something does not work as documented
labels: bug
---

**What happened?**

**What did you expect?**

**How to reproduce** (commands, config with addresses anonymised – never include keys)

**Environment**
- Distribution and kernel (`uname -r`):
- Compiler and OpenSSL versions (`cc --version`, `openssl version`):
- Firewall backend (nft or iptables, from `scripts/device-rules.sh show`):

**Logs** (`KEEP_LOGS=1 LOG_LEVEL=debug sudo scripts/netns-demo.sh`, trimmed)
