## Summary

## Checklist
- [ ] `make format-check` and `make test` pass
- [ ] `make asan` passes (no sanitizer reports)
- [ ] Privileged demo run (`sudo make privileged`) if packet handling or scripts changed
- [ ] Documentation updated
- [ ] No keys, real configs, logs or captures added
