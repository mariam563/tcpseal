# local/ — machine-specific files (git-ignored)

Everything in this directory except this README is ignored by git.
Put your real configuration and **all key files** here:

```
local/
├── device1.ini        # copied from examples/device1.example.ini
└── keys/
    ├── device1.key    # PRIVATE – created by `bin/tcpseal keygen`, mode 0600
    ├── device1.pub    # public – copy to the other device
    └── device2.pub    # the peer's public key, copied from Device2
```
