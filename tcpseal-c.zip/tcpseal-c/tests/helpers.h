/*
 * helpers.h - build test packets and matching Device1/Device2 sessions.
 */
#ifndef TCPSEAL_TEST_HELPERS_H
#define TCPSEAL_TEST_HELPERS_H

#include "tcpseal/handshake.h"
#include "tcpseal/packet.h"
#include "tcpseal/session.h"

#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const ts_limits TEST_LIMITS = {240, 300, 200000};

typedef struct {
    const char *src, *dst;
    uint16_t sport, dport;
    uint32_t seq, ack;
    uint8_t flags;
    uint16_t ip_id;
    uint8_t ttl;
    const uint8_t *options;
    size_t options_len; /* multiple of 4 */
} pkt_spec;

static inline pkt_spec default_spec(void)
{
    pkt_spec s = {"10.0.1.2", "10.0.2.2", 40000, 5001, 1000, 2000, 0x18, 1, 64, NULL, 0};
    return s;
}

/* Build a valid TCP/IPv4 packet with correct checksums; returns its length. */
static inline size_t make_packet_spec(const pkt_spec *s, const void *payload, size_t payload_len,
                                      uint8_t *out)
{
    uint8_t headers[TS_MAX_HEADERS];
    size_t tcp_len = 20 + s->options_len;
    memset(headers, 0, sizeof(headers));
    headers[0] = 0x45;
    ts_put16(headers + 4, s->ip_id);
    ts_put16(headers + 6, 0x4000); /* DF */
    headers[8] = s->ttl;
    headers[9] = 6;
    (void)inet_pton(AF_INET, s->src, headers + 12);
    (void)inet_pton(AF_INET, s->dst, headers + 16);
    uint8_t *tcp = headers + 20;
    ts_put16(tcp, s->sport);
    ts_put16(tcp + 2, s->dport);
    ts_put32(tcp + 4, s->seq);
    ts_put32(tcp + 8, s->ack);
    tcp[12] = (uint8_t)((tcp_len / 4) << 4);
    tcp[13] = s->flags;
    ts_put16(tcp + 14, 64240);
    if (s->options_len > 0) {
        memcpy(tcp + 20, s->options, s->options_len);
    }
    size_t len = 0;
    (void)ts_packet_build(headers, 20, tcp_len, payload, payload_len, out, 70000, &len);
    return len;
}

static inline size_t make_packet(const char *payload, uint8_t *out)
{
    pkt_spec s = default_spec();
    return make_packet_spec(&s, payload, strlen(payload), out);
}

/* Run a real in-memory handshake and return matching sessions. */
static inline void handshake_pair(ts_session **d1, ts_session **d2)
{
    EVP_PKEY *id1 = EVP_PKEY_Q_keygen(NULL, NULL, "ED25519");
    EVP_PKEY *id2 = EVP_PKEY_Q_keygen(NULL, NULL, "ED25519");
    ts_handshake a, b;
    ts_session_keys k1, k2;
    uint8_t m1[TS_HS_HELLO_LEN], m2[TS_HS_REPLY_LEN], m3[TS_HS_FINISH_LEN], m4[TS_HS_CONFIRM_LEN];
    char err[TS_ERR_LEN];
    (void)ts_handshake_init(&a, id1, id2, err);
    (void)ts_handshake_init(&b, id2, id1, err);
    (void)ts_initiator_hello(&a, m1);
    (void)ts_responder_reply(&b, m1, sizeof(m1), m2, err);
    (void)ts_initiator_finish(&a, m2, sizeof(m2), m3, &k1, err);
    (void)ts_responder_confirm(&b, m3, sizeof(m3), m4, &k2, err);
    (void)ts_initiator_confirm(&a, m4, sizeof(m4), err);
    *d1 = ts_session_new(k1.session_id, &k1.tx, &k1.rx, &TEST_LIMITS);
    *d2 = ts_session_new(k2.session_id, &k2.tx, &k2.rx, &TEST_LIMITS);
    ts_handshake_clear(&a);
    ts_handshake_clear(&b);
    EVP_PKEY_free(id1);
    EVP_PKEY_free(id2);
}

/* Two managers with matching current sessions. */
static inline void manager_pair(ts_manager *m1, ts_manager *m2)
{
    ts_session *s1, *s2;
    handshake_pair(&s1, &s2);
    ts_manager_init(m1, TS_PREVIOUS_GRACE_SECONDS);
    ts_manager_init(m2, TS_PREVIOUS_GRACE_SECONDS);
    ts_manager_install(m1, s1);
    ts_manager_install(m2, s2);
}

/* Create a fresh temporary directory (removed by the caller with rm_rf). */
static inline void make_temp_dir(char *path, size_t size)
{
    const char *base = getenv("TMPDIR") != NULL ? getenv("TMPDIR") : "/tmp";
    (void)snprintf(path, size, "%s/tcpseal-test.XXXXXX", base);
    if (mkdtemp(path) == NULL) {
        path[0] = '\0';
    }
}

static inline void rm_rf(const char *path)
{
    char cmd[4200];
    if (path[0] != '\0' && strstr(path, "tcpseal-test.") != NULL) {
        (void)snprintf(cmd, sizeof(cmd), "rm -rf '%s'", path);
        if (system(cmd) != 0) {
            (void)fprintf(stderr, "warning: could not remove %s\n", path);
        }
    }
}

#endif
