#!/usr/bin/env bash
# Privileged test: full PC1 -> Device1 -> Device2 -> PC2 path in network
# namespaces. Needs root, iproute2 (ip), nftables (nft), iptables or the
# nft_queue module, and nfnetlink_queue. Skips (exit 0) when not root.
#   make && sudo tests/privileged/test_netns_demo.sh
set -uo pipefail
REPO=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)
if [[ ${EUID} -ne 0 ]]; then
    echo "skip test_netns_demo: requires root"
    exit 0
fi
for cmd in ip nft; do
    command -v "$cmd" >/dev/null || { echo "skip test_netns_demo: requires $cmd"; exit 0; }
done
output=$("$REPO/scripts/netns-demo.sh" 2>&1)
status=$?
echo "$output"
if [[ $status -eq 0 ]] && grep -q "ALL PHASES PASSED" <<<"$output"; then
    echo "test_netns_demo: PASSED"
    exit 0
fi
echo "test_netns_demo: FAILED"
exit 1
