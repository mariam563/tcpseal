#!/usr/bin/env bash
# Command-line tests: keygen, check-config, exit codes, missing secrets,
# unsafe key permissions and missing privileges. No root needed.
#   tests/integration/test_cli.sh bin/tcpseal
set -uo pipefail

TCPSEAL=$(realpath "${1:-bin/tcpseal}")
WORK=$(mktemp -d -t tcpseal-test.XXXXXX)
trap 'rm -rf -- "$WORK"' EXIT
failures=0
count=0

check() {  # description expected_exit command...
    local description=$1 expected=$2
    shift 2
    count=$((count + 1))
    "$@" >"$WORK/out" 2>&1
    local status=$?
    if [[ $status -eq $expected ]]; then
        echo "ok   $description"
    else
        echo "FAIL $description (exit $status, expected $expected)"
        sed 's/^/     /' "$WORK/out"
        failures=$((failures + 1))
    fi
}

output_contains() {  # description text
    count=$((count + 1))
    if grep -q -- "$2" "$WORK/out"; then echo "ok   $1"; else echo "FAIL $1"; failures=$((failures + 1)); fi
}

cat >"$WORK/device1.ini" <<'EOF'
[device]
role = device1
identity_key = keys/device1.key
peer_public_key = keys/device2.pub
[control]
address = 10.0.12.2
EOF

check "version" 0 "$TCPSEAL" --version
check "unknown command" 2 "$TCPSEAL" frobnicate
check "check-config with missing key" 2 "$TCPSEAL" check-config "$WORK/device1.ini"
output_contains "missing key message" "identity key not found"
check "keygen device1" 0 "$TCPSEAL" keygen --name device1 --dir "$WORK/keys"
check "keygen refuses overwrite" 2 "$TCPSEAL" keygen --name device1 --dir "$WORK/keys"
check "keygen device2" 0 "$TCPSEAL" keygen --name device2 --dir "$WORK/keys"
check "check-config ok" 0 "$TCPSEAL" check-config "$WORK/device1.ini"
output_contains "check-config summary" "OK: role=device1"
chmod 644 "$WORK/keys/device1.key"
check "world-readable key refused" 2 "$TCPSEAL" run "$WORK/device1.ini"
output_contains "permission message" "unsafe permissions"
chmod 600 "$WORK/keys/device1.key"
if [[ ${EUID} -ne 0 ]]; then
    check "run without CAP_NET_ADMIN" 3 "$TCPSEAL" run "$WORK/device1.ini"
    output_contains "privilege message" "CAP_NET_ADMIN"
elif command -v setpriv >/dev/null && setpriv --reuid=65534 --regid=65534 --clear-groups true 2>/dev/null; then
    chmod -R a+rX "$WORK" && chmod 755 "$WORK/keys"
    cp "$WORK/keys/device1.key" "$WORK/nobody.key" && chown 65534 "$WORK/nobody.key" && chmod 600 "$WORK/nobody.key"
    sed "s#keys/device1.key#nobody.key#" "$WORK/device1.ini" >"$WORK/nobody.ini"
    check "run without CAP_NET_ADMIN (as nobody)" 3 setpriv --reuid=65534 --regid=65534 --clear-groups \
        "$TCPSEAL" run "$WORK/nobody.ini"
    output_contains "privilege message" "CAP_NET_ADMIN"
else
    echo "skip run without CAP_NET_ADMIN (running as root without setpriv)"
fi

echo "test_cli: $count tests, $failures failed"
echo
exit $(( failures > 0 ))
