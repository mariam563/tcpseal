/*
 * Control channel over real TCP sockets on 127.0.0.1 (no root needed):
 * handshake over the network, automatic rekey, wrong keys, retry until the
 * responder appears, and Device2 restart (session restart).
 */
#include "helpers.h"
#include "test.h"

#include "tcpseal/control.h"
#include "tcpseal/protector.h"

#include <pthread.h>
#include <time.h>

static const ts_limits SLOW = {600, 900, 100000};
static const ts_limits FAST = {1.0, 30, 100000};

typedef struct {
    EVP_PKEY *id1, *id2;
    ts_manager m1, m2;
    atomic_int stop1, stop2;
    ts_channel c1, c2;
    pthread_t t1, t2;
    int running1, running2;
} pair;

static void sleep_ms(int ms)
{
    struct timespec ts = {ms / 1000, (long)(ms % 1000) * 1000000L};
    (void)nanosleep(&ts, NULL);
}

static int start_responder(pair *p, uint16_t port, const ts_limits *limits)
{
    char err[TS_ERR_LEN];
    atomic_store(&p->stop2, 0);
    ts_channel_init(&p->c2, "127.0.0.1", port, p->id2, p->id1, &p->m2, limits, 2.0, &p->stop2);
    if (ts_responder_listen(&p->c2, err) != 0) {
        (void)fprintf(stderr, "    %s\n", err);
        return -1;
    }
    p->running2 = pthread_create(&p->t2, NULL, ts_responder_run, &p->c2) == 0;
    return 0;
}

static void stop_responder(pair *p)
{
    if (p->running2) {
        atomic_store(&p->stop2, 1);
        (void)pthread_join(p->t2, NULL);
        p->running2 = 0;
    }
}

static void start_initiator(pair *p, uint16_t port, EVP_PKEY *pinned, const ts_limits *limits)
{
    atomic_store(&p->stop1, 0);
    ts_channel_init(&p->c1, "127.0.0.1", port, p->id1, pinned, &p->m1, limits, 1.0, &p->stop1);
    p->running1 = pthread_create(&p->t1, NULL, ts_initiator_run, &p->c1) == 0;
}

static void pair_init(pair *p)
{
    memset(p, 0, sizeof(*p));
    p->id1 = EVP_PKEY_Q_keygen(NULL, NULL, "ED25519");
    p->id2 = EVP_PKEY_Q_keygen(NULL, NULL, "ED25519");
    ts_manager_init(&p->m1, 10);
    ts_manager_init(&p->m2, 10);
}

static void pair_close(pair *p)
{
    if (p->running1) {
        atomic_store(&p->stop1, 1);
        (void)pthread_join(p->t1, NULL);
    }
    stop_responder(p);
    ts_manager_destroy(&p->m1);
    ts_manager_destroy(&p->m2);
    EVP_PKEY_free(p->id1);
    EVP_PKEY_free(p->id2);
}

/* Both managers have the same current session (optionally != old_id). */
static int same_session(pair *p, const char *old_id)
{
    ts_session_info a, b;
    if (!ts_manager_current_info(&p->m1, ts_now(), &a) || !ts_manager_current_info(&p->m2, ts_now(), &b)) {
        return 0;
    }
    return strcmp(a.id, b.id) == 0 && (old_id == NULL || strcmp(a.id, old_id) != 0);
}

static int wait_same_session(pair *p, const char *old_id, int timeout_ms)
{
    for (int waited = 0; waited < timeout_ms; waited += 50) {
        if (same_session(p, old_id)) {
            return 1;
        }
        sleep_ms(50);
    }
    return 0;
}

static int roundtrip(pair *p)
{
    static uint8_t in[200], prot[300], out[300];
    size_t len = make_packet("request from PC1", in), plen, olen;
    return ts_protect(in, len, &p->m1, 1600, prot, &plen) == TS_PASS &&
           ts_unprotect(prot, plen, &p->m2, out, &olen) == TS_PASS && olen == len &&
           memcmp(in, out, len) == 0;
}

TEST(handshake_over_tcp_and_data_protection)
{
    pair p;
    pair_init(&p);
    int ok = start_responder(&p, 0, &SLOW) == 0;
    if (ok) {
        start_initiator(&p, p.c2.port, p.id2, &SLOW);
    }
    ok = ok && wait_same_session(&p, NULL, 5000) && roundtrip(&p);
    pair_close(&p);
    CHECK(ok);
}

TEST(automatic_rekey)
{
    pair p;
    ts_session_info first;
    pair_init(&p);
    int ok = start_responder(&p, 0, &FAST) == 0;
    if (ok) {
        start_initiator(&p, p.c2.port, p.id2, &FAST);
    }
    ok = ok && wait_same_session(&p, NULL, 5000) && ts_manager_current_info(&p.m1, ts_now(), &first);
    ok = ok && wait_same_session(&p, first.id, 8000);
    int completed = atomic_load(&p.c1.handshakes_completed);
    pair_close(&p);
    CHECK(ok);
    CHECK(completed >= 2);
}

TEST(wrong_peer_key_never_creates_a_session)
{
    pair p;
    ts_session_info info;
    pair_init(&p);
    EVP_PKEY *wrong = EVP_PKEY_Q_keygen(NULL, NULL, "ED25519");
    int ok = start_responder(&p, 0, &SLOW) == 0;
    if (ok) {
        start_initiator(&p, p.c2.port, wrong, &SLOW);
    }
    for (int i = 0; i < 100 && atomic_load(&p.c1.handshakes_failed) == 0; ++i) {
        sleep_ms(50);
    }
    int failed = atomic_load(&p.c1.handshakes_failed) >= 1;
    int none =
        !ts_manager_current_info(&p.m1, ts_now(), &info) && !ts_manager_current_info(&p.m2, ts_now(), &info);
    static uint8_t in[200], prot[300];
    size_t len = make_packet("must not leave unprotected", in), plen;
    int dropped = ts_protect(in, len, &p.m1, 1600, prot, &plen) == TS_DROP_NO_SESSION;
    pair_close(&p);
    EVP_PKEY_free(wrong);
    CHECK(ok && failed && none && dropped);
}

TEST(initiator_retries_until_responder_appears)
{
    pair p;
    pair_init(&p);
    /* Find a free port, release it, start Device1 first. */
    int ok = start_responder(&p, 0, &SLOW) == 0;
    uint16_t port = p.c2.port;
    stop_responder(&p);
    start_initiator(&p, port, p.id2, &SLOW);
    for (int i = 0; i < 100 && atomic_load(&p.c1.handshakes_failed) == 0; ++i) {
        sleep_ms(50);
    }
    int failed_first = atomic_load(&p.c1.handshakes_failed) >= 1;
    ok = ok && start_responder(&p, port, &SLOW) == 0 && wait_same_session(&p, NULL, 8000);
    pair_close(&p);
    CHECK(failed_first && ok);
}

TEST(device2_restart_triggers_new_session)
{
    pair p;
    ts_session_info old;
    pair_init(&p);
    int ok = start_responder(&p, 0, &SLOW) == 0;
    uint16_t port = p.c2.port;
    if (ok) {
        start_initiator(&p, port, p.id2, &SLOW);
    }
    ok = ok && wait_same_session(&p, NULL, 5000) && ts_manager_current_info(&p.m1, ts_now(), &old);
    /* Restart Device2: it loses all its keys. */
    stop_responder(&p);
    ts_manager_clear(&p.m2);
    ok = ok && start_responder(&p, port, &SLOW) == 0;
    ok = ok && wait_same_session(&p, old.id, 15000) && roundtrip(&p);
    pair_close(&p);
    CHECK(ok);
}

int main(void)
{
    ts_log_setup(TS_LOG_ERROR, "test"); /* keep the output readable */
    RUN(handshake_over_tcp_and_data_protection);
    RUN(automatic_rekey);
    RUN(wrong_peer_key_never_creates_a_session);
    RUN(initiator_retries_until_responder_appears);
    RUN(device2_restart_triggers_new_session);
    return test_summary("test_control");
}
