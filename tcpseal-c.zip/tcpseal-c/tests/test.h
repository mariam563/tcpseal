/*
 * test.h - a deliberately tiny unit-test framework (no external dependency).
 *
 *   TEST(name) { CHECK(condition); CHECK_EQ(a, b); }
 *   int main(void) { RUN(name); ...; return test_summary("file"); }
 *
 * A failed CHECK prints file:line and the condition, and ends that test.
 */
#ifndef TCPSEAL_TEST_H
#define TCPSEAL_TEST_H

#include <stdio.h>
#include <string.h>

static int test_failures;
static int test_count;
static int test_current_failed;

#define TEST(name) static void name(void)

#define CHECK(cond)                                                                                          \
    do {                                                                                                     \
        if (!(cond)) {                                                                                       \
            (void)fprintf(stderr, "  %s:%d: CHECK failed: %s\n", __FILE__, __LINE__, #cond);                 \
            test_current_failed = 1;                                                                         \
            return;                                                                                          \
        }                                                                                                    \
    } while (0)

#define CHECK_EQ(a, b)                                                                                       \
    do {                                                                                                     \
        long long check_a_ = (long long)(a), check_b_ = (long long)(b);                                      \
        if (check_a_ != check_b_) {                                                                          \
            (void)fprintf(stderr, "  %s:%d: CHECK_EQ failed: %s == %s (%lld != %lld)\n", __FILE__, __LINE__, \
                          #a, #b, check_a_, check_b_);                                                       \
            test_current_failed = 1;                                                                         \
            return;                                                                                          \
        }                                                                                                    \
    } while (0)

#define RUN(name)                                                                                            \
    do {                                                                                                     \
        test_current_failed = 0;                                                                             \
        test_count++;                                                                                        \
        name();                                                                                              \
        (void)printf("%s %s\n", test_current_failed ? "FAIL" : "ok  ", #name);                               \
        test_failures += test_current_failed;                                                                \
    } while (0)

static inline int test_summary(const char *suite)
{
    (void)printf("%s: %d tests, %d failed\n\n", suite, test_count, test_failures);
    return test_failures == 0 ? 0 : 1;
}

#endif
