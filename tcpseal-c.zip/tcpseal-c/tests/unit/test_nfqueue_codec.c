/* Netlink encoding/decoding of the NFQUEUE client and the packet processor. */
#include "helpers.h"
#include "test.h"

#include "tcpseal/daemon.h"
#include "tcpseal/nfqueue.h"

#include <linux/netlink.h>

/* Build an NFQNL_MSG_PACKET message the way the kernel sends it. */
static size_t kernel_packet_message(uint8_t *buf, size_t cap, uint16_t queue, uint32_t id,
                                    const uint8_t *payload, size_t payload_len)
{
    uint8_t hdr[7];
    ts_put32(hdr, id);
    ts_put16(hdr + 4, 0x0800);
    hdr[6] = 2;
    size_t len = ts_nfq_begin(buf, cap, TS_NFQ_MSG_PACKET, 0, 0, queue);
    len = ts_nl_put_attr(buf, len, cap, TS_NFQA_PACKET_HDR, hdr, sizeof(hdr));
    len = ts_nl_put_attr(buf, len, cap, TS_NFQA_PAYLOAD, payload, payload_len);
    ts_nfq_end(buf, len);
    return len;
}

TEST(packet_message_roundtrip)
{
    uint8_t pkt[200], msg[400];
    size_t plen = make_packet("abc", pkt);
    size_t len = kernel_packet_message(msg, sizeof(msg), 101, 77, pkt, plen);
    const struct nlmsghdr *nlh = (const struct nlmsghdr *)(void *)msg;
    CHECK_EQ(nlh->nlmsg_len, len);
    CHECK_EQ(nlh->nlmsg_type, (3 << 8) | 0);
    ts_queued_packet parsed;
    CHECK(ts_nfq_parse_packet(msg + TS_NLMSG_HDRLEN, len - TS_NLMSG_HDRLEN, &parsed) == 0);
    CHECK_EQ(parsed.queue, 101);
    CHECK_EQ(parsed.packet_id, 77);
    CHECK_EQ(parsed.payload_len, plen);
    CHECK(memcmp(parsed.payload, pkt, plen) == 0);
}

TEST(attribute_padding_and_lookup)
{
    uint8_t buf[64];
    size_t len = ts_nl_put_attr(buf, 0, sizeof(buf), 1, "a", 1);
    CHECK_EQ(len, 8);
    len = ts_nl_put_attr(buf, len, sizeof(buf), 2, "bcde", 4);
    CHECK_EQ(len, 16);
    size_t alen = 0;
    const uint8_t *a = ts_nl_find_attr(buf, len, 2, &alen);
    CHECK(a != NULL && alen == 4 && memcmp(a, "bcde", 4) == 0);
    CHECK(ts_nl_find_attr(buf, len, 9, &alen) == NULL);
    CHECK_EQ(ts_nl_put_attr(buf, 60, sizeof(buf), 1, "toolong", 7), 0); /* overflow detected */
}

TEST(verdict_header_layout)
{
    uint8_t buf[64];
    uint8_t verdict[8];
    ts_put32(verdict, TS_NF_ACCEPT);
    ts_put32(verdict + 4, 9);
    size_t len = ts_nfq_begin(buf, sizeof(buf), TS_NFQ_MSG_VERDICT, TS_NLM_F_REQUEST, 5, 100);
    len = ts_nl_put_attr(buf, len, sizeof(buf), TS_NFQA_VERDICT_HDR, verdict, sizeof(verdict));
    ts_nfq_end(buf, len);
    const struct nlmsghdr *nlh = (const struct nlmsghdr *)(void *)buf;
    CHECK_EQ(nlh->nlmsg_type, (3 << 8) | 1);
    CHECK_EQ(nlh->nlmsg_seq, 5);
    CHECK_EQ(ts_get16(buf + 18), 100); /* queue number in nfgenmsg, big-endian */
    size_t alen;
    const uint8_t *v = ts_nl_find_attr(buf + 20, len - 20, TS_NFQA_VERDICT_HDR, &alen);
    CHECK(v != NULL && ts_get32(v) == TS_NF_ACCEPT && ts_get32(v + 4) == 9);
}

TEST(processor_verdicts_and_stats)
{
    static ts_processor p1, p2;
    static ts_config cfg;
    ts_manager d1, d2;
    uint8_t pkt[200];
    static uint8_t prot_copy[300];
    const uint8_t *out;
    size_t out_len, plen = make_packet("data", pkt);
    char json[1024];
    cfg.encrypt_queue = 100;
    cfg.decrypt_queue = 101;
    cfg.peer_mtu = 1600;
    manager_pair(&d1, &d2);
    p1.config = p2.config = &cfg;
    p1.sessions = &d1;
    p2.sessions = &d2;

    ts_queued_packet q = {100, 1, pkt, plen};
    int a = ts_processor_handle(&p1, &q, &out, &out_len);
    memcpy(prot_copy, out, out_len);
    ts_queued_packet q2 = {101, 2, prot_copy, out_len};
    int b = ts_processor_handle(&p2, &q2, &out, &out_len);
    int restored = out_len == plen && memcmp(out, pkt, plen) == 0;
    int c = ts_processor_handle(&p2, &q2, &out, &out_len); /* replay */
    ts_queued_packet empty = {101, 3, NULL, 0};
    int d = ts_processor_handle(&p2, &empty, &out, &out_len);
    ts_stats_json(&p2.stats, json, sizeof(json));
    ts_manager_destroy(&d1);
    ts_manager_destroy(&d2);
    CHECK(a == 1 && b == 1 && restored);
    CHECK(c == 0 && d == 0);
    CHECK(strcmp(json, "{\"decrypt_drop_ReplayError\": 1, \"decrypt_drop_no_payload\": 1, "
                       "\"decrypted\": 1}") == 0);
}

int main(void)
{
    RUN(packet_message_roundtrip);
    RUN(attribute_padding_and_lookup);
    RUN(verdict_header_layout);
    RUN(processor_verdicts_and_stats);
    return test_summary("test_nfqueue_codec");
}
