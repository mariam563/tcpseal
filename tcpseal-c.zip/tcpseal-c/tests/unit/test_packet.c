/* IPv4/TCP parsing, checksums and canonical header (test requirement 7). */
#include "helpers.h"
#include "test.h"

#include "tcpseal/packet.h"

/* Byte-wise reference implementation of RFC 1071, used only to cross-check. */
static uint16_t independent_checksum(const uint8_t *data, size_t len)
{
    uint32_t total = 0;
    for (size_t i = 0; i < len; i += 2) {
        total += (uint32_t)(data[i] << 8) + (i + 1 < len ? data[i + 1] : 0);
        total = (total & 0xFFFF) + (total >> 16);
    }
    return (uint16_t)(~total & 0xFFFF);
}

TEST(ipv4_checksum_known_vector)
{
    /* Classic textbook header; the correct checksum is 0xB861. */
    const uint8_t header[20] = {0x45, 0x00, 0x00, 0x73, 0x00, 0x00, 0x40, 0x00, 0x40, 0x11,
                                0x00, 0x00, 0xc0, 0xa8, 0x00, 0x01, 0xc0, 0xa8, 0x00, 0xc7};
    CHECK_EQ(ts_internet_checksum(header, sizeof(header)), 0xB861);
}

TEST(build_produces_valid_checksums)
{
    uint8_t pkt[2000];
    size_t len = make_packet("some payload with odd length!", pkt);
    CHECK(ts_packet_checksums_valid(pkt, len));

    /* Cross-check the TCP checksum with the independent implementation. */
    uint8_t buf[2000];
    size_t seg_len = len - 20;
    memcpy(buf, pkt + 12, 8);
    buf[8] = 0;
    buf[9] = 6;
    ts_put16(buf + 10, (uint16_t)seg_len);
    memcpy(buf + 12, pkt + 20, seg_len);
    buf[12 + 16] = buf[12 + 17] = 0;
    CHECK_EQ(ts_get16(pkt + 20 + 16), independent_checksum(buf, 12 + seg_len));
}

TEST(checksum_detects_corruption)
{
    uint8_t pkt[2000];
    size_t len = make_packet("payload", pkt);
    pkt[len - 1] ^= 1;
    CHECK(!ts_packet_checksums_valid(pkt, len));
}

TEST(parse_splits_headers_options_and_payload)
{
    static const uint8_t options[12] = {1, 1, 8, 10, 0, 0, 0, 1, 0, 0, 0, 2}; /* NOP NOP TS */
    pkt_spec s = default_spec();
    s.options = options;
    s.options_len = sizeof(options);
    uint8_t pkt[2000];
    ts_packet p;
    char err[TS_ERR_LEN];
    size_t len = make_packet_spec(&s, "abc", 3, pkt);
    CHECK(ts_packet_parse(pkt, len, &p, err) == 0);
    CHECK_EQ(p.ip_len, 20);
    CHECK_EQ(p.tcp_len, 32);
    CHECK_EQ(p.payload_len, 3);
    CHECK(memcmp(ts_packet_payload(&p), "abc", 3) == 0);
    CHECK(memcmp(pkt + 40, options, sizeof(options)) == 0);
}

TEST(parse_ignores_padding_after_total_length)
{
    uint8_t pkt[2000] = {0};
    size_t len = make_packet("", pkt);
    ts_packet p;
    char err[TS_ERR_LEN];
    CHECK(ts_packet_parse(pkt, len + 6, &p, err) == 0); /* Ethernet padding */
    CHECK_EQ(p.payload_len, 0);
}

static int parse_mutated(size_t offset, uint8_t value, size_t truncate_to, const char *expected)
{
    uint8_t pkt[2000];
    ts_packet p;
    char err[TS_ERR_LEN] = "";
    size_t len = make_packet("data", pkt);
    if (offset < len) {
        pkt[offset] = value;
    }
    if (truncate_to > 0) {
        len = truncate_to;
    }
    return ts_packet_parse(pkt, len, &p, err) == -1 && strstr(err, expected) != NULL;
}

TEST(parse_rejects_invalid_packets)
{
    CHECK(parse_mutated(9999, 0, 10, "shorter"));
    CHECK(parse_mutated(0, 0x65, 0, "not an IPv4"));
    CHECK(parse_mutated(0, 0x44, 0, "header length"));
    CHECK(parse_mutated(9, 17, 0, "not a TCP"));
    CHECK(parse_mutated(2, 0x07, 0, "total length")); /* 0x07xx > buffer */
    CHECK(parse_mutated(6, 0x20, 0, "fragments"));    /* More Fragments */
    CHECK(parse_mutated(7, 0x10, 0, "fragments"));    /* fragment offset */
    CHECK(parse_mutated(32, 0x40, 0, "TCP header length"));
}

TEST(build_preserves_all_other_header_fields)
{
    pkt_spec s = default_spec();
    s.ip_id = 4242;
    s.ttl = 33;
    s.seq = 99;
    s.ack = 77;
    uint8_t original[2000], rebuilt[2000];
    size_t len = make_packet_spec(&s, "xxxxxxxxxx", 10, original);
    size_t new_len = 0;
    CHECK(ts_packet_build(original, 20, 20, (const uint8_t *)"yyyyyyyyyyyyyyyyyyyyyyyyyy", 26, rebuilt,
                          sizeof(rebuilt), &new_len) == 0);
    CHECK_EQ(new_len, len + 16);
    for (int i = 0; i < 20; ++i) {
        if (i != 2 && i != 3 && i != 10 && i != 11) {
            CHECK_EQ(rebuilt[i], original[i]);
        }
    }
    CHECK(memcmp(rebuilt + 20, original + 20, 16) == 0);
    CHECK(memcmp(rebuilt + 38, original + 38, 2) == 0);
}

TEST(canonical_header_normalises_mutable_fields)
{
    uint8_t a[200], b[200], c[200], ca[TS_MAX_HEADERS], cb[TS_MAX_HEADERS], cc[TS_MAX_HEADERS];
    ts_packet pa, pb, pc;
    char err[TS_ERR_LEN];
    pkt_spec s = default_spec();
    size_t la = make_packet_spec(&s, "zzzzz", 5, a);
    s.ttl = 63; /* decremented by a router */
    size_t lb = make_packet_spec(&s, "zzzzz", 5, b);
    s.ttl = 64;
    s.seq = 1001;
    size_t lc = make_packet_spec(&s, "zzzzz", 5, c);
    CHECK(ts_packet_parse(a, la, &pa, err) == 0 && ts_packet_parse(b, lb, &pb, err) == 0 &&
          ts_packet_parse(c, lc, &pc, err) == 0);
    size_t n = ts_canonical_header(&pa, 5, ca);
    CHECK_EQ(n, 40);
    (void)ts_canonical_header(&pb, 5, cb);
    (void)ts_canonical_header(&pc, 5, cc);
    CHECK(memcmp(ca, cb, n) == 0);
    CHECK(memcmp(ca, cc, n) != 0);
    (void)ts_canonical_header(&pa, 6, cb); /* plaintext length is authenticated */
    CHECK(memcmp(ca, cb, n) != 0);
}

int main(void)
{
    RUN(ipv4_checksum_known_vector);
    RUN(build_produces_valid_checksums);
    RUN(checksum_detects_corruption);
    RUN(parse_splits_headers_options_and_payload);
    RUN(parse_ignores_padding_after_total_length);
    RUN(parse_rejects_invalid_packets);
    RUN(build_preserves_all_other_header_fields);
    RUN(canonical_header_normalises_mutable_fields);
    return test_summary("test_packet");
}
