/* Nonce management, replay protection and session lifetime (requirements 4, 9). */
#include "helpers.h"
#include "test.h"

#include "tcpseal/session.h"

TEST(nonce_set_add_contains_and_grow)
{
    ts_nonce_set set;
    uint8_t nonce[TS_NONCE_LEN] = {0};
    CHECK(ts_nonce_set_init(&set) == 0);
    for (uint32_t i = 0; i < 50000; ++i) { /* forces several resizes */
        ts_derive_nonce((const uint8_t *)"0123456789abcdef0123456789abcdef", (uint8_t *)&i, sizeof(i), nonce);
        CHECK(ts_nonce_set_add(&set, nonce) == 0);
    }
    CHECK_EQ(set.count, 50000);
    uint32_t again = 123;
    ts_derive_nonce((const uint8_t *)"0123456789abcdef0123456789abcdef", (uint8_t *)&again, sizeof(again),
                    nonce);
    CHECK(ts_nonce_set_contains(&set, nonce));
    CHECK(ts_nonce_set_add(&set, nonce) == 1);
    ts_nonce_set_free(&set);
}

TEST(distinct_headers_give_distinct_nonces)
{
    ts_session *s1, *s2;
    ts_nonce_set seen;
    uint8_t header[16] = "....header....", nonce[TS_NONCE_LEN];
    handshake_pair(&s1, &s2);
    CHECK(ts_nonce_set_init(&seen) == 0);
    /* The sender itself would reject duplicates; here we just check the KDF. */
    ts_direction_keys keys;
    memset(&keys, 7, sizeof(keys));
    int duplicates = 0;
    for (uint32_t i = 0; i < 10000; ++i) {
        ts_put32(header, i);
        ts_derive_nonce(keys.nonce_key, header, sizeof(header), nonce);
        duplicates += ts_nonce_set_add(&seen, nonce) != 0;
    }
    ts_nonce_set_free(&seen);
    ts_session_free(s1);
    ts_session_free(s2);
    CHECK_EQ(duplicates, 0);
}

TEST(sender_refuses_to_reuse_a_nonce)
{
    ts_session *s1, *s2;
    uint8_t out[64];
    handshake_pair(&s1, &s2);
    int first = ts_session_seal(s1, (const uint8_t *)"header-A", 8, (const uint8_t *)"first", 5, out);
    int second = ts_session_seal(s1, (const uint8_t *)"header-A", 8, (const uint8_t *)"other", 5, out);
    uint64_t count = ts_session_tx_count(s1);
    ts_session_free(s1);
    ts_session_free(s2);
    CHECK_EQ(first, TS_OK);
    CHECK_EQ(second, TS_ERR_NONCE_REUSE);
    CHECK_EQ(count, 1);
}

TEST(receiver_rejects_replay)
{
    ts_session *s1, *s2;
    uint8_t sealed[64], plain[64];
    handshake_pair(&s1, &s2);
    int r0 = ts_session_seal(s1, (const uint8_t *)"hdr", 3, (const uint8_t *)"data", 4, sealed);
    int r1 = ts_session_open(s2, (const uint8_t *)"hdr", 3, sealed, 4 + TS_TAG_LEN, plain);
    int match = memcmp(plain, "data", 4) == 0;
    int r2 = ts_session_open(s2, (const uint8_t *)"hdr", 3, sealed, 4 + TS_TAG_LEN, plain);
    ts_session_free(s1);
    ts_session_free(s2);
    CHECK(r0 == TS_OK && r1 == TS_OK && match);
    CHECK_EQ(r2, TS_ERR_REPLAY);
}

TEST(directions_use_independent_keys)
{
    ts_session *s1, *s2;
    uint8_t sealed[64], plain[64];
    handshake_pair(&s1, &s2);
    (void)ts_session_seal(s1, (const uint8_t *)"hdr", 3, (const uint8_t *)"data", 4, sealed);
    /* Device1 must not accept its own ciphertext (reflection). */
    int r = ts_session_open(s1, (const uint8_t *)"hdr", 3, sealed, 4 + TS_TAG_LEN, plain);
    ts_session_free(s1);
    ts_session_free(s2);
    CHECK_EQ(r, TS_ERR_AUTH);
}

TEST(soft_and_hard_limits)
{
    ts_session *s1, *s2;
    handshake_pair(&s1, &s2);
    ts_direction_keys tx, rx;
    memset(&tx, 1, sizeof(tx));
    memset(&rx, 2, sizeof(rx));
    ts_limits limits = {10, 20, 100};
    ts_session *s = ts_session_new("limited", &tx, &rx, &limits);
    double now = ts_now();
    ts_session_set_created(s, now);
    int a = !ts_session_needs_rekey(s, now + 5) && !ts_session_expired(s, now + 5);
    int b = ts_session_needs_rekey(s, now + 10) && !ts_session_expired(s, now + 10);
    int c = ts_session_expired(s, now + 20);
    uint8_t out[32];
    for (uint16_t i = 0; i < 80; ++i) {
        (void)ts_session_seal(s, (uint8_t *)&i, sizeof(i), NULL, 0, out);
    }
    int d = ts_session_needs_rekey(s, now) && !ts_session_expired(s, now);
    for (uint16_t i = 80; i < 100; ++i) {
        (void)ts_session_seal(s, (uint8_t *)&i, sizeof(i), NULL, 0, out);
    }
    int e = ts_session_seal(s, (const uint8_t *)"one more", 8, NULL, 0, out) == TS_ERR_EXPIRED;
    ts_session_free(s);
    ts_session_free(s1);
    ts_session_free(s2);
    CHECK(a && b && c && d && e);
}

TEST(manager_keeps_previous_for_receiving_only)
{
    ts_session *old1, *old2, *new1, *new2, *rx[3];
    ts_manager m;
    handshake_pair(&old1, &old2);
    handshake_pair(&new1, &new2);
    ts_session_free(old2);
    ts_session_free(new2);
    ts_manager_init(&m, 60);
    ts_manager_install(&m, old1);
    ts_manager_install(&m, new1);
    ts_manager_lock(&m);
    ts_session *tx = ts_manager_tx_locked(&m, ts_now());
    size_t n = ts_manager_rx_locked(&m, ts_now(), rx);
    ts_manager_unlock(&m);
    ts_manager_destroy(&m);
    CHECK(tx == new1);
    CHECK_EQ(n, 2);
    CHECK(rx[0] == new1 && rx[1] == old1);
}

TEST(manager_forgets_previous_after_grace)
{
    ts_session *old1, *old2, *new1, *new2, *rx[3];
    ts_manager m;
    handshake_pair(&old1, &old2);
    handshake_pair(&new1, &new2);
    ts_session_free(old2);
    ts_session_free(new2);
    ts_manager_init(&m, 0);
    ts_manager_install(&m, old1);
    ts_manager_install(&m, new1);
    ts_manager_lock(&m);
    size_t n = ts_manager_rx_locked(&m, ts_now(), rx);
    ts_manager_unlock(&m);
    ts_manager_destroy(&m);
    CHECK_EQ(n, 1);
}

TEST(manager_has_no_tx_session_when_expired_or_empty)
{
    ts_manager m;
    ts_session *s1, *s2, *rx[3];
    ts_manager_init(&m, 10);
    ts_manager_lock(&m);
    int empty = ts_manager_tx_locked(&m, ts_now()) == NULL;
    ts_manager_unlock(&m);
    handshake_pair(&s1, &s2);
    ts_session_free(s2);
    ts_session_set_created(s1, ts_now() - 1000); /* older than its lifetime */
    ts_manager_install(&m, s1);
    ts_manager_lock(&m);
    int expired = ts_manager_tx_locked(&m, ts_now()) == NULL;
    size_t n = ts_manager_rx_locked(&m, ts_now(), rx);
    ts_manager_unlock(&m);
    ts_manager_destroy(&m);
    CHECK(empty && expired);
    CHECK_EQ(n, 0);
}

TEST(pending_session_decrypts_but_does_not_encrypt)
{
    ts_session *cur1, *cur2, *pen1, *pen2, *rx[3];
    ts_manager m;
    handshake_pair(&cur1, &cur2);
    handshake_pair(&pen1, &pen2);
    ts_session_free(cur2);
    ts_session_free(pen2);
    ts_manager_init(&m, 10);
    ts_manager_install(&m, cur1);
    ts_manager_add_pending(&m, pen1);
    ts_manager_lock(&m);
    int tx_ok = ts_manager_tx_locked(&m, ts_now()) == cur1;
    size_t n = ts_manager_rx_locked(&m, ts_now(), rx);
    int has_pending = n == 2 && rx[0] == pen1;
    ts_manager_unlock(&m);
    ts_manager_discard_pending(&m);
    ts_manager_lock(&m);
    size_t after = ts_manager_rx_locked(&m, ts_now(), rx);
    ts_manager_unlock(&m);
    ts_manager_destroy(&m);
    CHECK(tx_ok && has_pending);
    CHECK_EQ(after, 1);
}

int main(void)
{
    RUN(nonce_set_add_contains_and_grow);
    RUN(distinct_headers_give_distinct_nonces);
    RUN(sender_refuses_to_reuse_a_nonce);
    RUN(receiver_rejects_replay);
    RUN(directions_use_independent_keys);
    RUN(soft_and_hard_limits);
    RUN(manager_keeps_previous_for_receiving_only);
    RUN(manager_forgets_previous_after_grace);
    RUN(manager_has_no_tx_session_when_expired_or_empty);
    RUN(pending_session_decrypts_but_does_not_encrypt);
    return test_summary("test_session");
}
