/* Packet protection end to end without a network (requirements 3, 5, 6, 7, 9). */
#include "helpers.h"
#include "test.h"

#include "tcpseal/protector.h"

#define MTU 1600
static uint8_t in[70000], prot[70000], out[70000];

TEST(roundtrip_restores_original_packet)
{
    ts_manager d1, d2;
    size_t plen = 0, olen = 0;
    manager_pair(&d1, &d2);
    size_t len = make_packet("GET / HTTP/1.1\r\n\r\n", in);
    int a = ts_protect(in, len, &d1, MTU, prot, &plen);
    int b = ts_unprotect(prot, plen, &d2, out, &olen);
    ts_manager_destroy(&d1);
    ts_manager_destroy(&d2);
    CHECK(a == TS_PASS && b == TS_PASS);
    CHECK_EQ(olen, len);
    CHECK(memcmp(out, in, len) == 0);
}

TEST(wire_format_is_headers_ciphertext_tag)
{
    ts_manager d1, d2;
    size_t plen = 0;
    const char *payload = "secret application data";
    manager_pair(&d1, &d2);
    size_t len = make_packet(payload, in);
    int r = ts_protect(in, len, &d1, MTU, prot, &plen);
    ts_manager_destroy(&d1);
    ts_manager_destroy(&d2);
    CHECK(r == TS_PASS);
    CHECK_EQ(plen, len + TS_TAG_LEN);
    CHECK_EQ(ts_get16(prot + 2), plen);                          /* IPv4 total length updated */
    CHECK(memcmp(prot + 12, in + 12, 8) == 0);                   /* addresses */
    CHECK(memcmp(prot + 20, in + 20, 16) == 0);                  /* ports, seq, ack, flags, window */
    CHECK(memmem(prot, plen, payload, strlen(payload)) == NULL); /* encrypted */
    CHECK(ts_packet_checksums_valid(prot, plen));
}

TEST(decrypted_packet_valid_after_ttl_change)
{
    ts_manager d1, d2;
    size_t plen = 0, olen = 0;
    manager_pair(&d1, &d2);
    size_t len = make_packet("abc", in);
    (void)ts_protect(in, len, &d1, MTU, prot, &plen);
    prot[8]--; /* a router decremented the TTL (checksum now stale) */
    int r = ts_unprotect(prot, plen, &d2, out, &olen);
    ts_manager_destroy(&d1);
    ts_manager_destroy(&d2);
    CHECK(r == TS_PASS);
    CHECK(ts_packet_checksums_valid(out, olen));
    CHECK(memcmp(out + olen - 3, "abc", 3) == 0);
}

TEST(empty_payload_control_packet_is_authenticated)
{
    ts_manager d1, d2;
    size_t plen = 0, olen = 0;
    pkt_spec s = default_spec();
    s.flags = 0x02; /* SYN */
    manager_pair(&d1, &d2);
    size_t len = make_packet_spec(&s, NULL, 0, in);
    int a = ts_protect(in, len, &d1, MTU, prot, &plen);
    int b = ts_unprotect(prot, plen, &d2, out, &olen);
    int restored = olen == len && memcmp(out, in, len) == 0;
    s.flags = 0x04; /* forged RST with a fake 16-byte "tag" */
    s.seq = 5;
    size_t forged = make_packet_spec(&s, "AAAAAAAAAAAAAAAA", 16, in);
    int c = ts_unprotect(in, forged, &d2, out, &olen);
    ts_manager_destroy(&d1);
    ts_manager_destroy(&d2);
    CHECK(a == TS_PASS && plen == len + TS_TAG_LEN);
    CHECK(b == TS_PASS && restored);
    CHECK_EQ(c, TS_DROP_AUTH);
}

TEST(any_modification_is_rejected)
{
    const size_t offsets[] = {40, 0 /* tag: last byte */, 22 /* port */, 26 /* seq */, 19 /* addr */};
    int rejected = 0;
    for (size_t i = 0; i < sizeof(offsets) / sizeof(offsets[0]); ++i) {
        ts_manager d1, d2;
        size_t plen = 0, olen = 0;
        manager_pair(&d1, &d2);
        size_t len = make_packet("important data", in);
        (void)ts_protect(in, len, &d1, MTU, prot, &plen);
        prot[offsets[i] == 0 ? plen - 1 : offsets[i]] ^= 1;
        ts_packet_finalize(prot, 20, plen); /* attacker fixes the checksums */
        rejected += ts_unprotect(prot, plen, &d2, out, &olen) == TS_DROP_AUTH;
        ts_manager_destroy(&d1);
        ts_manager_destroy(&d2);
    }
    CHECK_EQ(rejected, 5);
}

TEST(replayed_packet_is_rejected)
{
    ts_manager d1, d2;
    size_t plen = 0, olen = 0;
    manager_pair(&d1, &d2);
    size_t len = make_packet("pay 100 EUR", in);
    (void)ts_protect(in, len, &d1, MTU, prot, &plen);
    int first = ts_unprotect(prot, plen, &d2, out, &olen);
    int second = ts_unprotect(prot, plen, &d2, out, &olen);
    ts_manager_destroy(&d1);
    ts_manager_destroy(&d2);
    CHECK_EQ(first, TS_PASS);
    CHECK_EQ(second, TS_DROP_REPLAY);
}

TEST(reordering_and_loss_do_not_desynchronise)
{
    enum { N = 300 };
    static uint8_t packets[N][200];
    static size_t lens[N];
    ts_manager d1, d2;
    manager_pair(&d1, &d2);
    pkt_spec s = default_spec();
    for (int i = 0; i < N; ++i) {
        char payload[32];
        size_t len;
        (void)snprintf(payload, sizeof(payload), "segment %d", i);
        s.seq = 1000u + 100u * (uint32_t)i;
        s.ip_id = (uint16_t)i;
        len = make_packet_spec(&s, payload, strlen(payload), in);
        (void)ts_protect(in, len, &d1, MTU, packets[i], &lens[i]);
    }
    int failures = 0;
    /* Lose every third packet (far more than any counter window) and deliver
     * the rest in a scrambled order. */
    for (int k = 0; k < N; ++k) {
        int i = (k * 7) % N;
        size_t olen;
        if (i % 3 != 0) {
            failures += ts_unprotect(packets[i], lens[i], &d2, out, &olen) != TS_PASS;
        }
    }
    ts_manager_destroy(&d1);
    ts_manager_destroy(&d2);
    CHECK_EQ(failures, 0);
}

TEST(tcp_retransmission_gets_new_nonce)
{
    ts_manager d1, d2;
    size_t l1 = 0, l2 = 0, olen;
    static uint8_t first[200], retrans[200];
    pkt_spec s = default_spec();
    manager_pair(&d1, &d2);
    s.seq = 5000;
    s.ip_id = 10;
    size_t len = make_packet_spec(&s, "same bytes", 10, in);
    int a = ts_protect(in, len, &d1, MTU, first, &l1);
    s.ip_id = 11; /* Linux retransmits with a new IP ID (and timestamp) */
    len = make_packet_spec(&s, "same bytes", 10, in);
    int b = ts_protect(in, len, &d1, MTU, retrans, &l2);
    int different = memcmp(first + 40, retrans + 40, l1 - 40) != 0;
    int c = ts_unprotect(first, l1, &d2, out, &olen);
    int d = ts_unprotect(retrans, l2, &d2, out, &olen);
    ts_manager_destroy(&d1);
    ts_manager_destroy(&d2);
    CHECK(a == TS_PASS && b == TS_PASS && different);
    CHECK(c == TS_PASS && d == TS_PASS);
}

TEST(byte_identical_retransmission_is_dropped)
{
    ts_manager d1, d2;
    size_t plen;
    pkt_spec s = default_spec();
    s.seq = 1;
    s.ip_id = 0;
    manager_pair(&d1, &d2);
    size_t len = make_packet_spec(&s, "x", 1, in);
    int a = ts_protect(in, len, &d1, MTU, prot, &plen);
    int b = ts_protect(in, len, &d1, MTU, prot, &plen);
    ts_manager_destroy(&d1);
    ts_manager_destroy(&d2);
    CHECK_EQ(a, TS_PASS);
    CHECK_EQ(b, TS_DROP_NONCE_REUSE);
}

TEST(packet_too_large_for_peer_link)
{
    ts_manager d1, d2;
    size_t plen;
    static char big[1461];
    memset(big, 'x', 1460);
    manager_pair(&d1, &d2);
    size_t len = make_packet(big, in); /* 1500 bytes */
    int a = ts_protect(in, len, &d1, 1500, prot, &plen);
    int b = ts_protect(in, len, &d1, 1516, prot, &plen);
    ts_manager_destroy(&d1);
    ts_manager_destroy(&d2);
    CHECK_EQ(a, TS_DROP_TOO_BIG);
    CHECK_EQ(b, TS_PASS);
}

TEST(no_session_means_drop)
{
    ts_manager empty;
    size_t plen;
    ts_manager_init(&empty, 10);
    size_t len = make_packet("data that must not leave unprotected", in);
    int a = ts_protect(in, len, &empty, MTU, prot, &plen);
    int b = ts_unprotect(in, len, &empty, out, &plen);
    ts_manager_destroy(&empty);
    CHECK_EQ(a, TS_DROP_NO_SESSION);
    CHECK_EQ(b, TS_DROP_NO_SESSION);
}

TEST(short_or_malformed_packets_are_rejected)
{
    ts_manager d1, d2;
    size_t plen;
    manager_pair(&d1, &d2);
    size_t len = make_packet("short", in);
    int a = ts_unprotect(in, len, &d2, out, &plen);
    static const uint8_t garbage[] = {0x45, 0x00, 'g', 'a', 'r', 'b'};
    int b = ts_protect(garbage, sizeof(garbage), &d1, MTU, prot, &plen);
    int c = ts_unprotect(garbage, sizeof(garbage), &d2, out, &plen);
    ts_manager_destroy(&d1);
    ts_manager_destroy(&d2);
    CHECK_EQ(a, TS_DROP_NO_TAG);
    CHECK(b == TS_DROP_MALFORMED && c == TS_DROP_MALFORMED);
}

TEST(packets_in_flight_during_rekey_are_accepted)
{
    ts_session *old1, *old2, *new1, *new2;
    ts_manager d1, d2;
    size_t l1, l2, olen;
    static uint8_t flight[200], after[200];
    handshake_pair(&old1, &old2);
    handshake_pair(&new1, &new2);
    ts_manager_init(&d1, 10);
    ts_manager_init(&d2, 10);
    ts_manager_install(&d1, old1);
    ts_manager_install(&d2, old2);
    pkt_spec s = default_spec();
    s.seq = 1;
    size_t len = make_packet_spec(&s, "sent with old key", 17, in);
    (void)ts_protect(in, len, &d1, MTU, flight, &l1);
    ts_manager_install(&d1, new1);
    ts_manager_install(&d2, new2);
    s.seq = 2;
    len = make_packet_spec(&s, "sent with new key", 17, in);
    (void)ts_protect(in, len, &d1, MTU, after, &l2);
    int a =
        ts_unprotect(flight, l1, &d2, out, &olen) == TS_PASS && memcmp(out + 40, "sent with old", 13) == 0;
    int b = ts_unprotect(after, l2, &d2, out, &olen) == TS_PASS && memcmp(out + 40, "sent with new", 13) == 0;
    ts_manager_destroy(&d1);
    ts_manager_destroy(&d2);
    CHECK(a && b);
}

int main(void)
{
    RUN(roundtrip_restores_original_packet);
    RUN(wire_format_is_headers_ciphertext_tag);
    RUN(decrypted_packet_valid_after_ttl_change);
    RUN(empty_payload_control_packet_is_authenticated);
    RUN(any_modification_is_rejected);
    RUN(replayed_packet_is_rejected);
    RUN(reordering_and_loss_do_not_desynchronise);
    RUN(tcp_retransmission_gets_new_nonce);
    RUN(byte_identical_retransmission_is_dropped);
    RUN(packet_too_large_for_peer_link);
    RUN(no_session_means_drop);
    RUN(short_or_malformed_packets_are_rejected);
    RUN(packets_in_flight_during_rekey_are_accepted);
    return test_summary("test_protector");
}
