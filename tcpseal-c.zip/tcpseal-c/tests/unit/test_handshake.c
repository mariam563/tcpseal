/* Authenticated DH handshake and key derivation (test requirements 1, 2, 10). */
#include "helpers.h"
#include "test.h"

#include "tcpseal/handshake.h"

#include <openssl/core_names.h>
#include <openssl/kdf.h>

typedef struct {
    EVP_PKEY *d1, *d2;
} ids;

static ids new_ids(void)
{
    ids i = {EVP_PKEY_Q_keygen(NULL, NULL, "ED25519"), EVP_PKEY_Q_keygen(NULL, NULL, "ED25519")};
    return i;
}

static void free_ids(ids i)
{
    EVP_PKEY_free(i.d1);
    EVP_PKEY_free(i.d2);
}

/* Run a handshake. tamper_msg (1..4) gets its byte at tamper_offset flipped
 * (offset counted from the end if negative). Returns 0 on success. */
static int run(EVP_PKEY *d1, EVP_PKEY *d1_pin, EVP_PKEY *d2, EVP_PKEY *d2_pin, int tamper_msg,
               int tamper_offset, ts_session_keys *k1, ts_session_keys *k2, char *err)
{
    ts_handshake a, b;
    uint8_t m1[TS_HS_HELLO_LEN], m2[TS_HS_REPLY_LEN], m3[TS_HS_FINISH_LEN], m4[TS_HS_CONFIRM_LEN];
    uint8_t *msgs[5] = {NULL, m1, m2, m3, m4};
    size_t sizes[5] = {0, sizeof(m1), sizeof(m2), sizeof(m3), sizeof(m4)};
    int r = -1;
#define TAMPER(n)                                                                                            \
    if (tamper_msg == (n)) {                                                                                 \
        size_t at = tamper_offset < 0 ? sizes[n] + (size_t)tamper_offset : (size_t)tamper_offset;            \
        msgs[n][at] ^= 1;                                                                                    \
    }
    (void)ts_handshake_init(&a, d1, d2_pin, err);
    (void)ts_handshake_init(&b, d2, d1_pin, err);
    (void)ts_initiator_hello(&a, m1);
    TAMPER(1)
    if (ts_responder_reply(&b, m1, sizeof(m1), m2, err) == 0) {
        TAMPER(2)
        if (ts_initiator_finish(&a, m2, sizeof(m2), m3, k1, err) == 0) {
            TAMPER(3)
            if (ts_responder_confirm(&b, m3, sizeof(m3), m4, k2, err) == 0) {
                TAMPER(4)
                r = ts_initiator_confirm(&a, m4, sizeof(m4), err);
            }
        }
    }
    ts_handshake_clear(&a);
    ts_handshake_clear(&b);
    return r;
}

TEST(successful_exchange_gives_matching_directional_keys)
{
    ids i = new_ids();
    ts_session_keys k1, k2;
    char err[TS_ERR_LEN];
    int r = run(i.d1, i.d1, i.d2, i.d2, 0, 0, &k1, &k2, err);
    free_ids(i);
    CHECK(r == 0);
    CHECK(strcmp(k1.session_id, k2.session_id) == 0);
    CHECK_EQ(strlen(k1.session_id), 16);
    CHECK(memcmp(&k1.tx, &k2.rx, sizeof(k1.tx)) == 0); /* Device1 -> Device2 */
    CHECK(memcmp(&k1.rx, &k2.tx, sizeof(k1.rx)) == 0); /* Device2 -> Device1 */
    CHECK(memcmp(k1.tx.aes_key, k1.rx.aes_key, TS_KEY_LEN) != 0);
    CHECK(memcmp(k1.tx.nonce_key, k1.rx.nonce_key, TS_KEY_LEN) != 0);
}

TEST(every_handshake_creates_fresh_keys)
{
    ids i = new_ids();
    ts_session_keys a1, a2, b1, b2;
    char err[TS_ERR_LEN];
    int r =
        run(i.d1, i.d1, i.d2, i.d2, 0, 0, &a1, &a2, err) | run(i.d1, i.d1, i.d2, i.d2, 0, 0, &b1, &b2, err);
    free_ids(i);
    CHECK(r == 0);
    CHECK(memcmp(a1.tx.aes_key, b1.tx.aes_key, TS_KEY_LEN) != 0);
    CHECK(strcmp(a1.session_id, b1.session_id) != 0);
}

TEST(key_schedule_matches_independent_hkdf)
{
    uint8_t shared[32], r1[32], r2[32], th[32], okm[TS_HS_OKM_LEN], expected[TS_HS_OKM_LEN];
    memset(shared, 0x11, 32);
    memset(r1, 0x22, 32);
    memset(r2, 0x33, 32);
    memset(th, 0x44, 32);
    CHECK(ts_derive_keys(shared, 32, r1, r2, th, okm) == 0);

    /* Recompute with a separately written HKDF call. */
    uint8_t salt[64], info[23 + 32];
    memcpy(salt, r1, 32);
    memcpy(salt + 32, r2, 32);
    memcpy(info, "tcpseal-v1 session keys", 23);
    memcpy(info + 23, th, 32);
    EVP_KDF *kdf = EVP_KDF_fetch(NULL, "HKDF", NULL);
    EVP_KDF_CTX *ctx = EVP_KDF_CTX_new(kdf);
    OSSL_PARAM p[] = {OSSL_PARAM_construct_utf8_string(OSSL_KDF_PARAM_DIGEST, (char *)"SHA256", 0),
                      OSSL_PARAM_construct_octet_string(OSSL_KDF_PARAM_KEY, shared, 32),
                      OSSL_PARAM_construct_octet_string(OSSL_KDF_PARAM_SALT, salt, 64),
                      OSSL_PARAM_construct_octet_string(OSSL_KDF_PARAM_INFO, info, sizeof(info)),
                      OSSL_PARAM_construct_end()};
    int ok = EVP_KDF_derive(ctx, expected, sizeof(expected), p) == 1;
    EVP_KDF_CTX_free(ctx);
    EVP_KDF_free(kdf);
    CHECK(ok);
    CHECK(memcmp(okm, expected, sizeof(okm)) == 0);
    for (int a = 0; a < 5; ++a) {
        for (int b = a + 1; b < 5; ++b) {
            CHECK(memcmp(okm + a * 32, okm + b * 32, 32) != 0);
        }
    }
}

TEST(hkdf_rfc5869_test_case_1)
{
    /* RFC 5869 appendix A.1 */
    uint8_t ikm[22], salt[13], info[10], okm[42];
    memset(ikm, 0x0b, sizeof(ikm));
    for (int i = 0; i < 13; ++i) {
        salt[i] = (uint8_t)i;
    }
    for (int i = 0; i < 10; ++i) {
        info[i] = (uint8_t)(0xf0 + i);
    }
    static const uint8_t expected[42] = {0x3c, 0xb2, 0x5f, 0x25, 0xfa, 0xac, 0xd5, 0x7a, 0x90, 0x43, 0x4f,
                                         0x64, 0xd0, 0x36, 0x2f, 0x2a, 0x2d, 0x2d, 0x0a, 0x90, 0xcf, 0x1a,
                                         0x5a, 0x4c, 0x5d, 0xb0, 0x2d, 0x56, 0xec, 0xc4, 0xc5, 0xbf, 0x34,
                                         0x00, 0x72, 0x08, 0xd5, 0xb8, 0x87, 0x18, 0x58, 0x65};
    EVP_KDF *kdf = EVP_KDF_fetch(NULL, "HKDF", NULL);
    EVP_KDF_CTX *ctx = EVP_KDF_CTX_new(kdf);
    OSSL_PARAM p[] = {OSSL_PARAM_construct_utf8_string(OSSL_KDF_PARAM_DIGEST, (char *)"SHA256", 0),
                      OSSL_PARAM_construct_octet_string(OSSL_KDF_PARAM_KEY, ikm, sizeof(ikm)),
                      OSSL_PARAM_construct_octet_string(OSSL_KDF_PARAM_SALT, salt, sizeof(salt)),
                      OSSL_PARAM_construct_octet_string(OSSL_KDF_PARAM_INFO, info, sizeof(info)),
                      OSSL_PARAM_construct_end()};
    int ok = EVP_KDF_derive(ctx, okm, sizeof(okm), p) == 1;
    EVP_KDF_CTX_free(ctx);
    EVP_KDF_free(kdf);
    CHECK(ok);
    CHECK(memcmp(okm, expected, sizeof(okm)) == 0);
}

TEST(wrong_pinned_key_is_rejected)
{
    ids i = new_ids();
    EVP_PKEY *impostor = EVP_PKEY_Q_keygen(NULL, NULL, "ED25519");
    ts_session_keys k1, k2;
    char err[TS_ERR_LEN] = "";
    /* Device1 pins Device2's key but talks to the impostor. */
    int r1 = run(i.d1, i.d1, impostor, i.d2, 0, 0, &k1, &k2, err);
    int sig1 = strstr(err, "signature") != NULL;
    /* Device2 pins Device1's key but talks to the impostor. */
    int r2 = run(impostor, i.d1, i.d2, i.d2, 0, 0, &k1, &k2, err);
    int sig2 = strstr(err, "signature") != NULL;
    EVP_PKEY_free(impostor);
    free_ids(i);
    CHECK(r1 != 0 && sig1);
    CHECK(r2 != 0 && sig2);
}

TEST(man_in_the_middle_replacing_dh_key_is_detected)
{
    ids i = new_ids();
    ts_session_keys k1, k2;
    char err[TS_ERR_LEN];
    /* Flip a byte of Device2's ephemeral public key inside M2. */
    int r = run(i.d1, i.d1, i.d2, i.d2, 2, TS_HS_HEADER_LEN + TS_HS_RANDOM_LEN + 5, &k1, &k2, err);
    free_ids(i);
    CHECK(r != 0);
}

TEST(any_modified_message_fails)
{
    ids i = new_ids();
    ts_session_keys k1, k2;
    char err[TS_ERR_LEN];
    int failures = 0;
    for (int msg = 1; msg <= 4; ++msg) {
        failures += run(i.d1, i.d1, i.d2, i.d2, msg, -1, &k1, &k2, err) != 0;
        failures += run(i.d1, i.d1, i.d2, i.d2, msg, 0, &k1, &k2, err) != 0; /* magic */
    }
    free_ids(i);
    CHECK_EQ(failures, 8);
}

TEST(malformed_and_low_order_hello_rejected)
{
    ids i = new_ids();
    ts_handshake b;
    uint8_t m2[TS_HS_REPLY_LEN];
    uint8_t hello[TS_HS_HELLO_LEN] = {'T', 'S', 'L', '1', 1}; /* all-zero X25519 point */
    char err[TS_ERR_LEN] = "";
    (void)ts_handshake_init(&b, i.d2, i.d1, err);
    int low_order =
        ts_responder_reply(&b, hello, sizeof(hello), m2, err) != 0 && strstr(err, "Diffie-Hellman") != NULL;
    int short_msg = ts_responder_reply(&b, hello, 10, m2, err) != 0;
    hello[4] = 2;
    int wrong_type = ts_responder_reply(&b, hello, sizeof(hello), m2, err) != 0;
    hello[0] = 'X';
    int bad_magic = ts_responder_reply(&b, hello, sizeof(hello), m2, err) != 0;
    ts_handshake_clear(&b);
    free_ids(i);
    CHECK(low_order);
    CHECK(short_msg && wrong_type && bad_magic);
}

int main(void)
{
    RUN(successful_exchange_gives_matching_directional_keys);
    RUN(every_handshake_creates_fresh_keys);
    RUN(key_schedule_matches_independent_hkdf);
    RUN(hkdf_rfc5869_test_case_1);
    RUN(wrong_pinned_key_is_rejected);
    RUN(man_in_the_middle_replacing_dh_key_is_detected);
    RUN(any_modified_message_fails);
    RUN(malformed_and_low_order_hello_rejected);
    return test_summary("test_handshake");
}
