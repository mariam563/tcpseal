/* Configuration validation and safe secret handling (requirements 11, 12). */
#include "helpers.h"
#include "test.h"

#include "tcpseal/config.h"
#include "tcpseal/keys.h"

#include <openssl/pem.h>

#include <stdio.h>
#include <sys/stat.h>

static char g_dir[512];

static const char VALID[] = "[device]\n"
                            "role = device1\n"
                            "identity_key = keys/device1.key\n"
                            "peer_public_key = keys/device2.pub\n"
                            "[control]\n"
                            "address = 10.0.12.2\n";

static const char *write_config(const char *text)
{
    static char path[600];
    (void)snprintf(path, sizeof(path), "%s/device.ini", g_dir);
    FILE *f = fopen(path, "w");
    if (f != NULL) {
        (void)fputs(text, f);
        (void)fclose(f);
    }
    return path;
}

/* Replace the first occurrence of `from` in VALID with `to`. */
static const char *variant(const char *from, const char *to)
{
    static char text[2048];
    const char *at = strstr(VALID, from);
    (void)snprintf(text, sizeof(text), "%.*s%s%s", (int)(at - VALID), VALID, to, at + strlen(from));
    return text;
}

static int fails_with(const char *text, const char *expected)
{
    ts_config cfg;
    char err[TS_ERR_LEN] = "";
    int failed = ts_config_load(write_config(text), &cfg, err) != 0;
    if (!failed || strstr(err, expected) == NULL) {
        (void)fprintf(stderr, "    expected error containing '%s', got '%s'\n", expected, err);
        return 0;
    }
    return 1;
}

TEST(valid_minimal_config_uses_defaults)
{
    static ts_config cfg;
    char err[TS_ERR_LEN] = "";
    CHECK(ts_config_load(write_config(VALID), &cfg, err) == 0);
    CHECK(strcmp(cfg.role, "device1") == 0 && cfg.is_initiator);
    CHECK_EQ(cfg.control_port, 47100);
    CHECK_EQ(cfg.encrypt_queue, 100);
    CHECK_EQ(cfg.decrypt_queue, 101);
    CHECK_EQ(cfg.peer_mtu, 1500);
    CHECK(strstr(cfg.identity_key, "/keys/device1.key") != NULL && cfg.identity_key[0] == '/');
}

TEST(shipped_examples_are_valid)
{
    static ts_config cfg;
    char err[TS_ERR_LEN] = "";
    CHECK(ts_config_load("examples/device1.example.ini", &cfg, err) == 0);
    CHECK(cfg.is_initiator && cfg.peer_mtu == 1600);
    CHECK(ts_config_load("examples/device2.example.ini", &cfg, err) == 0);
    CHECK(!cfg.is_initiator);
}

TEST(invalid_configs_fail_clearly)
{
    CHECK(fails_with(variant("role = device1", "role = router"), "role"));
    CHECK(fails_with(variant("address = 10.0.12.2", "address = not-an-ip"), "IPv4"));
    CHECK(fails_with(variant("address = 10.0.12.2", "address = 0.0.0.0"), "real address"));
    CHECK(fails_with(variant("[control]", "[control]\nport = 70000"), "outside"));
    CHECK(fails_with(variant("[control]", "[control]\nport = abc"), "not an integer"));
    CHECK(fails_with(variant("[control]", "[control]\ncolour = blue"), "unknown key"));
    CHECK(fails_with(variant("[device]", "[extra]\n[device]"), "unknown section"));
    CHECK(fails_with(variant("identity_key = keys/device1.key", ""), "missing required"));
    CHECK(fails_with(variant("[control]", "[dataplane]\nencrypt_queue = 5\ndecrypt_queue = 5\n[control]"),
                     "must differ"));
    CHECK(fails_with(variant("[control]", "[session]\nrekey_interval = 300\nlifetime = 300\n[control]"),
                     "smaller than"));
    CHECK(fails_with(variant("[control]", "[logging]\nlevel = loud\n[control]"), "level"));
    CHECK(fails_with(variant("role = device1", "role = device1\nrole = device2"), "duplicate"));
}

TEST(missing_config_file)
{
    ts_config cfg;
    char err[TS_ERR_LEN] = "";
    CHECK(ts_config_load("/nonexistent/tcpseal.ini", &cfg, err) != 0);
    CHECK(strstr(err, "not found") != NULL);
}

TEST(keygen_creates_private_key_with_mode_0600)
{
    char priv[600], pub[600], keys_dir[560], err[TS_ERR_LEN];
    struct stat st;
    (void)snprintf(keys_dir, sizeof(keys_dir), "%s/k", g_dir);
    CHECK(ts_keygen(keys_dir, "device1", 0, priv, pub, sizeof(priv), err) == 0);
    CHECK(stat(priv, &st) == 0 && (st.st_mode & 0777) == 0600);
    EVP_PKEY *a = ts_load_private(priv, err);
    EVP_PKEY *b = ts_load_public(pub, err);
    char fa[17], fb[17];
    ts_fingerprint(a, fa);
    ts_fingerprint(b, fb);
    EVP_PKEY_free(a);
    EVP_PKEY_free(b);
    CHECK(strcmp(fa, fb) == 0 && strlen(fa) == 16);
    CHECK(ts_keygen(keys_dir, "device1", 0, priv, pub, sizeof(priv), err) != 0);
    CHECK(strstr(err, "already exists") != NULL);
    CHECK(ts_keygen(keys_dir, "../evil", 0, priv, pub, sizeof(priv), err) != 0);
}

TEST(world_readable_private_key_is_refused)
{
    char priv[600], pub[600], keys_dir[560], err[TS_ERR_LEN] = "";
    (void)snprintf(keys_dir, sizeof(keys_dir), "%s/k2", g_dir);
    CHECK(ts_keygen(keys_dir, "device1", 0, priv, pub, sizeof(priv), err) == 0);
    CHECK(chmod(priv, 0644) == 0);
    CHECK(ts_load_private(priv, err) == NULL);
    CHECK(strstr(err, "unsafe permissions") != NULL);
}

TEST(missing_and_wrong_type_keys)
{
    char err[TS_ERR_LEN] = "", path[600];
    CHECK(ts_load_private("/nonexistent/x.key", err) == NULL && strstr(err, "not found") != NULL);
    CHECK(ts_load_public("/nonexistent/x.pub", err) == NULL && strstr(err, "not found") != NULL);
    (void)snprintf(path, sizeof(path), "%s/garbage.pub", g_dir);
    FILE *f = fopen(path, "w");
    CHECK(f != NULL);
    (void)fputs("not a key\n", f);
    (void)fclose(f);
    CHECK(ts_load_public(path, err) == NULL && strstr(err, "cannot parse") != NULL);
    /* An X25519 key is a valid PEM key but not an Ed25519 identity key. */
    EVP_PKEY *x = EVP_PKEY_Q_keygen(NULL, NULL, "X25519");
    f = fopen(path, "w");
    (void)PEM_write_PUBKEY(f, x);
    (void)fclose(f);
    EVP_PKEY_free(x);
    CHECK(ts_load_public(path, err) == NULL && strstr(err, "not an Ed25519") != NULL);
}

int main(void)
{
    make_temp_dir(g_dir, sizeof(g_dir));
    if (g_dir[0] == '\0') {
        return 1;
    }
    RUN(valid_minimal_config_uses_defaults);
    RUN(shipped_examples_are_valid);
    RUN(invalid_configs_fail_clearly);
    RUN(missing_config_file);
    RUN(keygen_creates_private_key_with_mode_0600);
    RUN(world_readable_private_key_is_refused);
    RUN(missing_and_wrong_type_keys);
    rm_rf(g_dir);
    return test_summary("test_config_keys");
}
