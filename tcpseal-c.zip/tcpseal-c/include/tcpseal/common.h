/*
 * common.h - constants, logging and small helpers shared by all modules.
 */
#ifndef TCPSEAL_COMMON_H
#define TCPSEAL_COMMON_H

#include <stddef.h>
#include <stdint.h>

#define TS_VERSION "0.1.0"

#define TS_KEY_LEN 32   /* AES-256 key, HMAC nonce key */
#define TS_NONCE_LEN 12 /* AES-GCM nonce (96 bits) */
#define TS_TAG_LEN 16   /* AES-GCM authentication tag */
#define TS_ERR_LEN 256  /* size of every error-message buffer */

enum ts_log_level { TS_LOG_DEBUG = 0, TS_LOG_INFO, TS_LOG_WARNING, TS_LOG_ERROR };

/* Logging to stderr: "<time> <role> <LEVEL> <component>: message". */
void ts_log_setup(int level, const char *role);
void ts_log(int level, const char *component, const char *fmt, ...) __attribute__((format(printf, 3, 4)));
int ts_log_level_from_name(const char *name); /* -1 if unknown */

/* Write a formatted message into an error buffer of TS_ERR_LEN bytes. */
void ts_set_error(char *err, const char *fmt, ...) __attribute__((format(printf, 2, 3)));

/* Monotonic clock in seconds (never jumps when the wall clock changes). */
double ts_now(void);

/* Erase secrets; the compiler is not allowed to optimise this away. */
void ts_secure_zero(void *data, size_t len);

/* Big-endian helpers. */
static inline uint16_t ts_get16(const uint8_t *p) { return (uint16_t)((p[0] << 8) | p[1]); }
static inline uint32_t ts_get32(const uint8_t *p)
{
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 8) | p[3];
}
static inline void ts_put16(uint8_t *p, uint16_t v)
{
    p[0] = (uint8_t)(v >> 8);
    p[1] = (uint8_t)v;
}
static inline void ts_put32(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)(v >> 24);
    p[1] = (uint8_t)(v >> 16);
    p[2] = (uint8_t)(v >> 8);
    p[3] = (uint8_t)v;
}

#endif
