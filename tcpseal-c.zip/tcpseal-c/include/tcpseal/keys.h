/*
 * keys.h - generation and safe loading of Ed25519 identity keys (PEM).
 *
 * Private keys are created locally with mode 0600 and never committed
 * (local/ is git-ignored). Only the public key is copied to the peer.
 * The file format (PKCS#8 / SubjectPublicKeyInfo PEM) is the same as in the
 * Python version, so keys can be shared between both implementations.
 */
#ifndef TCPSEAL_KEYS_H
#define TCPSEAL_KEYS_H

#include <openssl/evp.h>

#include <stddef.h>

/* Creates <dir>/<name>.key and <dir>/<name>.pub. Returns 0 on success. */
int ts_keygen(const char *dir, const char *name, int overwrite, char *private_path, char *public_path,
              size_t path_size, char *err);

/* Refuses missing files, non-Ed25519 keys and group/other-readable private keys. */
EVP_PKEY *ts_load_private(const char *path, char *err);
EVP_PKEY *ts_load_public(const char *path, char *err);

/* First 16 hex digits of SHA-256(raw public key), for comparing devices. */
void ts_fingerprint(const EVP_PKEY *key, char out[17]);

#endif
