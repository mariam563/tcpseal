/*
 * packet.h - IPv4/TCP parsing, checksums, rebuilding and canonical header.
 *
 * Only complete, unfragmented IPv4 packets carrying TCP are accepted.
 * Parsing never copies: a ts_packet points into the caller's buffer.
 */
#ifndef TCPSEAL_PACKET_H
#define TCPSEAL_PACKET_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define TS_MAX_IPV4_PACKET 65535u
/* IPv4 header (max 60) + TCP header (max 60). */
#define TS_MAX_HEADERS 120u

typedef struct {
    const uint8_t *data; /* start of the IPv4 header */
    size_t ip_len;       /* IPv4 header length (IHL * 4) */
    size_t tcp_len;      /* TCP header length incl. options (data offset * 4) */
    size_t payload_len;  /* TCP payload bytes (up to IPv4 total length) */
} ts_packet;

static inline size_t ts_packet_headers_len(const ts_packet *p) { return p->ip_len + p->tcp_len; }
static inline const uint8_t *ts_packet_payload(const ts_packet *p)
{
    return p->data + p->ip_len + p->tcp_len;
}

/* Returns 0 on success, -1 with a message in err (TS_ERR_LEN bytes). */
int ts_packet_parse(const uint8_t *data, size_t len, ts_packet *out, char *err);

/* RFC 1071 one's-complement checksum, returned in host byte order. */
uint16_t ts_internet_checksum(const uint8_t *data, size_t len);

/* TCP checksum over the IPv4 pseudo-header and the TCP segment. */
uint16_t ts_tcp_checksum(const uint8_t *ip_header, const uint8_t *segment, size_t segment_len);

/*
 * The packet at pkt (IPv4 header of ip_len bytes, then TCP) has a new
 * total length total_len: write it into the header and recompute the IPv4
 * header checksum and the TCP checksum. All other fields stay unchanged.
 */
void ts_packet_finalize(uint8_t *pkt, size_t ip_len, size_t total_len);

/* Convenience for tests: copy headers + payload into out and finalize. */
int ts_packet_build(const uint8_t *headers, size_t ip_len, size_t tcp_len, const uint8_t *payload,
                    size_t payload_len, uint8_t *out, size_t out_cap, size_t *out_len);

bool ts_packet_checksums_valid(const uint8_t *data, size_t len);

/*
 * Canonical header used as AES-GCM associated data and as nonce-derivation
 * input. Mutable fields are normalised (like IPsec AH, RFC 4302):
 *   total length -> plaintext packet length, TTL -> 0, IPv4 and TCP
 *   checksums -> 0, ECN bits -> 0.
 * Writes headers_len bytes into out (at least TS_MAX_HEADERS) and returns it.
 */
size_t ts_canonical_header(const ts_packet *p, size_t plaintext_len, uint8_t *out);

#endif
