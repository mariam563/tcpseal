/*
 * control.h - control channel: runs handshakes between the devices over TCP.
 *
 * The channel is local traffic of the devices (netfilter INPUT/OUTPUT), so
 * it never matches the rules that queue protected PC1<->PC2 traffic.
 *
 * Device1 connects, performs a handshake, and repeats it on the same
 * connection whenever the session needs a rekey. If the connection breaks
 * (e.g. Device2 restarted and lost its keys) it reconnects with exponential
 * back-off. Device2 accepts one connection at a time; a new connection
 * replaces the old one (e.g. after Device1 restarted).
 *
 * Framing: every message is preceded by a 2-byte big-endian length.
 */
#ifndef TCPSEAL_CONTROL_H
#define TCPSEAL_CONTROL_H

#include "tcpseal/session.h"

#include <openssl/evp.h>

#include <stdatomic.h>
#include <stdint.h>

#define TS_MAX_BACKOFF_SECONDS 30.0

typedef struct {
    char address[16]; /* Device1: Device2's address. Device2: listen address. */
    uint16_t port;    /* Device2 with port 0: an ephemeral port is chosen (tests) */
    EVP_PKEY *identity;
    EVP_PKEY *peer_identity;
    ts_manager *sessions;
    ts_limits limits;
    double timeout;   /* seconds per handshake message */
    atomic_int *stop; /* set to 1 to make run() return */
    atomic_int handshakes_completed;
    atomic_int handshakes_failed;
    int listen_fd; /* Device2 only */
} ts_channel;

void ts_channel_init(ts_channel *c, const char *address, uint16_t port, EVP_PKEY *identity,
                     EVP_PKEY *peer_identity, ts_manager *sessions, const ts_limits *limits, double timeout,
                     atomic_int *stop);

/* Device2: bind and listen (fills c->port if it was 0). Returns 0 or -1. */
int ts_responder_listen(ts_channel *c, char *err);

/* Thread entry points; arg is a ts_channel*. */
void *ts_initiator_run(void *arg);
void *ts_responder_run(void *arg);

#endif
