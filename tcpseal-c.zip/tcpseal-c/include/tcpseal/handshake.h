/*
 * handshake.h - authenticated ephemeral Diffie-Hellman (X25519 + Ed25519).
 *
 * Pure message processing, no sockets (control.c moves the bytes).
 * Wire-compatible with the Python version of tcpseal.
 *
 *   M1 D1->D2  "TSL1" | 0x01 | random_1(32) | x25519_pub_1(32)               69 bytes
 *   M2 D2->D1  "TSL1" | 0x02 | random_2(32) | x25519_pub_2(32) | sig_2(64)   133 bytes
 *   M3 D1->D2  "TSL1" | 0x03 | sig_1(64) | finished_1(32)                    101 bytes
 *   M4 D2->D1  "TSL1" | 0x04 | finished_2(32)                                37 bytes
 *
 *   th         = SHA-256(M1 || M2 without sig_2)
 *   sig_N      = Ed25519_sign(identity_N, "tcpseal-v1 deviceN sig" || th)
 *   okm        = HKDF-SHA256(ikm = X25519 secret, salt = random_1 || random_2,
 *                            info = "tcpseal-v1 session keys" || th, L = 160)
 *              = aes_12 | aes_21 | nonce_12 | nonce_21 | confirm   (5 x 32 bytes)
 *   finished_N = HMAC-SHA256(confirm, "tcpseal-v1 deviceN finished" || th)
 *   session id = hex(th[0..7])
 */
#ifndef TCPSEAL_HANDSHAKE_H
#define TCPSEAL_HANDSHAKE_H

#include "tcpseal/session.h"

#include <openssl/evp.h>

#include <stddef.h>
#include <stdint.h>

#define TS_HS_RANDOM_LEN 32
#define TS_HS_PUB_LEN 32
#define TS_HS_SIG_LEN 64
#define TS_HS_MAC_LEN 32
#define TS_HS_HEADER_LEN 5 /* magic + type */
#define TS_HS_HELLO_LEN (TS_HS_HEADER_LEN + TS_HS_RANDOM_LEN + TS_HS_PUB_LEN)
#define TS_HS_REPLY_LEN (TS_HS_HELLO_LEN + TS_HS_SIG_LEN)
#define TS_HS_FINISH_LEN (TS_HS_HEADER_LEN + TS_HS_SIG_LEN + TS_HS_MAC_LEN)
#define TS_HS_CONFIRM_LEN (TS_HS_HEADER_LEN + TS_HS_MAC_LEN)
#define TS_HS_MAX_LEN TS_HS_REPLY_LEN
#define TS_HS_OKM_LEN (5 * TS_KEY_LEN)

typedef struct {
    char session_id[17];
    ts_direction_keys tx;
    ts_direction_keys rx;
} ts_session_keys;

/* Shared state of one handshake (either role). Use each instance once. */
typedef struct {
    EVP_PKEY *identity;      /* own Ed25519 key (not owned) */
    EVP_PKEY *peer_identity; /* pinned peer Ed25519 public key (not owned) */
    EVP_PKEY *ephemeral;     /* fresh X25519 key (owned) */
    uint8_t random[TS_HS_RANDOM_LEN];
    uint8_t hello[TS_HS_HELLO_LEN];
    uint8_t th[32];
    uint8_t okm[TS_HS_OKM_LEN];
    int stage;
} ts_handshake;

int ts_handshake_init(ts_handshake *hs, EVP_PKEY *identity, EVP_PKEY *peer_identity, char *err);
void ts_handshake_clear(ts_handshake *hs);

/* Device1 */
int ts_initiator_hello(ts_handshake *hs, uint8_t out[TS_HS_HELLO_LEN]);
int ts_initiator_finish(ts_handshake *hs, const uint8_t *reply, size_t reply_len,
                        uint8_t out[TS_HS_FINISH_LEN], ts_session_keys *keys, char *err);
int ts_initiator_confirm(ts_handshake *hs, const uint8_t *msg, size_t msg_len, char *err);

/* Device2 */
int ts_responder_reply(ts_handshake *hs, const uint8_t *hello, size_t hello_len, uint8_t out[TS_HS_REPLY_LEN],
                       char *err);
int ts_responder_confirm(ts_handshake *hs, const uint8_t *finish, size_t finish_len,
                         uint8_t out[TS_HS_CONFIRM_LEN], ts_session_keys *keys, char *err);

/* HKDF key schedule (exposed for tests). Returns 0 on success. */
int ts_derive_keys(const uint8_t *shared, size_t shared_len, const uint8_t random_1[32],
                   const uint8_t random_2[32], const uint8_t th[32], uint8_t okm[TS_HS_OKM_LEN]);

#endif
