/*
 * daemon.h - the gateway daemon: configuration + control thread + NFQUEUE loop.
 */
#ifndef TCPSEAL_DAEMON_H
#define TCPSEAL_DAEMON_H

#include "tcpseal/config.h"
#include "tcpseal/nfqueue.h"
#include "tcpseal/protector.h"
#include "tcpseal/session.h"

#include <stdint.h>

/* Statistics: encrypted/decrypted counters and drops per reason. */
typedef struct {
    uint64_t encrypted;
    uint64_t decrypted;
    uint64_t encrypt_drops[TS_DROP_COUNT];
    uint64_t decrypt_drops[TS_DROP_COUNT];
    uint64_t encrypt_no_payload, decrypt_no_payload;
    uint64_t kernel_queue_overflow;
} ts_stats;

/* Turns queued packets into verdicts; separate from I/O so it can be tested. */
typedef struct {
    const ts_config *config;
    ts_manager *sessions;
    ts_stats stats;
    unsigned warned_encrypt, warned_decrypt; /* bit per reason: warn once, then count */
    uint8_t buffer[65536 + 64];
} ts_processor;

/* Returns 1 to accept (out and out_len receive the replacement packet), 0 to drop. */
int ts_processor_handle(ts_processor *p, const ts_queued_packet *packet, const uint8_t **out,
                        size_t *out_len);

/* JSON object like {"decrypted": 3, "encrypted": 4} with sorted keys. */
void ts_stats_json(const ts_stats *stats, char *out, size_t size);

/* Runs until SIGINT/SIGTERM. Returns a process exit code. */
int ts_daemon_run(const ts_config *config);

#endif
