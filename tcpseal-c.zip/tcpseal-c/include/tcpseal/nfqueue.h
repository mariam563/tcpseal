/*
 * nfqueue.h - minimal NFQUEUE client written directly on the netlink API.
 *
 * Implements only what tcpseal needs (no libnetfilter_queue dependency):
 * bind queues, request full packet copies, receive packets, send verdicts
 * with an optional replacement packet. Layouts follow <linux/netlink.h>,
 * <linux/netfilter/nfnetlink.h> and <linux/netfilter/nfnetlink_queue.h>:
 * netlink headers are in host byte order, netfilter structures big-endian.
 */
#ifndef TCPSEAL_NFQUEUE_H
#define TCPSEAL_NFQUEUE_H

#include <stddef.h>
#include <stdint.h>

#define TS_NFQ_SUBSYS_QUEUE 3
#define TS_NFQ_MSG_PACKET 0
#define TS_NFQ_MSG_VERDICT 1
#define TS_NFQ_MSG_CONFIG 2
#define TS_NFQA_PACKET_HDR 1
#define TS_NFQA_VERDICT_HDR 2
#define TS_NFQA_PAYLOAD 10
#define TS_NFQA_CFG_CMD 1
#define TS_NFQA_CFG_PARAMS 2
#define TS_NFQA_CFG_QUEUE_MAXLEN 3
#define TS_NF_DROP 0
#define TS_NF_ACCEPT 1
#define TS_NLM_F_REQUEST 0x1
#define TS_NLM_F_ACK 0x4
#define TS_NLMSG_HDRLEN 16
#define TS_NFGENMSG_LEN 4
#define TS_NFQ_MAX_PAYLOAD (0xFFFF - 4)

typedef struct {
    uint16_t queue;
    uint32_t packet_id;
    const uint8_t *payload; /* NULL if the kernel sent no packet data */
    size_t payload_len;
} ts_queued_packet;

typedef struct {
    int fd;
    uint32_t seq;
    uint16_t queues[2];
    int queue_count;
    uint64_t overflows; /* kernel queue overflowed (ENOBUFS): packets were dropped */
    uint8_t *buffer;
} ts_nfqueue;

typedef void (*ts_packet_callback)(void *ctx, const ts_queued_packet *packet);

/* Returns 0, or a positive errno value (EPERM means "needs CAP_NET_ADMIN"). */
int ts_nfq_open(ts_nfqueue *q, const uint16_t *queues, int count, char *err);
/* Waits up to timeout_ms; calls cb for every packet. Returns -1 on fatal error. */
int ts_nfq_receive(ts_nfqueue *q, int timeout_ms, ts_packet_callback cb, void *ctx);
int ts_nfq_verdict(ts_nfqueue *q, uint16_t queue, uint32_t packet_id, int accept, const uint8_t *payload,
                   size_t payload_len);
void ts_nfq_close(ts_nfqueue *q);

/* Codec helpers (exposed for unit tests). Return the new length or 0 on overflow. */
size_t ts_nl_put_attr(uint8_t *buf, size_t len, size_t cap, uint16_t type, const void *data, size_t data_len);
size_t ts_nfq_begin(uint8_t *buf, size_t cap, uint8_t msg_type, uint16_t flags, uint32_t seq, uint16_t queue);
void ts_nfq_end(uint8_t *buf, size_t len);
int ts_nfq_parse_packet(const uint8_t *body, size_t body_len, ts_queued_packet *out);
/* Walks the attributes of body; returns attribute data or NULL. */
const uint8_t *ts_nl_find_attr(const uint8_t *attrs, size_t len, uint16_t type, size_t *out_len);

#endif
