/*
 * config.h - strict INI configuration (same format as the Python version).
 *
 * Unknown sections or keys, duplicates, missing required values and
 * out-of-range numbers are errors. Relative paths are resolved relative to
 * the directory that contains the configuration file.
 */
#ifndef TCPSEAL_CONFIG_H
#define TCPSEAL_CONFIG_H

#include "tcpseal/session.h"

#include <limits.h>
#include <stdbool.h>
#include <stdint.h>

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif

typedef struct {
    char role[8]; /* "device1" or "device2" */
    bool is_initiator;
    char identity_key[PATH_MAX];
    char peer_public_key[PATH_MAX];
    char control_address[16]; /* device1: Device2's address; device2: listen address */
    uint16_t control_port;
    double handshake_timeout;
    uint16_t encrypt_queue;
    uint16_t decrypt_queue;
    uint32_t peer_mtu;
    ts_limits limits;
    int log_level;
} ts_config;

int ts_config_load(const char *path, ts_config *cfg, char *err);

#endif
