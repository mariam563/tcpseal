/*
 * protector.h - transform one packet: protect (encrypt) / unprotect (decrypt).
 *
 * Wire format on the Device1 <-> Device2 link:
 *
 *     original IPv4 header | original TCP header | AES-GCM ciphertext | 16-byte tag
 *
 * Only the IPv4 total length and the two checksums differ from the original.
 * Packets without payload (SYN, ACK, FIN, RST) get a tag-only payload, so
 * TCP control packets are authenticated as well.
 */
#ifndef TCPSEAL_PROTECTOR_H
#define TCPSEAL_PROTECTOR_H

#include "tcpseal/session.h"

#include <stddef.h>
#include <stdint.h>

/* Drop reasons. Names match the statistics keys printed by the daemon. */
enum ts_drop_reason {
    TS_PASS = 0,
    TS_DROP_MALFORMED,
    TS_DROP_TOO_BIG,
    TS_DROP_NO_SESSION,
    TS_DROP_NONCE_REUSE,
    TS_DROP_EXPIRED,
    TS_DROP_NO_TAG,
    TS_DROP_AUTH,
    TS_DROP_REPLAY,
    TS_DROP_INTERNAL,
    TS_DROP_COUNT
};

const char *ts_drop_reason_name(int reason);

/* out must have room for in_len + TS_TAG_LEN bytes. Returns TS_PASS or a reason. */
int ts_protect(const uint8_t *in, size_t in_len, ts_manager *m, size_t peer_mtu, uint8_t *out,
               size_t *out_len);

/* out must have room for in_len bytes. Returns TS_PASS or a reason. */
int ts_unprotect(const uint8_t *in, size_t in_len, ts_manager *m, uint8_t *out, size_t *out_len);

#endif
