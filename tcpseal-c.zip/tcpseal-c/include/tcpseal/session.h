/*
 * session.h - session keys, nonce management, replay protection, lifetime.
 *
 * Nonce strategy (no nonce is transmitted, no custom header is added):
 *
 *     nonce = HMAC-SHA256(direction_nonce_key, canonical_header)[0..11]
 *
 * The receiving device sees the same header bytes and recomputes the nonce,
 * so packet loss and reordering cannot desynchronise anything.
 *
 * Uniqueness is ENFORCED: the sender remembers every nonce used in the
 * session and refuses to encrypt a second packet with the same nonce (the
 * packet is dropped; TCP retransmits it with a new IP ID / timestamp).
 * The receiver remembers every accepted nonce, which gives exact replay
 * protection. Both sets disappear with the session (rekey bounds memory).
 */
#ifndef TCPSEAL_SESSION_H
#define TCPSEAL_SESSION_H

#include "tcpseal/common.h"

#include <pthread.h>
#include <stdbool.h>
#include <stdint.h>

/* After a rekey the previous session may still DECRYPT for this long. */
#define TS_PREVIOUS_GRACE_SECONDS 10.0

/* Results of seal/open; also used as drop reasons by the protector. */
enum ts_session_result {
    TS_OK = 0,
    TS_ERR_NONCE_REUSE,
    TS_ERR_EXPIRED,
    TS_ERR_REPLAY,
    TS_ERR_AUTH,
    TS_ERR_INTERNAL,
};

typedef struct {
    uint8_t aes_key[TS_KEY_LEN];
    uint8_t nonce_key[TS_KEY_LEN];
} ts_direction_keys;

typedef struct {
    double rekey_after_seconds; /* soft limit: Device1 starts a new handshake */
    double lifetime_seconds;    /* hard limit: session is never used again */
    uint64_t max_packets;       /* hard per-direction limit; rekey at 80 % */
} ts_limits;

/* Growing open-addressing hash set of 12-byte nonces. */
typedef struct {
    uint8_t *slots; /* capacity * 16 bytes: 12 nonce bytes + "used" flag */
    size_t capacity;
    size_t count;
} ts_nonce_set;

int ts_nonce_set_init(ts_nonce_set *set);
bool ts_nonce_set_contains(const ts_nonce_set *set, const uint8_t nonce[TS_NONCE_LEN]);
/* Returns 0 if added, 1 if it was already present, -1 on out-of-memory. */
int ts_nonce_set_add(ts_nonce_set *set, const uint8_t nonce[TS_NONCE_LEN]);
void ts_nonce_set_free(ts_nonce_set *set);

typedef struct ts_session ts_session;

ts_session *ts_session_new(const char *session_id, const ts_direction_keys *tx, const ts_direction_keys *rx,
                           const ts_limits *limits);
void ts_session_free(ts_session *s);

const char *ts_session_id(const ts_session *s);
uint64_t ts_session_tx_count(const ts_session *s);
uint64_t ts_session_rx_count(const ts_session *s);
double ts_session_age(const ts_session *s, double now);
void ts_session_set_created(ts_session *s, double created); /* for tests */
bool ts_session_expired(const ts_session *s, double now);
bool ts_session_needs_rekey(const ts_session *s, double now);

void ts_derive_nonce(const uint8_t nonce_key[TS_KEY_LEN], const uint8_t *header, size_t header_len,
                     uint8_t nonce[TS_NONCE_LEN]);

/* Encrypt: out receives plaintext_len bytes ciphertext followed by the tag. */
int ts_session_seal(ts_session *s, const uint8_t *aad, size_t aad_len, const uint8_t *plaintext,
                    size_t plaintext_len, uint8_t *out);
/* Decrypt: protected = ciphertext || tag; out receives protected_len-16 bytes. */
int ts_session_open(ts_session *s, const uint8_t *aad, size_t aad_len, const uint8_t *protected_data,
                    size_t protected_len, uint8_t *out);

/*
 * Session manager: current session (encrypt + decrypt), previous session
 * (decrypt only, during a grace period) and pending session (Device1 only:
 * keys derived but not yet confirmed by Device2 -> decrypt only).
 *
 * The manager OWNS the sessions. Callers that use a session returned by a
 * *_locked function must hold the manager lock for as long as they use it,
 * because install() may free the old previous session.
 */
typedef struct {
    pthread_mutex_t lock;
    ts_session *current;
    ts_session *previous;
    ts_session *pending;
    double previous_until;
    double grace_seconds;
} ts_manager;

void ts_manager_init(ts_manager *m, double grace_seconds);
void ts_manager_destroy(ts_manager *m);
void ts_manager_lock(ts_manager *m);
void ts_manager_unlock(ts_manager *m);
void ts_manager_add_pending(ts_manager *m, ts_session *s);
void ts_manager_discard_pending(ts_manager *m);
void ts_manager_install(ts_manager *m, ts_session *s);
void ts_manager_clear(ts_manager *m);

/* Must be called with the lock held. */
ts_session *ts_manager_tx_locked(ts_manager *m, double now);
size_t ts_manager_rx_locked(ts_manager *m, double now, ts_session *out[3]);

/* Copy of the current session's id and counters (takes the lock itself).
 * Returns false if there is no current session. */
typedef struct {
    char id[17];
    double age;
    uint64_t tx, rx;
    bool needs_rekey;
} ts_session_info;
bool ts_manager_current_info(ts_manager *m, double now, ts_session_info *info);

#endif
